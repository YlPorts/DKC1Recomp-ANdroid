# DKC1 Android v1.5

Android ARM64 frontend for the pinned DKC1Recomp runtime. App identity remains
`com.ylports.dkc1recomp.mobile`, versionCode 106 / versionName 1.5. The same
private signing certificate as Mobile 0.3 is used for the delivered APK.
Do not change that identity or publish the signing key.

## Uso

Instalar sobre **DKC1 Android v1.4**, **v1.3.1**, **v1.3**, **v1.2**, **v1.1**, **v1** o **DKC1Recomp Mobile 0.3**, sin desinstalar ni borrar los datos.
La copia privada de la ROM, settings-v3.json y los guardados anteriores se
conservan. Una instalación nueva requiere importar la ROM USA v1.0 una vez.
El nombre visible es **DKC1 Android** y el panel muestra **v1.5**.

Menú oscuro: Juego, Gráficos, Audio, Controles, Partidas, Mods, Música, Extras.
No incluye pestaña de créditos, novedades ni explicaciones extensas. Los avisos
legales se conservan en assets/licenses y Extras > Licencias. El icono usado
es la imagen proporcionada por el propietario; no es un recurso extraído de ROM.

## Funciones

- Pausa y continuidad, cinco ranuras por formato, SRAM independiente y backup.
- 4:3, 16:10, 16:9, 21:9. Los modos anchos siguen siendo experimentales; no se
  cambia su lógica de cámara, colisiones ni la ampliación del cartucho.
- Nearest, Bilinear y Sharp Bilinear en dos pasos (ampliación entera nearest
  seguida de ajuste lineal); modelos de color del host PC y scanlines.
- Controles táctiles uniformes/editables, tamaño/opacidad y dos mandos.
- Velocidad normal o 2x. En 2x se consume el audio del motor sin reproducirlo.
- Rebobinado opcional: capturas cada seis fotogramas, historial máximo 32 MiB
  más un buffer de trabajo de hasta 8 MiB. El botón recupera hasta dos segundos
  según el historial disponible. Desactivado de forma predeterminada.
- Mods independientes con código Lua, botones de selección, atlas y audio
  externos. Las físicas y reglas específicas se cargan desde cada `.dkcmod`.
- Baby Kong no está disponible: se excluyen del enlace su decodificador y
  movimiento. Los hooks opcionales conectan la API general de mods; sin un
  script activo no modifican el juego. No se altera el port Windows/macOS
  de escritorio. Para el formato 5 se amplía únicamente el puente del intérprete
  snesrecomp, con un modo de sesión desactivado por defecto.

## Música MSU-1

Música > Importar pack ZIP / MSU1 o Importar carpeta. Copia local persistente;
no necesita conservar permisos URI ni acceso al archivo original para jugar.
Usa `runner/dkc1_msu1.c`, el mismo reproductor mmap/resample/mix de escritorio.

Se admiten nombres track-N.pcm, dkc_msu-N.pcm y dkc-N.pcm; se normalizan a track-N.
Exige pistas 1–27 para no silenciar temas ausentes después de aplicar el mute SPC.
PCM MSU-1: cabecera MSU1, punto de bucle little-endian, estéreo PCM signed 16-bit
44.1 kHz; no son MP3 ni WAV renombrados. Máximo 512 entradas, 256 MiB por pista,
2 GiB totales; rechazo de rutas peligrosas, duplicados, cabeceras y bucles inválidos.
El pack anterior se conserva hasta completar la validación del nuevo.

La sustitución sonora se activa en una nueva sesión. Los estados de esta modalidad
usan el sufijo `-msu1`, separado de la banda sonora original para evitar cargar
un estado con el programa SPC equivocado. La SRAM sigue compartida. Cambiar la
música puede mostrar otras ranuras, pero no elimina las anteriores. Al cargar o
rebobinar, la pista externa reinicia desde su comienzo (no se restaura el cursor
PCM); no se modifica la ROM privada en disco.

## Mods

Paquetes ZIP `.dkcmod` de formatos 2, 3, 4 y 5. Los formatos 2 y 3 conservan
los parches de traducción, datos, gráficos y sonido; el formato 3 añade botones
de selección. Los perfiles visuales de formato 1 siguen disponibles.

El formato 4 incorpora `dkc-lua-v1`: el mod contiene su código fuente Lua y sus
bancos opcionales de gráficos y sonidos. El APK ofrece funciones generales para
leer/escribir WRAM, filtrar controles, dibujar y gestionar sonidos; las reglas,
físicas, personajes y animaciones pertenecen al archivo del mod. Esas reglas
pueden actualizarse reconstruyendo solamente el `.dkcmod`. Una capacidad que la
API aún no ofrezca sí requiere ampliar la aplicación.

El formato 5 ejecuta romhacks en compatibilidad SNES: conserva sus instrucciones
de cartucho mediante el intérprete del núcleo. Esta primera modalidad usa 4:3,
música propia y un solo mod activo. No convierte Mario en código nativo ni Lua.
Al desactivarlo se recuperan las preferencias y perfiles de los otros mods.
Ver **mods/FORMATO_V15.md**. El APK no incluye el mod de Mario.

Se admiten hasta 32 paquetes instalados y ocho activos, con comprobación de
conflictos y selección persistente. Solo puede estar activo un mod con scripts
a la vez, acompañado de mods de datos compatibles. Los scripts no disponen de
archivos, red, procesos ni bibliotecas nativas; Lua tiene límites de memoria e
instrucciones y no acepta bytecode. Ver **mods/FORMATO_V14.md** para la API y
**mods/independent-template/** para una muestra editable.

Sonic y Tails 2.1 usa este sistema y mantiene las opciones de pareja o personaje
solitario. El APK 1.5 conserva sin cambios este `.dkcmod`: su alias compatible
conserva la selección, activación y perfiles de partidas de Sonic y Tails 1.0.
El paquete anterior permanece guardado, pero su antiguo motor específico
`sonic2-v1` requiere la actualización al mod independiente para ejecutarse.

Español 1.0: continúa los 217 mensajes, 49 nombres, 14 glifos españoles,
menús y créditos de Español 0.2. Añade los rótulos pendientes de escenarios y
mapas, barriles, combustible, «Nintendo presenta», «Fin del juego», encabezado
del final falso y tres advertencias del cartucho. Conserva nombres propios,
marcas, título, KONG y TNT. El paquete requiere `min_port: 102` (APK 1.2).

La lista de regiones de datos solo se amplía para los dos recursos de Candy y
el encabezado de créditos, con límites exactos. Siguen protegidos código,
vectores y cabeceras en los formatos de datos. El formato 5 tiene su contrato
separado y conserva hardware y vectores. El generador del juego utiliza siempre
la ROM limpia.

Desactiva Español 0.2, importa Español 1.0 sin descomprimirlo y actívalo antes
de iniciar otra sesión. Actualizar el APK no elimina la ROM, ajustes ni partidas.
Un mod sin alias compatible usa su propia huella y sus estados/SRAM quedan
separados; los antiguos no se borran. En formato 4, un autor puede declarar
`save_profile_sha256` para preservar explícitamente los perfiles de una versión
anterior con el mismo ID y los mismos selectores. Esa migración conserva los
archivos anteriores y solo sustituye la activación después de validar la
actualización. Ver **mods/README.md** y **mods/FORMATO_V14.md**.

## Compilar

Usar el código fuente del fork con snesrecomp en
851b11e38588818afc705e4270d3eb982b7b2af2 y SDL2 en
c98c4fbff6d8f3016a3ce6685bf8f43433c3efcc.
SDK 35, Build Tools 35.0.0, NDK 28.2.13676358, CMake 3.22.1,
Gradle 8.11.1 y JDK 17. Lua 5.4 está incluido en `third_party_runtime/lua`.
Aplica primero `APLICAR_V15.py`: el núcleo necesita el parche compat-v1 revisado.
El informe `BUILD_V1_5.json` registra la compilación de esta entrega.

```sh
python android/tools/build_android.py --rom /ruta/privada/dkc1.sfc --sdk /ruta/sdk --prepare-only
cd android
./gradlew --no-daemon :app:assembleRelease :app:lintRelease
```

Firmar el APK con la clave privada conservada de Mobile. El repositorio no
incluye ROM, código generado desde ROM, partidas, SDK ni claves.

## Validación y límites

Pruebas: `python android/tools/run_tests.py --report pruebas.json`.
Separar compilación, tests locales y ejecución en dispositivo. La v1.4 no se
ha ejecutado en un teléfono durante esta sesión. El LEEME principal de la entrega
y sus informes describen las pruebas actuales de scripts, migración y juego
en el motor Linux. `VALIDACION_ACTUAL.md` conserva únicamente el informe
histórico de la v1.2. Las pruebas MSU-1 usan PCM
sintético, no certifican todos los packs comerciales ni todos los niveles.
No se afirma paridad total con PC: Reconstruct y el CRT avanzado siguen sin
portar. Sharp Bilinear móvil es de dos pasos, no una copia de su shader de PC.

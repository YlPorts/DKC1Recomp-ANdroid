#!/usr/bin/env python3
"""Inspect an unsigned build without claiming signature or installation success."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

from verify_apk import elf_loads
from sign_release import CERT_SHA256


def run(args):
    return subprocess.check_output([str(x) for x in args], text=True, stderr=subprocess.STDOUT)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--apk', type=Path, required=True)
    p.add_argument('--sdk', type=Path, required=True)
    p.add_argument('--report', type=Path, required=True)
    a = p.parse_args()
    bt = a.sdk / 'build-tools/35.0.0'
    llvm = a.sdk / 'ndk/28.2.13676358/toolchains/llvm/prebuilt/linux-x86_64/bin'
    metadata = run([bt / 'aapt', 'dump', 'badging', a.apk])
    assert "name='com.ylports.dkc1recomp.mobile' versionCode='105' versionName='1.4'" in metadata
    assert "sdkVersion:'23'" in metadata and "native-code: 'arm64-v8a'" in metadata
    run([bt / 'zipalign', '-c', '-P', '16', '4', a.apk])
    signature = subprocess.run([str(bt / 'apksigner'), 'verify', str(a.apk)],
                               text=True, capture_output=True)
    if signature.returncode == 0:
        raise RuntimeError('This APK is signed; use verify_apk.py instead')
    native, references = [], {}
    with zipfile.ZipFile(a.apk) as z:
        names = z.namelist()
        assert len(names) == len(set(names))
        expected = {'lib/arm64-v8a/libmain.so', 'lib/arm64-v8a/libSDL2.so'}
        assert {n for n in names if n.startswith('lib/') and n.endswith('.so')} == expected
        assert not any(Path(n).suffix.lower() in ('.smc', '.sfc', '.smd', '.md', '.gba', '.srm', '.sav', '.state')
                       and not n.startswith('assets/licenses/') for n in names)
        notices = [n for n in names if n.startswith('assets/licenses/')]
        assert len(notices) >= 6
        assert 'assets/licenses/Lua-LICENSE.txt' in notices
        assert not any(n.endswith(('.lua','.dkcmod')) for n in names)
        with tempfile.TemporaryDirectory(prefix='dkc1-unsigned-') as d:
            for name in sorted(expected):
                assert z.getinfo(name).compress_type == zipfile.ZIP_STORED
                data = z.read(name)
                native.append({'name': name, 'size_bytes': len(data),
                               'sha256': hashlib.sha256(data).hexdigest(), 'elf_load_segments': elf_loads(data)})
                if name.endswith('/libmain.so'):
                    lib = Path(d) / 'libmain.so'; lib.write_bytes(data)
                    exports = {line.split()[-1] for line in run([llvm / 'llvm-nm', '-D', '--defined-only', lib]).splitlines() if line.split()}
                    required = ['SDL_main'] + ['Java_com_ylports_dkc1recomp_GameActivity_' + n for n in
                        ('nativeSetTouchMask', 'nativeSetMenuPaused', 'nativeSetLifecyclePaused',
                         'nativeRequest', 'nativeSetMuted', 'nativeConfigure')]
                    assert set(required) <= exports
                    assert {'AddonRuntimeLoad','ModScriptCreate','ModMediaDraw'} <= exports
                    assert not any(name.startswith(('SonicMod','SonicPhysics','SonicAudio','SonicSfx')) for name in exports)
                    wrappers = ['__wrap_Sprite_ApplyVelocity_M0X0', '__wrap_CODE_BFB0D1_M0X0',
                                '__wrap_APU_SubmitCommand_M0X0', '__wrap_APU_SubmitCommand_M1X0']
                    assert set(wrappers) <= exports
                    assembly = run([llvm / 'llvm-objdump', '-d', lib])
                    for wrapper in wrappers:
                        hits = [line.strip() for line in assembly.splitlines()
                                if re.search(r'\b(?:b|bl)\s', line) and '<' + wrapper in line]
                        references[wrapper] = {'direct_branch_references': len(hits), 'examples': hits[:4]}
                    assert references['__wrap_CODE_BFB0D1_M0X0']['direct_branch_references'] > 0
                    assert references['__wrap_APU_SubmitCommand_M0X0']['direct_branch_references'] > 0
                    assert references['__wrap_APU_SubmitCommand_M1X0']['direct_branch_references'] > 0
    android = Path(__file__).resolve().parents[1]
    source_hashes = {f.relative_to(android).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
                     for base in [android / 'native', android / 'app/src', android / 'third_party_runtime']
                     for f in sorted(base.rglob('*')) if f.is_file() and f.suffix in ('.c', '.h', '.java', '.xml')}
    for f in [android / 'native/CMakeLists.txt', android / 'app/build.gradle']:
        source_hashes[f.relative_to(android).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    report = {'apk': a.apk.name, 'size_bytes': a.apk.stat().st_size,
              'sha256': hashlib.sha256(a.apk.read_bytes()).hexdigest(),
              'structural_verification_passed': True, 'signature_verified': False,
              'installable': False, 'required_mobile_certificate_sha256': CERT_SHA256,
              'application_id': 'com.ylports.dkc1recomp.mobile', 'version_code': 105, 'version_name': '1.4',
              'minimum_sdk': 23, 'target_sdk': 35, 'abi': 'arm64-v8a',
              'elf_alignment_16k': True, 'zip_alignment_16k': True, 'jni_exports_present': True,
              'native_libraries': native, 'mod_wrapper_references': references,
              'generic_lua_runtime_linked': True, 'sonic_native_implementation_absent': True,
              'rom_file_bundled': False, 'license_files': notices, 'android_source_sha256': source_hashes,
              'installed_on_android': False, 'gameplay_tested_on_android': False,
              'scope': 'Unsigned build structure and linked hooks only; signature and device execution are not verified'}
    a.report.parent.mkdir(parents=True, exist_ok=True)
    a.report.write_text(json.dumps(report, indent=2) + '\n')
    print('Unsigned APK structure verified; signature_verified=false, installable=false')


if __name__ == '__main__':
    main()

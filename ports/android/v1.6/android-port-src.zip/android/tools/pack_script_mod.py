#!/usr/bin/env python3
"""Build a DKC1 Android 1.4 independent .dkcmod without an APK compiler or ROM.

Example:
 python android/tools/pack_script_mod.py \
   --manifest android/mods/independent-template/manifest.json \
   --script android/mods/independent-template/main.lua --out Salto-configurable.dkcmod

Lua source is packed, never executed by this tool. Android validates and runs it
with the generic dkc-lua-v1 host. An optional atlas/audio bank must already use
DKCATL1/DKCSND1 encoding. The runtime descriptor is generated from the bytes.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import tempfile
import zipfile

BASE_SHA='fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15'
MAX_BUNDLE=24*1024*1024
MAX_MEDIA=16*1024*1024
MAX_TOTAL=32*1024*1024
MAX_SCRIPT=256*1024
CHOICE_ID=re.compile(r'[a-z][a-z0-9_-]{0,31}\Z')
HASH=re.compile(r'[0-9a-f]{64}\Z')


def sha(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError(f'Campo JSON duplicado: {key}')
        result[key]=value
    return result


def bounded_read(path:Path,limit:int)->bytes:
    if path.stat().st_size>limit:raise ValueError(f'Archivo demasiado grande: {path.name}')
    with path.open('rb') as stream:data=stream.read(limit+1)
    if len(data)>limit:raise ValueError(f'Archivo demasiado grande: {path.name}')
    return data


def fields(value,allowed,required=()):
    if not isinstance(value,dict) or set(value)-set(allowed) or set(required)-set(value):
        raise ValueError('Campos del manifiesto ausentes o no admitidos.')


def label(value,limit):
    if not isinstance(value,str) or not value.strip() or len(value)>limit or any(ord(c)<32 or 127<=ord(c)<160 for c in value):
        raise ValueError('Texto de manifiesto vacío, demasiado largo o con controles.')
    return value


def integer(value,minimum,maximum):
    if type(value) is not int or not minimum<=value<=maximum:raise ValueError('Entero de manifiesto fuera de rango.')
    return value


def validate_atlas(data:bytes):
    if not data:return
    if len(data)<24 or len(data)>MAX_MEDIA or data[:8]!=b'DKCATL1\0':raise ValueError('Se requiere un atlas DKCATL1 válido.')
    width,height,frames,colors=struct.unpack_from('<IIII',data,8)
    if not(1<=width<=256 and 1<=height<=256 and 1<=frames<=4096 and 1<=colors<=256):raise ValueError('Dimensiones del atlas fuera de rango.')
    start=24+colors*4
    if start+width*height*frames!=len(data) or any(p>=colors for p in data[start:]):raise ValueError('Píxeles o longitud del atlas inválidos.')


def validate_audio(data:bytes):
    if not data:return
    if len(data)<12 or len(data)>MAX_MEDIA or data[:8]!=b'DKCSND1\0':raise ValueError('Se requiere un banco DKCSND1 válido.')
    count,=struct.unpack_from('<I',data,8)
    if count>32:raise ValueError('Máximo 32 efectos de sonido.')
    offset,used=12,0
    for _ in range(count):
        if offset+16>len(data):raise ValueError('Cabecera de sonido incompleta.')
        bit,rate,channels,frames=struct.unpack_from('<IIII',data,offset);offset+=16
        if not bit or bit&(bit-1) or bit&used or not 8000<=rate<=96000 or channels not in (1,2) or not 1<=frames<=rate*8:
            raise ValueError('Parámetros de sonido inválidos.')
        offset+=frames*channels*2;used|=bit
        if offset>len(data):raise ValueError('PCM de sonido incompleto.')
    if offset!=len(data):raise ValueError('Datos adicionales en el banco de sonido.')


def validate_manifest(manifest:dict,source_dir:Path):
    fields(manifest,{'format','min_port','id','name','version','description','category','locale','base_sha256','patches','choices','runtime','save_profile_sha256'}, {'id','name','version','category'})
    manifest=dict(manifest)
    manifest.setdefault('format',4);manifest.setdefault('min_port',105);manifest.setdefault('base_sha256',BASE_SHA);manifest.setdefault('patches',[])
    if manifest['format']!=4 or type(manifest['format']) is not int or manifest['min_port']!=105 or type(manifest['min_port']) is not int or manifest['base_sha256']!=BASE_SHA:
        raise ValueError('El constructor requiere formato 4, min_port 105 y la ROM base USA v1.0.')
    if not re.fullmatch(r'[a-z0-9][a-z0-9._-]{1,63}',label(manifest['id'],64)):raise ValueError('ID de mod inválido.')
    for key,limit in [('name',60),('version',24),('description',300),('category',20),('locale',20)]:
        if key in manifest:label(manifest[key],limit)
    if manifest['category'] not in ('data','audio','graphics','translation'):raise ValueError('Categoría no admitida.')
    if 'locale' in manifest and not re.fullmatch(r'[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})?',manifest['locale']):raise ValueError('Idioma no admitido.')
    if 'save_profile_sha256' in manifest and not HASH.fullmatch(label(manifest['save_profile_sha256'],64)):raise ValueError('Alias del perfil inválido.')
    choices=manifest.get('choices',[])
    if not isinstance(choices,list) or len(choices)>8:raise ValueError('Se permiten hasta ocho selectores.')
    resources={};patch_count=0
    region_file=Path(__file__).resolve().parents[1]/'mods/regions.json'
    regions=None
    def patches(rows):
        nonlocal patch_count,regions
        if not isinstance(rows,list):raise ValueError('patches debe ser una lista.')
        spans=[];total=0
        for patch in rows:
            fields(patch,{'offset','size','file','sha256','expected_sha256','kind'},{'offset','size','file','sha256','expected_sha256','kind'})
            patch_count+=1
            if patch_count>4096:raise ValueError('Demasiados parches.')
            offset=integer(patch['offset'],0,4194303);size=integer(patch['size'],1,4*1024*1024);total+=size
            if total>4*1024*1024:raise ValueError('Una lista de parches supera 4 MiB.')
            name=label(patch['file'],160)
            if not re.fullmatch(r'(patches|textures|sprites|levels|audio)/[A-Za-z0-9._/-]+\.bin',name) or any(p in ('','.', '..') for p in name.split('/')):
                raise ValueError('Ruta de parche no permitida.')
            file=(source_dir/name).resolve()
            try:file.relative_to(source_dir.resolve())
            except ValueError as error:raise ValueError('Un parche sale de la carpeta del manifiesto.') from error
            for key in ('sha256','expected_sha256'):
                if not HASH.fullmatch(label(patch[key],64)):raise ValueError('Huella de parche inválida.')
            kind=patch['kind'];text=manifest['category']=='translation' or kind=='text'
            if kind not in ('text','graphics','level','audio','data') or manifest['category']=='translation' and kind!='text':raise ValueError('Tipo de parche no admitido.')
            if regions is None:regions=json.loads(region_file.read_text(encoding='utf-8'))
            if not any(a<=offset and offset+size<=b for a,b in regions['text' if text else 'data']):raise ValueError('Un parche toca una región no admitida.')
            content=bounded_read(file,4*1024*1024)
            if len(content)!=size or sha(content)!=patch['sha256']:raise ValueError(f'Parche incompleto o alterado: {name}')
            if name.lower() in {p.lower() for p in resources} and name not in resources:raise ValueError('Dos recursos solo difieren por mayúsculas.')
            resources[name]=content;spans.append((offset,offset+size))
        check_spans(spans)
        return spans
    base=patches(manifest['patches']);seen=set()
    for choice in choices:
        fields(choice,{'id','label','default','options'},{'id','label','default','options'})
        cid=choice['id']
        if not isinstance(cid,str) or not CHOICE_ID.fullmatch(cid) or cid in seen:raise ValueError('Selector inválido o duplicado.')
        seen.add(cid);label(choice['label'],60)
        options=choice['options']
        if not isinstance(options,list) or not 2<=len(options)<=8:raise ValueError('Un selector requiere entre dos y ocho botones.')
        option_ids=set()
        for option in options:
            fields(option,{'id','label','patches'},{'id','label','patches'})
            oid=option['id']
            if not isinstance(oid,str) or not CHOICE_ID.fullmatch(oid) or oid in option_ids:raise ValueError('Opción inválida o duplicada.')
            option_ids.add(oid);label(option['label'],60);check_spans(base+patches(option['patches']))
        if choice['default'] not in option_ids:raise ValueError('La selección predeterminada no existe.')
    return manifest,resources


def check_spans(spans):
    end=0
    for a,b in sorted(spans):
        if a<end:raise ValueError('Parches solapados.')
        end=b


def build(manifest_path:Path,script_path:Path,output:Path,atlas_path:Path|None=None,audio_path:Path|None=None)->dict:
    if output.suffix.lower()!='.dkcmod':raise ValueError('La salida debe terminar en .dkcmod.')
    raw=bounded_read(manifest_path,512*1024).decode('utf-8')
    manifest=json.loads(raw,object_pairs_hook=unique_object,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Número JSON no admitido.')))
    manifest,entries=validate_manifest(manifest,manifest_path.parent)
    script=bounded_read(script_path,MAX_SCRIPT);script.decode('utf-8')
    if not script or b'\0' in script or script.startswith(b'\x1b'):raise ValueError('Se requiere código Lua fuente UTF-8 sin bytes nulos, no bytecode.')
    atlas=bounded_read(atlas_path,MAX_MEDIA) if atlas_path else b'';audio=bounded_read(audio_path,MAX_MEDIA) if audio_path else b''
    validate_atlas(atlas);validate_audio(audio)
    bundle=struct.pack('<8sIII',b'DKCLUA1\0',len(script),len(atlas),len(audio))+script+atlas+audio
    if len(bundle)>MAX_BUNDLE:raise ValueError('El contenedor de ejecución supera 24 MiB.')
    manifest['runtime']={'engine':'dkc-lua-v1','file':'runtime/mod.bin','size':len(bundle),'sha256':sha(bundle)}
    entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8');entries['runtime/mod.bin']=bundle
    if len(entries['manifest.json'])>512*1024:raise ValueError('El manifiesto generado supera 512 KiB.')
    for target,candidates in [('README.txt',['README.txt','README.md']),('LICENSE.txt',['LICENSE.txt','LICENSE.md'])]:
        for candidate in candidates:
            source=manifest_path.parent/candidate
            if source.is_file():entries[target]=bounded_read(source,65536);break
    if len(entries)>512 or sum(map(len,entries.values()))>MAX_TOTAL:raise ValueError('El paquete supera sus límites de entradas o tamaño.')
    output.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix='.dkcmod-',suffix='.tmp',dir=output.parent);os.close(fd)
    try:
        with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
            for name,data in sorted(entries.items()):
                info=zipfile.ZipInfo(name,date_time=(2026,9,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
                archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        if Path(temp).stat().st_size>MAX_TOTAL:raise ValueError('El ZIP supera 32 MiB.')
        package_sha=sha(Path(temp).read_bytes());os.replace(temp,output)
    finally:
        if Path(temp).exists():Path(temp).unlink()
    return {'output':str(output),'package_sha256':package_sha,'runtime_sha256':sha(bundle),'script_bytes':len(script),'atlas_bytes':len(atlas),'audio_bytes':len(audio),'entries':len(entries),'gameplay_tested':False}


def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--script',type=Path,required=True)
    parser.add_argument('--atlas',type=Path);parser.add_argument('--audio',type=Path);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:report=build(args.manifest,args.script,args.out,args.atlas,args.audio)
    except (OSError,ValueError,KeyError,TypeError) as error:parser.exit(1,str(error)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0

if __name__=='__main__':raise SystemExit(main())

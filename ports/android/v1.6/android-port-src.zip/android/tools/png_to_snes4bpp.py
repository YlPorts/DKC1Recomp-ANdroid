#!/usr/bin/env python3
"""Convert an author-owned indexed PNG to raw SNES 4bpp tiles and RGB555 palette.

This converts pixel data, NOT animation/OAM headers, compression or pointers.
Only insert the result into a matching uncompressed 4bpp asset location. PNG
index 0 is transparent; at most 16 palette entries may be used. No quantization
is performed implicitly. Requires Pillow. No Nintendo artwork is included.
"""
import argparse,struct
from pathlib import Path
from PIL import Image

def convert(image:Image.Image)->tuple[bytes,bytes]:
    if image.mode!='P':raise ValueError('Use an indexed PNG (P mode), not RGB/RGBA.')
    w,h=image.size
    if not w or not h or w%8 or h%8 or w>1024 or h>1024:raise ValueError('Dimensions must be multiples of 8, at most 1024.')
    pixels=image.tobytes()
    if max(pixels)>15:raise ValueError('Only palette indices 0..15 are permitted.')
    alpha=image.info.get('transparency',0)
    if isinstance(alpha,int):
        if alpha!=0:raise ValueError('Transparent index must be 0.')
    elif not (len(alpha)>0 and alpha[0]==0 and all(x==255 for x in alpha[1:])):raise ValueError('Only index 0 may be transparent, no partial alpha.')
    palette=image.getpalette() or [];palette=palette+[0]*(48-len(palette));colors=bytearray()
    for i in range(16):
        r,g,b=palette[3*i:3*i+3];colors+=struct.pack('<H',(r>>3)|((g>>3)<<5)|((b>>3)<<10))
    out=bytearray()
    for ty in range(0,h,8):
        for tx in range(0,w,8):
            tile=bytearray(32)
            for y in range(8):
                for x in range(8):
                    v=pixels[(ty+y)*w+tx+x]
                    for plane in range(4):tile[(plane//2)*16+y*2+plane%2]|=((v>>plane)&1)<<(7-x)
            out+=tile
    return bytes(out),bytes(colors)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('png',type=Path);p.add_argument('--tiles',type=Path,required=True);p.add_argument('--palette',type=Path,required=True);a=p.parse_args()
    try:
        with Image.open(a.png) as image:tiles,palette=convert(image)
        a.tiles.write_bytes(tiles);a.palette.write_bytes(palette);print(f'{len(tiles)//32} tiles, 16 RGB555 palette entries.')
    except (OSError,ValueError) as e:p.exit(1,str(e)+'\n')
if __name__=='__main__':main()

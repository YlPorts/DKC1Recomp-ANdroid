#!/usr/bin/env python3
"""Sign an Android update with the original Mobile certificate, never a new key.

Passwords must be supplied in environment variables. Private key material and
passwords are never written to reports. The output appears only after signature,
package, version and alignment verification all pass.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

CERT_SHA256 = "d054ee3bb0a45e7c7625767c35aeeb8c2d66ec66e9b9570a1da3d627c13ae4b6"
APPLICATION_ID = "com.ylports.dkc1recomp.mobile"


def run(args: list[str], binary: bool = False):
    p = subprocess.run(args, check=False, capture_output=True, text=not binary)
    if p.returncode:
        # Tool diagnostics may include private paths. Keep failures generic.
        raise RuntimeError(f"{Path(args[0]).name} failed (exit {p.returncode}); no update was published")
    return p.stdout


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--apk", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--sdk", type=Path, required=True)
    p.add_argument("--keystore", type=Path, required=True)
    p.add_argument("--alias", required=True)
    p.add_argument("--store-password-env", default="DKC1_STORE_PASSWORD")
    p.add_argument("--key-password-env", default="DKC1_KEY_PASSWORD")
    a = p.parse_args()
    for name in (a.store_password_env, a.key_password_env):
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) or not os.environ.get(name):
            p.error("Set the requested password environment variables first")
    if not a.apk.is_file() or not a.keystore.is_file():
        p.error("The input APK and original keystore must exist")
    if a.out.exists():
        p.error("Output already exists; choose a new filename")
    bt = a.sdk / "build-tools/35.0.0"
    for name in ("aapt", "zipalign", "apksigner"):
        if not (bt / name).is_file():
            p.error("Android Build Tools 35.0.0 are required")
    keytool = shutil.which("keytool")
    if not keytool:
        p.error("Java keytool is required")
    der = run([keytool, "-exportcert", "-keystore", str(a.keystore),
               "-alias", a.alias, "-storepass:env", a.store_password_env], binary=True)
    if hashlib.sha256(der).hexdigest() != CERT_SHA256:
        raise RuntimeError("Wrong certificate: this key cannot update the existing Mobile app")
    badging = run([str(bt / "aapt"), "dump", "badging", str(a.apk)])
    package = re.search(r"package: name='([^']+)' versionCode='([0-9]+)' versionName='([^']+)'", badging)
    if not package or package.group(1) != APPLICATION_ID or int(package.group(2)) < 103:
        raise RuntimeError("Wrong package or version: expected a Mobile update newer than 1.2")
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="dkc1-sign-", dir=a.out.parent) as d:
        temp = Path(d)
        aligned, signed = temp / "aligned.apk", temp / "signed.apk"
        run([str(bt / "zipalign"), "-P", "16", "-f", "4", str(a.apk), str(aligned)])
        run([str(bt / "apksigner"), "sign", "--ks", str(a.keystore), "--ks-key-alias", a.alias,
             "--ks-pass", "env:" + a.store_password_env,
             "--key-pass", "env:" + a.key_password_env,
             "--out", str(signed), str(aligned)])
        verify = run([str(bt / "apksigner"), "verify", "--verbose", "--print-certs", str(signed)])
        certs = re.findall(r"certificate SHA-256 digest: ([0-9a-fA-F]+)", verify)
        if [x.lower() for x in certs] != [CERT_SHA256]:
            raise RuntimeError("The signed APK certificate did not match the original Mobile key")
        run([str(bt / "zipalign"), "-P", "16", "-c", "4", str(signed)])
        signed.rename(a.out)
    report = {"apk": a.out.name, "sha256": hashlib.sha256(a.out.read_bytes()).hexdigest(),
              "application_id": package.group(1), "version_code": int(package.group(2)),
              "version_name": package.group(3), "certificate_sha256": CERT_SHA256,
              "original_mobile_certificate": True, "zip_alignment_16k": True,
              "installed_on_android": False}
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError) as e:
        raise SystemExit(str(e))

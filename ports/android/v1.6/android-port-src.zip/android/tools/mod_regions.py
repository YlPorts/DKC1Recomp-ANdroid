#!/usr/bin/env python3
"""Conservative ROM-data map; never allow patching the main 65816 code.

Structural offsets come from the project's GPL-provenance recomp/*.cfg.
Whole CPU-visible upper halves that contain code stay read-only. Audited text/artwork
spans are the only exceptions in code banks. This is NOT a proof of mod safety:
invalid assets can still be rejected or break the guest game.
"""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[2]
# Identified strings, not instructions. Translation-only patches are further
# constrained to preserve length, control bytes and bit-7 line terminators.
TEXT=[(0x1dfd5,0x1e1c0),(0x1efe8,0x1f3e7),(0x38a50d,0x38a7e7),(0x3c03c8,0x3c35ca)]
# v1.2: exact, uncompressed Candy BG tilemap/gfx and the fake-credits header.
# Source oracle: Yoshifanatic1 DKC1 AssetPointersAndFiles.asm and
# Routine_Macros_DKC1.asm, c2080f40469c716923f550706509a0d354229841.
# $C01340..$C01A3F tilemap; $C01A41..$C07A20 4bpp tiles;
# $81EFDE..$81EFE7 text. The inter-resource byte $C01A40 stays excluded.
AUDITED_DATA_V12=[(0x1340,0x1a40),(0x1a41,0x7a21),(0x1efde,0x1efe8)]
def ranges():
    out=[]
    for bank in range(0x40):
        cfg=ROOT/f'recomp/bank{bank+0x80:02x}.cfg'
        # All ROM offset lower halves are data in this game's HiROM layout.
        # Bank zero is excluded (vectors/header/architectural bootstrap).
        if bank:out.append((bank<<16,(bank<<16)+0x8000))
        if bank and (not cfg.exists() or not re.search(r'^func ',cfg.read_text(),re.M)):
            out.append(((bank<<16)+0x8000,(bank+1)<<16))
    out+=TEXT+AUDITED_DATA_V12
    merged=[]
    for a,b in sorted(out):
        if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
        else:merged.append((a,b))
    return merged

def permitted(offset,length,translation=False):
    return length>0 and any(a<=offset and offset+length<=b for a,b in (TEXT if translation else ranges()))

if __name__=='__main__':
    rows=ranges();(ROOT/'android/mods/regions.json').write_text(json.dumps({'rom':'USA-1.0','data':rows,'text':TEXT},indent=2)+'\n')
    header='/* Generated structural data ranges; see android/tools/mod_regions.py. */\n'
    header+='static const uint32_t kModDataRanges[][2] = {\n'+''.join(f'  {{0x{a:x}u,0x{b:x}u}},\n' for a,b in rows)+'};\n'
    (ROOT/'android/native/mod_regions.h').write_text(header)
    java='package com.ylports.dkc1recomp;\n/** Generated structural data map; see mod_regions.py. */\nfinal class ModRegions {\n'
    for name,rs in [('DATA',rows),('TEXT',TEXT)]:java+=f' static final int[][] {name}={{'+','.join('{'+f'{a},{b}'+'}' for a,b in rs)+'};\n'
    java+=' static boolean allowed(int offset,int size,boolean text){if(offset<0||size<=0)return false;long end=(long)offset+size;for(int[] r:text?TEXT:DATA)if(offset>=r[0]&&end<=r[1])return true;return false;}\n}\n'
    (ROOT/'android/app/src/main/java/com/ylports/dkc1recomp/ModRegions.java').write_text(java)
    print(len(rows),'permitted structural ranges')

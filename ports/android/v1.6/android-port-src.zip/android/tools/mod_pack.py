#!/usr/bin/env python3
"""Pack fixed-size ROM DATA changes for DKC1 Android 1.2. Never recompiles code.

Example:
 python android/tools/mod_pack.py --base-rom clean.sfc --modified-rom edited.sfc \
   --id author.graphics --name "My graphics" --category graphics --output MyMod.dkcmod
ROMs stay private. A successful structural check does not prove gameplay
correctness: assets must retain the original SNES encoding and pointer layout.
"""
from __future__ import annotations
import argparse,hashlib,json,re,zipfile
from pathlib import Path
from mod_regions import permitted,ranges,TEXT,AUDITED_DATA_V12
BASE_SHA='fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15'
SIZE=4194304

def read_rom(path:Path,clean:bool)->bytes:
    b=path.read_bytes()
    if len(b)==SIZE+512:b=b[512:]
    if len(b)!=SIZE:raise ValueError('ROM size must remain 4 MiB (optional 512-byte copier header).')
    if clean and hashlib.sha256(b).hexdigest()!=BASE_SHA:raise ValueError('Base ROM is not the supported USA v1.0.')
    return b

def data_chunks(before:bytes,after:bytes,translation:bool=False)->list[tuple[int,int]]:
    if len(before)!=SIZE or len(after)!=SIZE:raise ValueError('Invalid payload size.')
    # One range per changed permitted region minimizes ZIP entries and preserves
    # all intermediate unchanged bytes. Boundaries never cross denied code.
    allowed=TEXT if translation else ranges();chunks=[]
    cursor=0
    for start,end in allowed:
        if before[cursor:start]!=after[cursor:start]:raise ValueError(f'Unsupported/code change before offset 0x{start:x}.')
        changed=[i for i in range(start,end) if before[i]!=after[i]]
        if changed:chunks.append((changed[0],changed[-1]+1))
        cursor=end
    if before[cursor:]!=after[cursor:]:raise ValueError('Unsupported/code change after final data range.')
    if not chunks:raise ValueError('No changes to package.')
    return chunks

def write_package(before:bytes,after:bytes,chunks:list[tuple[int,int]],output:Path,*,id:str,name:str,version:str='1.0',category:str='data',description:str='',locale:str='',min_port:int=101)->dict:
    if hashlib.sha256(before).hexdigest()!=BASE_SHA or len(after)!=SIZE:raise ValueError('Invalid base ROM or modified length.')
    if not re.fullmatch(r'[a-z0-9][a-z0-9._-]{1,63}',id):raise ValueError('Invalid package ID.')
    if not 1<=len(name)<=60 or not 1<=len(version)<=24 or len(description)>300:raise ValueError('Manifest text too long/empty.')
    if category not in ('translation','graphics','audio','data'):raise ValueError('Unsupported category.')
    if locale and not re.fullmatch(r'[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})?',locale):raise ValueError('Invalid locale.')
    patches=[];resources={};end=0;total=0
    for index,(a,b) in enumerate(sorted(chunks)):
        if a<end or not permitted(a,b-a,category=='translation'):raise ValueError('Overlapping or unsupported range.')
        old=before[a:b];new=after[a:b];end=b;total+=b-a
        if category=='translation':
            for x,y in zip(old,new):
                if (x<32 and x!=y) or (x>=32 and ((x^y)&128 or (y&127)<32)):raise ValueError('Changed text command/line terminator.')
        file=f'patches/{index:03}.bin';resources[file]=new
        patches.append({'offset':a,'size':b-a,'file':file,'sha256':hashlib.sha256(new).hexdigest(),'expected_sha256':hashlib.sha256(old).hexdigest(),'kind':'text' if category=='translation' else category if category!='data' else 'data'})
    if not patches or len(patches)>500 or total>SIZE:raise ValueError('Package exceeds limits.')
    if min_port not in (101,102):raise ValueError('Unsupported minimum port version.')
    if any(a<hi and b>lo for a,b in chunks for lo,hi in AUDITED_DATA_V12):min_port=102
    manifest={'format':2,'min_port':min_port,'id':id,'name':name,'version':version,'category':category,'base_sha256':BASE_SHA,'patches':patches}
    if description:manifest['description']=description
    if locale:manifest['locale']=locale
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
        for f,b in resources.items():z.writestr(f,b)
    return manifest

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base-rom',type=Path,required=True);p.add_argument('--modified-rom',type=Path,required=True)
    p.add_argument('--id',required=True);p.add_argument('--name',required=True);p.add_argument('--version',default='1.0');p.add_argument('--category',choices=['translation','graphics','audio','data'],default='data');p.add_argument('--description',default='');p.add_argument('--locale',default='');p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    try:
        before=read_rom(a.base_rom,True);after=read_rom(a.modified_rom,False)
        m=write_package(before,after,data_chunks(before,after,a.category=='translation'),a.output,id=a.id,name=a.name,version=a.version,category=a.category,description=a.description,locale=a.locale)
        print(f'{a.output}: {len(m["patches"])} data regions. Test in-game before distributing.')
        return 0
    except (ValueError,OSError) as e:p.exit(1,str(e)+'\n')
if __name__=='__main__':raise SystemExit(main())

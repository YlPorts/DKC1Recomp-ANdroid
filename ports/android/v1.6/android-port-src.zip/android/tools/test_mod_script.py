#!/usr/bin/env python3
"""Build and exercise the independent mod VM using its vendored Lua sources."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, help="Directory for executable and JSON/log evidence")
    parser.add_argument("--cc", default="cc")
    parser.add_argument("--no-sanitize", action="store_true")
    args = parser.parse_args()
    android = Path(__file__).resolve().parents[1]
    output = (args.out or Path(tempfile.mkdtemp(prefix="dkc-mod-vm-"))).resolve()
    output.mkdir(parents=True, exist_ok=True)
    lua = android / "third_party_runtime/lua/src"
    excluded = {"lua.c", "luac.c", "linit.c", "liolib.c", "loslib.c", "loadlib.c",
                "ldblib.c", "lcorolib.c", "lutf8lib.c"}
    sources = [str(path) for path in sorted(lua.glob("*.c")) if path.name not in excluded]
    if not sources:
        raise SystemExit(f"Missing vendored Lua sources: {lua}")
    binary = output / "test_mod_script"
    command = [args.cc, "-std=c11", "-O1", "-g", "-fno-omit-frame-pointer",
               "-Dluai_makeseed(L)=0x444b4331u", f"-I{lua}", f"-I{android / 'native'}"]
    if not args.no_sanitize:
        command.append("-fsanitize=address,undefined")
    command += [str(android / "native/mod_script.c"), str(android / "tests/test_mod_script.c"),
                *sources, "-lm", "-o", str(binary)]
    subprocess.run(command, check=True)
    environment = os.environ.copy()
    # LeakSanitizer cannot operate under the ptrace-based task environment.
    if not args.no_sanitize:
        environment["ASAN_OPTIONS"] = "detect_leaks=0"
    result = subprocess.run([str(binary)], env=environment, capture_output=True,
                            text=True, timeout=15)
    (output / "mod-script-tests.log").write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(f"VM test failed ({result.returncode}): {output / 'mod-script-tests.log'}")
    report = json.loads(result.stdout)
    report["sanitizers"] = [] if args.no_sanitize else ["AddressSanitizer", "UndefinedBehaviorSanitizer"]
    report["leak_sanitizer"] = False
    report["scope"] = "VM and stub host API; does not certify game integration or Android execution"
    report["build_command"] = command
    report["source_sha256"] = {
        str(path.relative_to(android)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [android / "native/mod_script.c", android / "native/mod_script.h",
                     android / "tests/test_mod_script.c"]
    }
    report_path = output / "mod-script-tests.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": True, "assertions": report["assertions"], "report": str(report_path)}))


if __name__ == "__main__":
    main()

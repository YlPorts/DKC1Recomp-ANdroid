#!/usr/bin/env python3
"""Build the initial Spanish data-only package from the user's clean ROM.
Contains no original game assets or English dialogue. Spanish wording is in
android/mods/es_messages.txt and es_names.txt; numeric text layout is hash-bound.
"""
import argparse,functools,json
from pathlib import Path
from mod_pack import read_rom,write_package
ROOT=Path(__file__).resolve().parents[1]
def wrap(text,capacities):
    words=text.split()
    @functools.lru_cache(None)
    def fit(i,j):
        if j==len(capacities):return [] if i==len(words) else None
        for k in range(len(words),i-1,-1):
            line=' '.join(words[i:k])
            if len(line)>capacities[j]:continue
            tail=fit(k,j+1)
            if tail is not None:return [line]+tail
        return None
    return fit(0,0)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--rom',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    try:
        before=read_rom(a.rom,True);after=bytearray(before);layout=json.loads((ROOT/'mods/es_layout.json').read_text())
        messages={int(l[:3]):l[4:] for l in (ROOT/'mods/es_messages.txt').read_text().splitlines() if l.strip()}
        names=(ROOT/'mods/es_names.txt').read_text().splitlines()
        if len(messages)!=len(layout['messages']) or len(names)!=len(layout['names']):raise ValueError('Translation count mismatch.')
        def put(o,n,text):
            value=text.ljust(n).encode('ascii')
            if len(value)!=n:raise ValueError(f'Text too long at {o:#x}')
            after[o:o+n]=bytes((v&127)|(old&128) for v,old in zip(value,before[o:o+n]))
        for i,rows in enumerate(layout['messages']):
            lines=wrap(messages[i],[n for _,n in rows])
            if lines is None:raise ValueError(f'Message {i} does not fit original rows.')
            for (o,n),line in zip(rows,lines):put(o,n,line)
        for (o,n),text in zip(layout['names'],names):put(o,n,text)
        write_package(before,bytes(after),[(0x38a50d,0x38a7e7),(0x3c03c8,0x3c35ca)],a.output,
          id='ylports.es.inicial',name='Español · mapas y diálogos',version='0.1',category='translation',locale='es',
          description='49 nombres de zonas y 217 mensajes. El título y los menús gráficos aún no están traducidos. Usa la fuente original, sin tildes.')
        print('Spanish package built. 49 map labels and 217 messages; graphical menus/title not translated.')
    except (OSError,ValueError,UnicodeError,KeyError) as e:p.exit(1,str(e)+'\n')
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Run host-side unit tests. This does NOT build or test an Android APK."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ANDROID=Path(__file__).resolve().parents[1]

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report",type=Path)
    parser.add_argument("--sonic-atlas",type=Path,help="Previous atlas for pixel/PCM differential compatibility tests")
    parser.add_argument("--rom",type=Path,help="Verified original ROM for Java integration")
    parser.add_argument("--spanish-mod",type=Path,help="Real Spanish data mod")
    parser.add_argument("--independent-mod",type=Path,help="Real independent runtime mod")
    parser.add_argument("--legacy-mod",type=Path,help="Previous mod for exact profile migration")
    args=parser.parse_args()
    if args.spanish_mod and not args.rom:parser.error("--spanish-mod requires --rom")
    if args.independent_mod and not (args.rom and args.spanish_mod):parser.error("--independent-mod requires --rom and --spanish-mod")
    if args.legacy_mod and not args.independent_mod:parser.error("--legacy-mod requires --independent-mod")
    for path in (args.sonic_atlas,args.rom,args.spanish_mod,args.independent_mod,args.legacy_mod):
        if path and not path.is_file():parser.error(f"Input file does not exist: {path}")
    if args.report:args.report.parent.mkdir(parents=True,exist_ok=True)
    commands=[];ok=True;media_tested=independent_tested=package_tested=migration_tested=False
    environment=os.environ.copy()
    # LeakSanitizer cannot operate under debugger/ptrace; ASan and UBSan remain enabled.
    environment.setdefault("ASAN_OPTIONS","detect_leaks=0")
    with tempfile.TemporaryDirectory(prefix="dkc1-port-unit-") as t:
        temp=Path(t);java=temp/"java";java.mkdir()
        evidence=args.report.parent if args.report else temp
        def run(name,command,cwd=None):
            nonlocal ok
            result=subprocess.run([str(x) for x in command],cwd=cwd,env=environment,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            print("\n==",name,"==\n"+result.stdout,flush=True)
            commands.append({"name":name,"exit_code":result.returncode,"output":result.stdout})
            ok=ok and result.returncode==0
            return result.returncode==0
        cc=shutil.which("cc") or shutil.which("clang")
        if not cc or not shutil.which("javac") or not shutil.which("java"):
            print("Tests require a host C compiler and JDK 17+",file=sys.stderr);return 2
        core=ANDROID.parent/"snesrecomp/runner/src"
        common=[cc,"-std=c11","-Wall","-Wextra","-Werror","-fsanitize=address,undefined","-fno-omit-frame-pointer","-g","-I",ANDROID/"native"]
        binary=temp/"test_platform"
        if run("C unit test compilation (host, not Android)",common+[
                ANDROID/"native/android_platform.c",ANDROID/"tests/test_platform.c","-lm","-o",binary]):
            run("C utilities with ASan/UBSan",[binary])
        music=temp/"test_music_rewind"
        if run("Desktop MSU-1 and rewind compilation",common+["-D_POSIX_C_SOURCE=200809L","-I",ANDROID.parent/"runner",
                ANDROID.parent/"runner/dkc1_msu1.c",ANDROID.parent/"runner/desktop_rewind.c",ANDROID/"tests/test_music_rewind.c","-o",music]):
            run("Desktop music and rewind runtime tests",[music])
        # Compile the restricted Lua core once. Historical character C units are
        # excluded from these production-runtime tests.
        lua=ANDROID/"third_party_runtime/lua/src"
        excluded={"lua.c","luac.c","linit.c","liolib.c","loslib.c","loadlib.c","ldblib.c","lcorolib.c","lutf8lib.c"}
        lua_sources=sorted(p for p in lua.glob("*.c") if p.name not in excluded)
        objects=temp/"lua-objects";objects.mkdir()
        lua_ready=bool(lua_sources) and run("Bounded Lua core compilation",[
            cc,"-std=c11","-O1","-g","-fsanitize=address,undefined","-fno-omit-frame-pointer",
            "-Dluai_makeseed(L)=0x444b4331u","-I",lua,"-c",*lua_sources],cwd=objects)
        if not lua_sources:
            ok=False;commands.append({"name":"Bounded Lua core compilation","exit_code":1,"output":"Missing vendored Lua sources"})
        if lua_ready:
            lua_objects=sorted(objects.glob("*.o"));script=temp/"test_mod_script"
            if run("Generic mod VM test compilation",common+["-I",lua,
                    ANDROID/"native/mod_script.c",ANDROID/"tests/test_mod_script.c",*lua_objects,"-lm","-o",script]):
                run("Independent scripts: quotas, capabilities, callbacks and faults",[script])
            bridge=temp/"test_addon_runtime"
            if run("Generic game capability bridge compilation",common+["-I",lua,"-I",core,
                    ANDROID/"native/mod_script.c",ANDROID/"native/mod_media.c",ANDROID/"native/addon_runtime.c",
                    core/"sha256.c",ANDROID/"tests/test_addon_runtime.c",*lua_objects,"-lm","-o",bridge]):
                run("Independent runtime: choices, script behavior, rollback and OAM restoration",[bridge])
        media=temp/"test_mod_media"
        if run("Generic media test and historical PCM oracle compilation",common+["-I",core,
                ANDROID/"native/mod_media.c",ANDROID/"tests/legacy/sonic_audio.c",
                ANDROID/"tests/test_mod_media.c","-lm","-o",media]):
            media_tested=run("Generic media bounds, transactions, rendering and mixing",[media]+([args.sonic_atlas] if args.sonic_atlas else [])) and bool(args.sonic_atlas)
        sources=ANDROID/"app/src/main/java/com/ylports/dkc1recomp"
        production=["PadModel","RomVerifier","SaveBackup","MusicPack","VisualMod","ModJson","ModRegions","RuntimeMod","NativeModule","ContentMods"]
        tests=["RuntimeModTests","ChoiceModTests","ContentModTests","ContentTests","PortTests","BackupTests","IndependentModTests","ActualPackageTests","ActualMigrationTests"]
        java_ready=run("Pure-Java unit test compilation",["javac","--release","17","-d",java,
            *[sources/(name+".java") for name in production],*[ANDROID/"tests"/(name+".java") for name in tests]])
        def java_test(name,class_name,arguments=()):
            return run(name,["java","-ea","-cp",java,"com.ylports.dkc1recomp."+class_name,*arguments])
        if java_ready:
            java_test("Java controls and ROM rejection","PortTests")
            java_test("Java backup security and uniform layout","BackupTests")
            java_test("MSU-1 pack and profile security","ContentTests")
            integration=[args.rom] if args.rom else []
            if args.spanish_mod:integration.append(args.spanish_mod)
            java_test("Mod choice parsing and save profile compatibility","ChoiceModTests",integration)
            java_test("Generic script bundle and legacy descriptor validation","RuntimeModTests")
            java_test("Strict JSON and package rejection tests","ContentModTests",integration if args.spanish_mod else [])
            if args.rom:
                independent_args=list(integration)
                if args.spanish_mod:independent_args.append(evidence/"independent-mod-java.json")
                independent_tested=java_test("Independent mod import and exact profile migration","IndependentModTests",independent_args)
            if args.independent_mod:
                package_tested=java_test("Actual independent mod and Spanish package integration","ActualPackageTests",
                    [args.rom,args.spanish_mod,args.independent_mod,evidence/"actual-package-java.json"])
            if args.legacy_mod:
                migration_tested=java_test("Actual previous package and all save profile migrations","ActualMigrationTests",
                    [args.rom,args.spanish_mod,args.legacy_mod,args.independent_mod,evidence/"actual-migration-java.json"])
        mod=temp/"test_content_mod"
        # Preserve the existing validator's compiler contract; its compact
        # legacy formatting is unrelated to the independent-runtime change.
        content_flags=[flag for flag in common if flag not in ("-Wall","-Wextra","-Werror")]
        if run("Native data-mod validator compilation",content_flags+["-D_POSIX_C_SOURCE=200809L","-I",core,
                ANDROID/"native/content_mod.c",core/"sha256.c",ANDROID/"tests/test_content_mod.c","-o",mod]):
            run("Native data-mod transaction and corrupt input tests",[mod])
        run("Content-mod authoring tools",[sys.executable,ANDROID/"tests/test_mod_tools.py"])
        run("Independent script package authoring",[sys.executable,ANDROID/"tests/test_script_packer.py"])
        run("Python build-tool and static contract tests",[sys.executable,ANDROID/"tests/test_tools.py"])
        run("Reviewed interpreter patch identity guard",[sys.executable,ANDROID/"tests/test_engine_compat.py"])
    report={"scope":"Host-side unit and optional real-package integration tests only","all_executed_tests_passed":ok,
        "android_apk_built":False,"android_ndk_compile_tested":False,"retail_rom_import_tested":independent_tested,
        "gameplay_tested":False,"device_tested":False,"actual_media_differential_tested":media_tested,
        "actual_sonic_atlas_audio_tested":media_tested,
        "sonic_atlas_sha256":hashlib.sha256(args.sonic_atlas.read_bytes()).hexdigest() if args.sonic_atlas else None,
        "independent_mod_java_tested":independent_tested,"actual_package_integration_tested":package_tested,
        "actual_legacy_profile_migration_tested":migration_tested,
        "sanitizers":["AddressSanitizer","UndefinedBehaviorSanitizer"],"leak_sanitizer":False,"tests":commands}
    if args.report:args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    return 0 if ok else 1
if __name__=="__main__":raise SystemExit(main())

#include "sonic_sfx_hook.h"
#include "cpu_state.h"
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

RecompReturn __wrap_APU_SubmitCommand_M0X0(CpuState *cpu);
RecompReturn __wrap_APU_SubmitCommand_M1X0(CpuState *cpu);
static bool enabled;
static unsigned submitted, calls, events;
static RecompReturn return_value;
bool SonicModEnabled(void) { return enabled; }
void SonicAudioEvents(uint32_t value) { events |= value; }
static RecompReturn FakeOriginal(CpuState *cpu) {
  calls++; submitted = cpu->X;
  cpu->A = (uint16_t)((cpu->A & 0xff00) | 0x81);
  cpu->S += 3;
  cpu->cycles += 47;
  cpu->master_cycles += 282;
  return return_value;
}
RecompReturn __real_APU_SubmitCommand_M0X0(CpuState *cpu) { return FakeOriginal(cpu); }
RecompReturn __real_APU_SubmitCommand_M1X0(CpuState *cpu) { return FakeOriginal(cpu); }
static unsigned Expected(unsigned command) {
  static const unsigned voices[] = {5,0x13,0x3e,0x3f,0x40,0x41,0x43,0x44,0x45,0x46,0x5d,0x5e};
  if ((command >> 8) < 4 || (command >> 8) > 6) return command;
  for (unsigned i=0; i<sizeof voices/sizeof *voices; i++)
    if ((command & 255) == voices[i]) return command & 0xff00;
  return command;
}
int main(void) {
  unsigned changed = 0, trials = 0;
  for (unsigned mode=0; mode<2; mode++) {
    for (unsigned on=0; on<2; on++) {
      enabled = on;
      for (unsigned command=0; command<65536; command++) {
        CpuState state = {0};
        state.X = command; state.Y = 0x1234; state.A = 0x6a55;
        state.S = 0x1fd; state.D = 0; state.DB = 0x80; state.PB = 0x8a;
        state.P = 0x83; state.m_flag = mode; state._flag_C = 1;
        state._flag_N = 1; state.cycles = 17; state.master_cycles = 102;
        CpuState expected = state;
        return_value = RECOMP_RETURN_NORMAL;
        FakeOriginal(&expected);
        calls = events = 0;
        RecompReturn result = mode ? __wrap_APU_SubmitCommand_M1X0(&state)
                                  : __wrap_APU_SubmitCommand_M0X0(&state);
        assert(result == RECOMP_RETURN_NORMAL && calls == 1);
        assert(memcmp(&state, &expected, sizeof state) == 0);
        unsigned wanted = enabled ? Expected(command) : command;
        assert(submitted == wanted);
        bool hurt = enabled && wanted != command && ((command & 255)==0x43 || (command & 255)==0x46);
        assert(events == (hurt ? 16u : 0u));
        trials++;
        if (mode==0 && on && wanted != command) changed++;
      }
    }
  }
  enabled = true;
  CpuState state = {0}; state.X = 0x543;
  return_value = RECOMP_RETURN_SKIP_1; calls = events = 0;
  assert(__wrap_APU_SubmitCommand_M0X0(&state)==RECOMP_RETURN_SKIP_1);
  assert(events==0 && calls==1 && state.X==0x543);
  assert(changed == 36);
  printf("{\"passed\":true,\"wrapper_command_cases\":%u,\"mapped_commands\":%u,\"cpu_flags_stack_cycles_preserved\":true,\"non_sfx_commands_untouched\":true}\n",trials,changed);
  return 0;
}

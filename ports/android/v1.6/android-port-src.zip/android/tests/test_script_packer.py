#!/usr/bin/env python3
"""Independent source-package authoring checks; no ROM or Android compiler needed."""
from pathlib import Path
import importlib.util
import json
import struct
import tempfile
import unittest
import zipfile

ANDROID=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pack_script_mod',ANDROID/'tools/pack_script_mod.py')
packer=importlib.util.module_from_spec(spec);spec.loader.exec_module(packer)


class ScriptPackerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.manifest=self.root/'manifest.json';self.script=self.root/'main.lua';self.output=self.root/'Example.dkcmod'
        self.data={'id':'test.independent','name':'Example','version':'1.0','category':'data','choices':[{'id':'style','label':'Style','default':'a','options':[{'id':'a','label':'A','patches':[]},{'id':'b','label':'B','patches':[]}]}]}
        self.write_manifest();self.script.write_text('return {}\n',encoding='utf-8')
    def tearDown(self):self.temp.cleanup()
    def write_manifest(self):self.manifest.write_text(json.dumps(self.data),encoding='utf-8')
    def build(self,**kw):return packer.build(self.manifest,self.script,self.output,**kw)
    def test_reproducible_script_only_package(self):
        (self.root/'README.md').write_text('Independent source example.\n')
        first=self.build();original=self.output.read_bytes();second=self.build()
        self.assertEqual(original,self.output.read_bytes());self.assertEqual(first['package_sha256'],second['package_sha256']);self.assertFalse(first['gameplay_tested'])
        with zipfile.ZipFile(self.output) as archive:
            self.assertEqual(set(archive.namelist()),{'manifest.json','runtime/mod.bin','README.txt'})
            manifest=json.loads(archive.read('manifest.json'));runtime=archive.read('runtime/mod.bin')
            self.assertEqual(manifest['choices'],self.data['choices']);self.assertEqual(manifest['format'],4);self.assertEqual(manifest['min_port'],105)
            self.assertEqual(manifest['base_sha256'],packer.BASE_SHA);self.assertEqual(manifest['runtime']['sha256'],packer.sha(runtime))
            self.assertEqual(struct.unpack_from('<8sIII',runtime),(b'DKCLUA1\0',len(self.script.read_bytes()),0,0));self.assertEqual(runtime[20:],self.script.read_bytes())
    def test_script_source_limits_preserve_output(self):
        self.build();original=self.output.read_bytes()
        for invalid in [b'',b'\x1bLua',b'return {}\0',b'\xff',b'a'*(packer.MAX_SCRIPT+1)]:
            self.script.write_bytes(invalid)
            with self.subTest(size=len(invalid)),self.assertRaises((ValueError,UnicodeError)):self.build()
            self.assertEqual(self.output.read_bytes(),original)
    def test_invalid_choices_and_duplicate_json_keys(self):
        base=json.loads(json.dumps(self.data))
        for transform in [lambda m:m.update(min_port=104),lambda m:m.update(format=True),lambda m:m['choices'][0].update(default='missing'),lambda m:m['choices'][0]['options'][1].update(id='a'),lambda m:m['choices'][0].update(id='../escape'),lambda m:m.update(save_profile_sha256='bad')]:
            self.data=json.loads(json.dumps(base));transform(self.data);self.write_manifest()
            with self.assertRaises(ValueError):self.build()
        self.manifest.write_text('{"id":"one","id":"two"}')
        with self.assertRaises(ValueError):self.build()
        self.assertFalse(self.output.exists())
    def test_resources_validated_and_packed(self):
        atlas=struct.pack('<8sIIII',b'DKCATL1\0',2,2,1,2)+bytes([0,0,0,0,255,128,64,255])+bytes([0,1,1,0])
        audio=struct.pack('<8sI',b'DKCSND1\0',1)+struct.pack('<IIII',1,8000,1,3)+struct.pack('<hhh',0,1000,-1000)
        atlas_path=self.root/'atlas.bin';audio_path=self.root/'audio.bin';atlas_path.write_bytes(atlas);audio_path.write_bytes(audio)
        report=self.build(atlas_path=atlas_path,audio_path=audio_path);self.assertEqual(report['atlas_bytes'],len(atlas));self.assertEqual(report['audio_bytes'],len(audio))
        with zipfile.ZipFile(self.output) as archive:
            data=archive.read('runtime/mod.bin');self.assertEqual(data[20+len(self.script.read_bytes()):],atlas+audio)
        for invalid in [atlas[:-1],atlas+b'?',atlas[:24]+bytes([0])*8+bytes([0,1,1,2])]:
            atlas_path.write_bytes(invalid)
            with self.assertRaises(ValueError):self.build(atlas_path=atlas_path,audio_path=audio_path)
        atlas_path.write_bytes(atlas)
        for invalid in [audio[:-1],audio+b'?',audio[:12]+struct.pack('<I',3)+audio[16:]]:
            audio_path.write_bytes(invalid)
            with self.assertRaises(ValueError):self.build(atlas_path=atlas_path,audio_path=audio_path)
    def test_declared_data_patch_and_traversal_rejection(self):
        path=self.root/'patches/change.bin';path.parent.mkdir();path.write_bytes(b'X')
        patch={'offset':65536,'size':1,'file':'patches/change.bin','sha256':packer.sha(b'X'),'expected_sha256':packer.sha(b'Y'),'kind':'data'}
        self.data['patches']=[patch];self.write_manifest();self.build()
        with zipfile.ZipFile(self.output) as archive:self.assertEqual(archive.read(patch['file']),b'X')
        patch['file']='patches/../change.bin';self.write_manifest()
        with self.assertRaises(ValueError):self.build()
        patch['file']='patches/change.bin';patch['sha256']='0'*64;self.write_manifest()
        with self.assertRaises(ValueError):self.build()
    def test_code_is_not_executed_and_old_runtime_is_recomputed(self):
        sentinel=self.root/'should-not-exist';self.script.write_text(f'os.execute("touch {sentinel}")\nreturn {{}}\n')
        self.data['runtime']={'engine':'old','sha256':'invalid'};self.write_manifest();self.build();self.assertFalse(sentinel.exists())
        with zipfile.ZipFile(self.output) as archive:self.assertEqual(json.loads(archive.read('manifest.json'))['runtime']['engine'],'dkc-lua-v1')
    def test_template_builds_without_private_inputs(self):
        template=ANDROID/'mods/independent-template'
        report=packer.build(template/'manifest.json',template/'main.lua',self.output)
        self.assertEqual(report['atlas_bytes'],0);self.assertEqual(report['audio_bytes'],0)
        with zipfile.ZipFile(self.output) as archive:
            m=json.loads(archive.read('manifest.json'));self.assertEqual(m['choices'][0]['default'],'original');self.assertEqual(len(m['choices'][0]['options']),2)
            self.assertIn('LICENSE.txt',archive.namelist());self.assertIn('README.txt',archive.namelist())


if __name__=='__main__':unittest.main(verbosity=2)

package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Delivery integration against private user ROM, previous Spanish and new Sonic packages. */
public final class ActualPackageTests {
    private static int checks;
    interface Operation {void run()throws Exception;}
    private static void check(boolean condition){checks++;if(!condition)throw new AssertionError("check "+checks);}
    private static void rejects(Operation operation)throws Exception {boolean rejected=false;try{operation.run();}catch(IOException expected){rejected=true;}check(rejected);}
    private static String sha(byte[] data)throws Exception{return ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(data));}
    private static ContentMods.Info install(File root,File cache,Path path)throws Exception {try(InputStream in=Files.newInputStream(path)){return ContentMods.install(root,cache,in);}}
    public static void main(String[] args)throws Exception {
        if(args.length!=4)throw new IllegalArgumentException("clean ROM, Spanish mod, Sonic mod, JSON report");
        Path tmp=Files.createTempDirectory("dkc-actual-packages-");
        try{
            File root=tmp.resolve("root").toFile(),cache=tmp.resolve("cache").toFile();Path game=tmp.resolve("root/game");Files.createDirectories(game);byte[] rom=Files.readAllBytes(Path.of(args[0]));Files.write(game.resolve("dkc1.sfc"),rom);
            byte[] sram={1,2,3,4};Path originalSram=game.resolve("dkc1.srm");Files.write(originalSram,sram);
            ContentMods.Info spanish=install(root,cache,Path.of(args[1])),sonic=install(root,cache,Path.of(args[2]));check(ContentMods.active(root).isEmpty());check(ContentMods.installed(root).size()==2);
            check(sonic.patchCount==0);check(sonic.runtime!=null);check(sonic.runtime.size>4*1024*1024);check(ContentMods.selected(root,sonic).get("characters").equals("both"));
            ContentMods.toggle(root,sonic.digest);ContentMods.Session onlySonic=ContentMods.prepare(root);check(onlySonic.runtimeOptions.equals("characters=both\n"));check(Files.size(Path.of(onlySonic.plan))==76);
            String[] modes={"both","sonic","tails"};Set<String> standaloneKeys=new HashSet<>();
            for(int i=0;i<3;i++){ContentMods.select(root,sonic.digest,"characters",modes[i]);ContentMods.Session session=ContentMods.prepare(root);check(session.runtimeOptions.equals("characters="+modes[i]+"\n"));check(session.key.equals(ContentMods.activeKey(root)));check(session.runtimeSha.equals(sonic.runtime.sha));standaloneKeys.add(session.key);}
            check(standaloneKeys.size()==3);ContentMods.toggle(root,sonic.digest);check(ContentMods.prepare(root).key.isEmpty());
            ContentMods.toggle(root,spanish.digest);ContentMods.Session es=ContentMods.prepare(root);String expectedLegacy=sha((spanish.digest+"\n").getBytes(StandardCharsets.UTF_8)).substring(0,16);check(es.key.equals(expectedLegacy));check(es.runtimeMode==-1);
            Path spanishSave=game.resolve("quicksave-4x3-mod-"+es.key+".state");Files.write(spanishSave,new byte[]{9,8,7});
            ContentMods.toggle(root,sonic.digest);check(ContentMods.prepare(root).runtimeOptions.equals("characters=tails\n"));Set<String> combinedKeys=new HashSet<>();
            for(int i=0;i<3;i++){ContentMods.select(root,sonic.digest,"characters",modes[i]);ContentMods.Session session=ContentMods.prepare(root);check(session.runtimeOptions.equals("characters="+modes[i]+"\n"));check(session.planSha.equals(es.planSha));check(!session.key.equals(es.key));check(!standaloneKeys.contains(session.key));combinedKeys.add(session.key);}
            check(combinedKeys.size()==3);rejects(()->ContentMods.uninstall(root,sonic.digest));
            Path resource=sonic.runtime.source.toPath();byte[] data=Files.readAllBytes(resource),changed=data.clone();changed[changed.length-1]^=1;Files.write(resource,changed);rejects(()->ContentMods.prepare(root));Files.write(resource,data);check(ContentMods.prepare(root).runtimeOptions.equals("characters=tails\n"));
            ContentMods.toggle(root,sonic.digest);check(ContentMods.prepare(root).key.equals(es.key));check(Files.exists(spanishSave));check(Arrays.equals(Files.readAllBytes(originalSram),sram));
            ContentMods.disableAll(root);check(ContentMods.prepare(root).key.isEmpty());check(ContentMods.prepare(root).runtimeMode==-1);check(Arrays.equals(Files.readAllBytes(game.resolve("dkc1.sfc")),rom));
            ContentMods.uninstall(root,sonic.digest);ContentMods.Info reinstalled=install(root,cache,Path.of(args[2]));check(ContentMods.selected(root,reinstalled).get("characters").equals("tails"));
            String report="{\n  \"scope\": \"Host Java actual-package integration; no Android gameplay claim\",\n  \"passed\": true,\n  \"assertions\": "+checks+",\n  \"rom_sha256\": \""+sha(rom)+"\",\n  \"sonic_package_sha256\": \""+sonic.digest+"\",\n  \"spanish_package_sha256\": \""+spanish.digest+"\",\n  \"spanish_legacy_save_key\": \""+es.key+"\",\n  \"spanish_patch_count\": "+spanish.patchCount+",\n  \"runtime_bytes\": "+sonic.runtime.size+",\n  \"all_three_modes_persisted\": true,\n  \"selections_have_distinct_save_profiles\": true,\n  \"spanish_plan_unchanged_with_sonic\": true,\n  \"previous_profile_restored_when_disabled\": true,\n  \"original_rom_and_sram_unchanged\": true,\n  \"corrupt_runtime_rejected\": true\n}\n";
            Files.writeString(Path.of(args[3]),report);System.out.println("Actual package integration passed: "+checks+" assertions.");
        }finally{try(java.util.stream.Stream<Path> paths=Files.walk(tmp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}}
    }
}

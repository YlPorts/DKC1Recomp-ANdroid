package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Selector regressions, including optional integration against the user's clean ROM. */
public final class ChoiceModTests {
    private static int checks;
    private static final String ID="a".repeat(64);
    interface Operation {void run()throws Exception;}
    private static void check(boolean condition){checks++;if(!condition)throw new AssertionError("check "+checks);}
    private static void rejects(Operation operation)throws Exception {boolean rejected=false;try{operation.run();}catch(IOException expected){rejected=true;}check(rejected);}
    private static byte[] utf8(String text){return text.getBytes(StandardCharsets.UTF_8);}
    private static String sha(byte[] data)throws Exception{return ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(data));}
    private static String patch(int offset,String path,byte[] before,byte[] after)throws Exception {
        return "{\"offset\":"+offset+",\"size\":"+after.length+",\"file\":\""+path+"\",\"sha256\":\""+sha(after)+"\",\"expected_sha256\":\""+sha(before)+"\",\"kind\":\"graphics\"}";
    }
    private static String manifest(String id,String basePatches,String choices,String runtime){
        return "{\"format\":3,\"min_port\":103,\"id\":\""+id+"\",\"name\":\"Choices\",\"version\":\"1\",\"category\":\"graphics\",\"base_sha256\":\""+ContentMods.BASE_SHA+"\",\"patches\":["+basePatches+"],\"choices\":["+choices+"]"+(runtime.isEmpty()?"":",\"runtime\":"+runtime)+"}";
    }
    private static String choice(String id,String original,String modified,String patches){
        return "{\"id\":\""+id+"\",\"label\":\"Personajes\",\"default\":\""+original+"\",\"options\":[{\"id\":\""+original+"\",\"label\":\"Original\",\"patches\":[]},{\"id\":\""+modified+"\",\"label\":\"Modificado\",\"patches\":["+patches+"]}]}";
    }
    private static void writePackage(Path dir,Map<String,byte[]> files)throws Exception {for(Map.Entry<String,byte[]> e:files.entrySet()){Path file=dir.resolve(e.getKey());Files.createDirectories(file.getParent());Files.write(file,e.getValue());}}
    private static byte[] zip(Map<String,byte[]> files)throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(bytes)){for(Map.Entry<String,byte[]> e:files.entrySet()){ZipEntry entry=new ZipEntry(e.getKey());entry.setTime(0);z.putNextEntry(entry);z.write(e.getValue());z.closeEntry();}}return bytes.toByteArray();
    }
    private static ContentMods.Info install(File root,File cache,Map<String,byte[]> files)throws Exception{return ContentMods.install(root,cache,new ByteArrayInputStream(zip(files)));}
    private static Map<String,byte[]> files(String manifest,byte[] patch){Map<String,byte[]> files=new LinkedHashMap<>();files.put("manifest.json",utf8(manifest));files.put("sprites/hero.bin",patch);return files;}
    public static void main(String[] args)throws Exception {
        Path tmp=Files.createTempDirectory("dkc-choices-");
        try{
            File root=tmp.resolve("root").toFile();Path dir=tmp.resolve("root/mods-v2/packages/"+ID);byte[] original={0},modified={42};
            String change=patch(65536,"sprites/hero.bin",original,modified),choices=choice("hero","original","modified",change),good=manifest("test.choices","",choices,"");
            writePackage(dir,files(good,modified));ContentMods.Info info=ContentMods.installed(root).get(0);
            check(info.choices.size()==1);check(info.choices.get(0).options.size()==2);check(info.choices.get(0).options.get(1).patchCount==1);
            check(ContentMods.selected(root,info).get("hero").equals("original"));
            Files.writeString(tmp.resolve("root/mods-v2/enabled.txt"),ID+"\n");String defaultKey=ContentMods.activeKey(root);check(defaultKey.length()==16);
            Path selection=tmp.resolve("root/mods-v2/selections/"+ID+".txt");Files.createDirectories(selection.getParent());Files.writeString(selection,"hero=modified\n");
            check(ContentMods.selected(root,info).get("hero").equals("modified"));check(!ContentMods.activeKey(root).equals(defaultKey));
            Files.writeString(selection,"hero=original\n");check(ContentMods.activeKey(root).equals(defaultKey));
            for(String invalid:new String[]{"hero=missing\n","other=original\n","hero=original\nhero=modified\n","hero=original=modified\n","../x=original\n"}){
                Files.writeString(selection,invalid);rejects(()->ContentMods.selected(root,info));check(ContentMods.activeKey(root).equals("invalid"));
            }
            Files.delete(selection);
            for(String[] replacement:new String[][]{
                {"\"min_port\":103","\"min_port\":102"},{"\"format\":3","\"format\":2"},
                {"\"default\":\"original\"","\"default\":\"missing\""},{"\"id\":\"modified\"","\"id\":\"original\""},
                {"\"id\":\"hero\"","\"id\":\"hero:bad\""},{"\"label\":\"Personajes\"","\"label\":\"Personajes\",\"script\":\"run\""},
                {"\"options\":[","\"options\":[] ,\"unused\":["},{"\"patches\":["+change+"]","\"patches\":[]"},
                {"\"choices\":["+choices+"]","\"choices\":["+choices+","+choices+"]"}}){
                Files.writeString(dir.resolve("manifest.json"),good.replace(replacement[0],replacement[1]));rejects(()->ContentMods.installed(root));
            }
            Files.writeString(dir.resolve("manifest.json"),good);
            String legacy=good.replace("\"format\":3","\"format\":2").replace("\"min_port\":103","\"min_port\":102").replace("\"patches\":[],\"choices\":["+choices+"]","\"patches\":["+change+"]");
            Files.writeString(dir.resolve("manifest.json"),legacy);check(ContentMods.installed(root).get(0).choices.isEmpty());check(ContentMods.activeKey(root).equals(sha(utf8(ID+"\n")).substring(0,16)));
            ContentMods.disableAll(root);check(ContentMods.activeKey(root).isEmpty());
            if(args.length>0)integration(tmp.resolve("integration"),Files.readAllBytes(Path.of(args[0])));
            if(args.length>1)legacyIntegration(tmp.resolve("legacy"),Files.readAllBytes(Path.of(args[0])),Files.readAllBytes(Path.of(args[1])));
            System.out.println("Choice-mod tests passed: "+checks+" assertions. Retail integration="+(args.length>0));
        }finally{try(java.util.stream.Stream<Path> paths=Files.walk(tmp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}}
    }
    private static void integration(Path dir,byte[] rom)throws Exception {
        check(sha(rom).equals(ContentMods.BASE_SHA));File root=dir.resolve("root").toFile(),cache=dir.resolve("cache").toFile();Path game=dir.resolve("root/game");Files.createDirectories(game);Files.write(game.resolve("dkc1.sfc"),rom);
        byte[] original={rom[65536]},modified={(byte)(rom[65536]^7)};String patch=patch(65536,"sprites/hero.bin",original,modified);
        String option=choice("hero","original","modified",patch),manifest=manifest("test.integration","",option,"");Map<String,byte[]> pkg=files(manifest,modified);
        ContentMods.Info info=install(root,cache,pkg);check(ContentMods.active(root).isEmpty());ContentMods.toggle(root,info.digest);ContentMods.Session initial=ContentMods.prepare(root);
        check(initial.key.equals(ContentMods.activeKey(root)));check(initial.runtimeMode==-1);byte[] initialPlan=Files.readAllBytes(Path.of(initial.plan));check(initialPlan.length==76);check(sha(initialPlan).equals(initial.planSha));
        ContentMods.select(root,info.digest,"hero","modified");ContentMods.Session selected=ContentMods.prepare(root);check(!selected.key.equals(initial.key));check(selected.key.equals(ContentMods.activeKey(root)));
        byte[] selectedPlan=Files.readAllBytes(Path.of(selected.plan));check(selectedPlan.length==117);check(selectedPlan[selectedPlan.length-1]==modified[0]);check(!selected.planSha.equals(initial.planSha));
        Path save=game.resolve("quicksave-4x3-mod-"+selected.key+".state");Files.write(save,new byte[]{1,2,3});
        ContentMods.select(root,info.digest,"hero","original");check(ContentMods.prepare(root).key.equals(initial.key));ContentMods.select(root,info.digest,"hero","modified");check(ContentMods.prepare(root).key.equals(selected.key));check(Files.exists(save));
        rejects(()->ContentMods.select(root,info.digest,"missing","modified"));rejects(()->ContentMods.select(root,info.digest,"hero","missing"));check(ContentMods.prepare(root).key.equals(selected.key));
        ContentMods.disableAll(root);ContentMods.uninstall(root,info.digest);check(Files.exists(save));ContentMods.Info reinstalled=install(root,cache,pkg);check(reinstalled.digest.equals(info.digest));check(ContentMods.selected(root,reinstalled).get("hero").equals("modified"));ContentMods.toggle(root,info.digest);check(ContentMods.prepare(root).key.equals(selected.key));
        // A conflicting alternative is refused without overwriting the old selection.
        ContentMods.select(root,info.digest,"hero","original");String conflictManifest=manifest("test.conflict",patch,choice("style","one","two",""),"");
        ContentMods.Info conflict=install(root,cache,files(conflictManifest,modified));ContentMods.toggle(root,conflict.digest);String beforeKey=ContentMods.activeKey(root);
        rejects(()->ContentMods.select(root,info.digest,"hero","modified"));check(ContentMods.selected(root,info).get("hero").equals("original"));check(ContentMods.activeKey(root).equals(beforeKey));
        ContentMods.disableAll(root);
        // Verify preimages of inactive alternatives at import time too.
        Map<String,byte[]> wrong=files(manifest.replace("\"expected_sha256\":\""+sha(original)+"\"","\"expected_sha256\":\""+sha(modified)+"\""),modified);rejects(()->install(root,cache,wrong));
        // Runtime-only packages carry a zero-patch ROM plan and three distinct persisted profiles.
        byte[] script=utf8("return {}\n"),runtime=new byte[20+script.length];System.arraycopy(utf8("DKCLUA1"),0,runtime,0,7);runtime[8]=(byte)script.length;System.arraycopy(script,0,runtime,20,script.length);
        String runtimeChoice="{\"id\":\"characters\",\"label\":\"Personajes\",\"default\":\"both\",\"options\":[{\"id\":\"both\",\"label\":\"Sonic y Tails\",\"patches\":[]},{\"id\":\"sonic\",\"label\":\"Sonic\",\"patches\":[]},{\"id\":\"tails\",\"label\":\"Tails\",\"patches\":[]}]}";
        String descriptor="{\"engine\":\"dkc-lua-v1\",\"file\":\"runtime/sonic.bin\",\"size\":"+runtime.length+",\"sha256\":\""+sha(runtime)+"\"}";
        Map<String,byte[]> runtimeFiles=new LinkedHashMap<>();runtimeFiles.put("manifest.json",utf8(manifest("test.runtime","",runtimeChoice,descriptor).replace("\"format\":3","\"format\":4").replace("\"min_port\":103","\"min_port\":105")));runtimeFiles.put("runtime/sonic.bin",runtime);
        ContentMods.Info sonic=install(root,cache,runtimeFiles);ContentMods.toggle(root,sonic.digest);Set<String> keys=new HashSet<>();String[] modes={"both","sonic","tails"};
        for(int i=0;i<modes.length;i++){ContentMods.select(root,sonic.digest,"characters",modes[i]);ContentMods.Session session=ContentMods.prepare(root);check(session.runtimeMode==-1);check(session.runtimeOptions.equals("characters="+modes[i]+"\n"));check(session.runtimeSha.equals(sha(runtime)));check(new File(session.runtimePath).isFile());check(Files.size(Path.of(session.plan))==76);keys.add(session.key);}
        check(keys.size()==3);check(Arrays.equals(Files.readAllBytes(game.resolve("dkc1.sfc")),rom));
        runtimeFiles.put("manifest.json",utf8(manifest("test.runtime_other","",runtimeChoice,descriptor).replace("\"format\":3","\"format\":4").replace("\"min_port\":103","\"min_port\":105")));ContentMods.Info otherRuntime=install(root,cache,runtimeFiles);String runtimeKey=ContentMods.activeKey(root);rejects(()->ContentMods.toggle(root,otherRuntime.digest));check(ContentMods.activeKey(root).equals(runtimeKey));
        ContentMods.disableAll(root);check(ContentMods.prepare(root).runtimeMode==-1);check(Files.exists(save));
    }
    private static void legacyIntegration(Path dir,byte[] rom,byte[] pkg)throws Exception {
        File root=dir.resolve("root").toFile(),cache=dir.resolve("cache").toFile();Path game=dir.resolve("root/game");Files.createDirectories(game);Files.write(game.resolve("dkc1.sfc"),rom);
        ContentMods.Info info=ContentMods.install(root,cache,new ByteArrayInputStream(pkg));check(info.choices.isEmpty());check(info.runtime==null);check(info.patchCount>0);check(info.locale.equals("es"));
        ContentMods.toggle(root,info.digest);ContentMods.Session session=ContentMods.prepare(root);String legacyKey=sha(utf8(sha(pkg)+"\n")).substring(0,16);
        check(session.key.equals(legacyKey));check(ContentMods.activeKey(root).equals(legacyKey));check(session.runtimeMode==-1);check(sha(Files.readAllBytes(Path.of(session.plan))).equals(session.planSha));
        ContentMods.disableAll(root);check(ContentMods.prepare(root).key.isEmpty());ContentMods.toggle(root,info.digest);check(ContentMods.prepare(root).key.equals(legacyKey));check(Arrays.equals(Files.readAllBytes(game.resolve("dkc1.sfc")),rom));
    }
}

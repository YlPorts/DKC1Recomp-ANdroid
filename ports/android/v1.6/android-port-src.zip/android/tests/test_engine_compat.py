#!/usr/bin/env python3
"""Fail-closed acceptance of the reviewed interpreter patch (no real ROM)."""
from pathlib import Path
import hashlib, importlib.util, tempfile, unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('build_android',Path(__file__).resolve().parents[1]/'tools/build_android.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)

class EnginePatchTests(unittest.TestCase):
    def test_only_exact_reviewed_files(self):
        with tempfile.TemporaryDirectory(prefix='dkc-engine-guard-') as directory:
            root=Path(directory);expected={}
            for name in ('runner/src/snes/interp_bridge.c','runner/src/snes/interp_bridge.h'):
                file=root/name;file.parent.mkdir(parents=True,exist_ok=True)
                file.write_bytes(name.encode());expected[name]=hashlib.sha256(name.encode()).hexdigest()
            changed='\n'.join(expected)
            with patch.object(build,'ENGINE_PATCHED_SHA',expected),patch.object(build,'run',return_value=changed):
                build.verify_engine_compatibility(root)
                (root/next(iter(expected))).write_bytes(b'unknown change')
                with self.assertRaises(RuntimeError):build.verify_engine_compatibility(root)
            for names in ('',changed+'\nrunner/other.c',next(iter(expected))):
                with patch.object(build,'ENGINE_PATCHED_SHA',expected),patch.object(build,'run',return_value=names):
                    with self.assertRaises(RuntimeError):build.verify_engine_compatibility(root)

if __name__=='__main__':unittest.main(verbosity=2)

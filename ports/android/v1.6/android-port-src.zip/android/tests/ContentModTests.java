package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** ROM-independent adversarial tests; optional private retail-ROM integration. */
public final class ContentModTests {
    private static int checks;
    interface Operation { void run() throws Exception; }
    private static void check(boolean value){checks++;if(!value)throw new AssertionError("check "+checks);}
    private static void rejects(Operation op)throws Exception{boolean failed=false;try{op.run();}catch(IOException expected){failed=true;}check(failed);}
    private static String sha(byte[] data)throws Exception{return ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(data));}
    private static byte[] utf8(String s){return s.getBytes(StandardCharsets.UTF_8);}
    private static byte[] zip(Map<String,byte[]> files)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(out)){
            for(Map.Entry<String,byte[]> e:files.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}
        }return out.toByteArray();
    }
    private static Map<String,byte[]> unzip(byte[] bytes)throws Exception{
        Map<String,byte[]> out=new LinkedHashMap<>();try(ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=z.getNextEntry())!=null){out.put(e.getName(),z.readAllBytes());z.closeEntry();}}return out;
    }
    private static void install(File root,File cache,Map<String,byte[]> files)throws Exception{ContentMods.install(root,cache,new ByteArrayInputStream(zip(files)));}
    private static Map<String,byte[]> change(Map<String,byte[]> src,String from,String to){Map<String,byte[]> m=new LinkedHashMap<>(src);m.put("manifest.json",utf8(new String(m.get("manifest.json"),StandardCharsets.UTF_8).replace(from,to)));return m;}
    public static void main(String[] args)throws Exception{
        Path tmp=Files.createTempDirectory("dkc-mod-test-");File root=tmp.resolve("root").toFile(),cache=tmp.resolve("cache").toFile();root.mkdirs();cache.mkdirs();
        try{
            for(String text:new String[]{"", "[]", "{\"a\":1,\"a\":2}","{\"a\":01}","{\"a\":1.5}","{\"a\":1e3}","{\"a\":1,}","{\"a\":[1,]}","{\"a\":truee}","{}x","{\"a\":\"\\u-001\"}","{\"a\":\"\\u+001\"}","{\"a\":\"\\uD800\"}","{\"a\":\"\\uDC00\"}","{\"a\":99999999999999999999999999}","{\"a\":\"\n\"}","{\"a\":"+"[".repeat(14)+"0"+"]".repeat(14)+"}"})rejects(()->ModJson.read(text));
            Map<String,Object> parsed=ModJson.read("{\"text\":\"Espa\\u00f1ol\",\"n\":12,\"a\":[true,null,{}],\"face\":\"\\ud83d\\ude00\"}");
            check(ModJson.string(parsed.get("text")).equals("Español"));check(ModJson.integer(parsed.get("n"))==12);check(ModJson.array(parsed.get("a")).size()==3);
            rejects(()->ModJson.integer(-1L));rejects(()->ModJson.integer(2147483648L));rejects(()->ModJson.integer("1"));rejects(()->ModJson.keys(parsed,"n"));
            check(!ModRegions.allowed(0,16,false));check(!ModRegions.allowed(0x8000,16,false));check(ModRegions.allowed(0x38a50d,16,true));check(!ModRegions.allowed(0x38a50c,2,true));
            check(!ModRegions.allowed(Integer.MAX_VALUE,10,false));check(!ModRegions.allowed(-1,100,false));check(!ModRegions.allowed(0x3c03c8,0,true));
            String name="patches/data.bin";byte[] payload=new byte[]{42};String h=sha(payload);
            String manifest="{\"format\":2,\"min_port\":101,\"id\":\"test.good\",\"name\":\"Test\",\"version\":\"1\",\"category\":\"graphics\",\"base_sha256\":\""+ContentMods.BASE_SHA+"\",\"patches\":[{\"offset\":65536,\"size\":1,\"file\":\""+name+"\",\"sha256\":\""+h+"\",\"expected_sha256\":\""+h+"\",\"kind\":\"graphics\"}]}";
            Map<String,byte[]> good=new LinkedHashMap<>();good.put("manifest.json",utf8(manifest));good.put(name,payload);
            for(String path:new String[]{"../escape","/absolute","x/../../escape","x\\escape","a//b","a/./b","C:/escape"}){Map<String,byte[]> f=new LinkedHashMap<>(good);f.put(path,new byte[]{1});rejects(()->install(root,cache,f));}
            Map<String,byte[]> duplicate=new LinkedHashMap<>(good);duplicate.put("MANIFEST.JSON",utf8(manifest));rejects(()->install(root,cache,duplicate));
            Map<String,byte[]> unknown=new LinkedHashMap<>(good);unknown.put("script.dll",new byte[]{1});rejects(()->install(root,cache,unknown));
            Map<String,byte[]> huge=new LinkedHashMap<>();huge.put("manifest.json",new byte[512*1024+1]);rejects(()->install(root,cache,huge));
            Map<String,byte[]> many=new LinkedHashMap<>(good);for(int i=0;i<513;i++)many.put("x"+i+"/",new byte[0]);rejects(()->install(root,cache,many));
            Map<String,byte[]> directory=new LinkedHashMap<>(good);directory.put("folder/",new byte[]{1});rejects(()->install(root,cache,directory));
            for(String[] pair:new String[][]{{"\"format\":2","\"format\":3"},{"\"min_port\":101","\"min_port\":999"},{"\"offset\":65536","\"offset\":32768"},{"\"size\":1","\"size\":0"},{"\"kind\":\"graphics\"","\"kind\":\"script\""},{"\"category\":\"graphics\"","\"category\":\"translation\""},{"\"name\":\"Test\"","\"name\":\"Test\",\"code\":\"run\""}}){rejects(()->install(root,cache,change(good,pair[0],pair[1])));}
            rejects(()->install(root,cache,good)); // clean base ROM is required
            check(ContentMods.installed(root).isEmpty());check(ContentMods.prepare(root).key.isEmpty());
            rejects(()->ContentMods.toggle(root,"../outside"));check(ContentMods.active(root).isEmpty());
            Files.createDirectories(tmp.resolve("root/mods-v2"));Files.writeString(tmp.resolve("root/mods-v2/enabled.txt"),"invalid");
            rejects(()->ContentMods.prepare(root));check(ContentMods.activeKey(root).equals("invalid"));ContentMods.disableAll(root);check(ContentMods.activeKey(root).isEmpty());
            check(SaveBackup.allowed("game/dkc1-mod-0123456789abcdef.srm"));check(SaveBackup.allowed("game/quicksave-4x3-mod-0123456789abcdef-slot5.state"));check(SaveBackup.allowed("game/autosave-21x9-msu1-mod-0123456789abcdef.state"));
            check(!SaveBackup.allowed("game/dkc1-mod-not-a-hash.srm"));check(!SaveBackup.allowed("mods-v2/plans/payload.bin"));
            if(args.length>=2){
                byte[] rom=Files.readAllBytes(Path.of(args[0]));check(sha(rom).equals(ContentMods.BASE_SHA));Files.createDirectories(tmp.resolve("root/game"));Files.write(tmp.resolve("root/game/dkc1.sfc"),rom);
                byte[] pkg=Files.readAllBytes(Path.of(args[1]));ContentMods.Info info=ContentMods.install(root,cache,new ByteArrayInputStream(pkg));
                // The complete Spanish v1.0 package shipped with Android v1.2
                // contains 48 patches; the initial translation fixture had 2.
                check(info.patchCount==48);check(info.locale.equals("es"));check(ContentMods.active(root).isEmpty());check(ContentMods.installed(root).size()==1);
                ContentMods.toggle(root,info.digest);ContentMods.Session s=ContentMods.prepare(root);check(s.key.length()==16);check(sha(Files.readAllBytes(Path.of(s.plan))).equals(s.planSha));
                Map<String,byte[]> alt=change(unzip(pkg),"ylports.es.inicial","other.es");ContentMods.Info conflict=ContentMods.install(root,cache,new ByteArrayInputStream(zip(alt)));
                rejects(()->ContentMods.toggle(root,conflict.digest));check(ContentMods.activeKey(root).equals(s.key));
                rejects(()->ContentMods.uninstall(root,info.digest));ContentMods.toggle(root,info.digest);check(ContentMods.prepare(root).plan.isEmpty());ContentMods.toggle(root,info.digest);check(ContentMods.prepare(root).key.equals(s.key));
                if(args.length>=3){Path output=Path.of(args[2]);Files.createDirectories(output);Files.copy(Path.of(s.plan),output.resolve("spanish-plan.bin"),StandardCopyOption.REPLACE_EXISTING);Files.writeString(output.resolve("spanish-plan.sha256"),s.planSha+"\n");Files.writeString(output.resolve("spanish-mod-key.txt"),s.key+"\n");}
                String dialoguePath=null;Map<String,byte[]> originalPackage=unzip(pkg);
                for(Object row:ModJson.array(ModJson.read(new String(originalPackage.get("manifest.json"),StandardCharsets.UTF_8)).get("patches"))){Map<String,Object> entry=ModJson.object(row);if(ModJson.integer(entry.get("offset"))==0x3c03c8)dialoguePath=ModJson.string(entry.get("file"));}
                check(dialoguePath!=null);Path resource=tmp.resolve("root/mods-v2/packages/"+info.digest+"/"+dialoguePath);byte[] before=Files.readAllBytes(resource),bad=before.clone();bad[0]^=1;Files.write(resource,bad);rejects(()->ContentMods.prepare(root));Files.write(resource,before);
                // The complete translation uses declared data patches. Test
                // the stricter text contract with a dedicated one-byte patch.
                byte[] originalText={rom[0x3c03c8]},brokenText={(byte)(rom[0x3c03c8]^128)};
                Map<String,byte[]> invalid=change(good,"\"offset\":65536","\"offset\":3933128");
                invalid=change(invalid,"\"kind\":\"graphics\"","\"kind\":\"text\"");
                invalid=change(invalid,"\"sha256\":\""+h+"\"","\"sha256\":\""+sha(brokenText)+"\"");
                invalid=change(invalid,"\"expected_sha256\":\""+h+"\"","\"expected_sha256\":\""+sha(originalText)+"\"");
                invalid.put(name,brokenText);final Map<String,byte[]> badControls=invalid;rejects(()->install(root,cache,badControls));
                check(Arrays.equals(Files.readAllBytes(tmp.resolve("root/game/dkc1.sfc")),rom));ContentMods.disableAll(root);ContentMods.uninstall(root,info.digest);ContentMods.uninstall(root,conflict.digest);check(ContentMods.installed(root).isEmpty());
            }
            System.out.println("Content-mod tests passed: "+checks+" assertions. Retail integration="+(args.length>=2));
        }finally{try(java.util.stream.Stream<Path> paths=Files.walk(tmp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}}
    }
}

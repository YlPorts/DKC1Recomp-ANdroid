package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Package bounds and source validation; execution quotas are tested by the native Lua host. */
public final class RuntimeModTests {
    interface Check {void run()throws Exception;}
    private static int checks;
    private static void reject(Check check)throws Exception {
        try{check.run();throw new AssertionError("Malformed descriptor accepted");}catch(IOException expected){checks++;}
    }
    public static void main(String[] args)throws Exception {
        Path root=Files.createTempDirectory("dkc-runtime-");
        try{
            Path runtime=Files.createDirectories(root.resolve("runtime"));
            byte[] data=new byte[32];System.arraycopy(new byte[]{'S','2','M','O','D','1','3',0},0,data,0,8);
            Path file=runtime.resolve("sonic.bin");Files.write(file,data);
            String hash=ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(data));
            Map<String,Object> m=new LinkedHashMap<>();
            m.put("engine","sonic2-v1");m.put("file","runtime/sonic.bin");m.put("size",32L);
            m.put("sha256",hash);m.put("character_choice","characters");
            RuntimeMod.Info info=RuntimeMod.inspect(root.toFile(),m,true);
            if(info.mode("both")!=0||info.mode("sonic")!=1||info.mode("tails")!=2)throw new AssertionError("Mode mapping");checks++;
            if(RuntimeMod.inspect(root.toFile(),null,true)!=null)throw new AssertionError("Legacy no-op");checks++;
            reject(()->info.mode("arbitrary"));
            m.put("engine","script");reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.put("engine","sonic2-v1");
            m.put("file","runtime/../../escape.bin");reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.put("file","runtime/sonic.bin");
            m.put("size",33L);reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.put("size",32L);
            m.put("sha256","0".repeat(64));reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.put("sha256",hash);
            m.put("character_choice","Characters:1");reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.put("character_choice","characters");
            data[0]='X';Files.write(file,data);reject(()->RuntimeMod.inspect(root.toFile(),m,false));
            data[0]='S';Files.write(file,data);
            m.put("execute","code.so");reject(()->RuntimeMod.inspect(root.toFile(),m,true));
            m.remove("execute");m.remove("character_choice");m.put("engine","dkc-lua-v1");
            byte[] script="return {}\n".getBytes(java.nio.charset.StandardCharsets.UTF_8),bundle=new byte[20+script.length];
            System.arraycopy(new byte[]{'D','K','C','L','U','A','1',0},0,bundle,0,8);bundle[8]=(byte)script.length;System.arraycopy(script,0,bundle,20,script.length);
            Files.write(file,bundle);m.put("size",(long)bundle.length);m.put("sha256",ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(bundle)));
            RuntimeMod.Info scriptInfo=RuntimeMod.inspect(root.toFile(),m,true);if(!scriptInfo.scripted()||!scriptInfo.choice.isEmpty())throw new AssertionError("Generic source descriptor");checks++;
            for(int offset:new int[]{0,8,11,12,15,16,19}){
                byte[] malformed=bundle.clone();malformed[offset]^=1;Files.write(file,malformed);reject(()->RuntimeMod.inspect(root.toFile(),m,false));
            }
            for(byte value:new byte[]{0,27,(byte)255}){
                byte[] malformed=bundle.clone();malformed[20]=value;Files.write(file,malformed);reject(()->RuntimeMod.inspect(root.toFile(),m,false));
            }
            Files.write(file,bundle);m.put("character_choice","characters");reject(()->RuntimeMod.inspect(root.toFile(),m,true));m.remove("character_choice");
            byte[] changed=bundle.clone();changed[changed.length-1]=' ';Files.write(file,changed);reject(()->RuntimeMod.inspect(root.toFile(),m,true));
            Files.write(file,bundle);
            System.out.println("Runtime resource checks passed: "+checks);
        }finally{
            try(java.util.stream.Stream<Path> paths=Files.walk(root)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}
        }
    }
}

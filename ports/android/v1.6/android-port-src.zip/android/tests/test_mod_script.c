#include "mod_script.h"
#include "lua.h"
#include "lauxlib.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static unsigned assertions;
#define CHECK(x) do { assertions++; assert(x); } while (0)

static int host_add(lua_State *state) {
    int *calls = (int *)lua_touserdata(state, lua_upvalueindex(1));
    ++*calls;
    lua_pushinteger(state, luaL_checkinteger(state, 1) + 9);
    return 1;
}

static void register_host(lua_State *state, void *userdata) {
    lua_newtable(state);
    lua_pushlightuserdata(state, userdata);
    lua_pushcclosure(state, host_add, 1);
    lua_setfield(state, -2, "add");
    lua_setglobal(state, "dkc");
}

static ModScript *create(const char *source, int *calls, char *error, size_t n) {
    return ModScriptCreate(source, strlen(source), register_host, calls, error, n);
}

static void rejects_source(const char *source, const char *reason) {
    int calls = 0;
    char error[512] = {0};
    ModScript *script = create(source, &calls, error, sizeof(error));
    CHECK(script == NULL);
    CHECK(strstr(error, reason) != NULL);
    CHECK(calls == 0);
}

static void rejects_callback(const char *body, const char *reason) {
    int calls = 0;
    char source[1024], error[512] = {0};
    snprintf(source, sizeof(source), "return { tick=function() %s end }", body);
    ModScript *script = create(source, &calls, error, sizeof(error));
    CHECK(script != NULL);
    int64_t value = 812;
    CHECK(!ModScriptCall(script, "tick", NULL, 0, &value, 1));
    CHECK(!ModScriptEnabled(script));
    CHECK(value == 812);
    if (!strstr(ModScriptError(script), reason))
        fprintf(stderr, "Expected %s, received %s for %s\n", reason, ModScriptError(script), body);
    CHECK(strstr(ModScriptError(script), reason) != NULL);
    CHECK(!ModScriptCall(script, "tick", NULL, 0, &value, 1));
    CHECK(ModScriptMemory(script) <= MOD_SCRIPT_MEMORY_LIMIT);
    ModScriptDestroy(script);
}

int main(void) {
    int calls = 0;
    char error[512] = {0};
    const char *source =
        "assert(io==nil and os==nil and package==nil and debug==nil)\n"
        "assert(load==nil and loadfile==nil and dofile==nil and require==nil)\n"
        "assert(pcall==nil and xpcall==nil and coroutine==nil)\n"
        "assert(print==nil and warn==nil and collectgarbage==nil)\n"
        "assert(getmetatable==nil and setmetatable==nil)\n"
        "assert(math.random==nil and math.randomseed==nil)\n"
        "assert(string.dump==nil and ('s').dump==nil)\n"
        "assert(string.find==nil and ('s').find==nil and string.gsub==nil)\n"
        "assert(table.move==nil and table.insert==nil and table.remove==nil)\n"
        "assert(tostring({})=='table' and tostring(function() end)=='function')\n"
        "assert(tostring(17)=='17' and tostring(true)=='true' and tostring(nil)=='nil')\n"
        "local ticks=0\n"
        "return { filter_input=function(x) return dkc.add(x) end,\n"
        "reset=function() ticks=0 end, tick=function() ticks=ticks+1; return ticks end,\n"
        "values=function() return true,false,nil,-42 end,\n"
        "bad_values=function() return 77,'invalid' end }\n";
    ModScript *script = create(source, &calls, error, sizeof(error));
    CHECK(script != NULL);
    CHECK(ModScriptEnabled(script));
    CHECK(error[0] == 0);
    CHECK(ModScriptMemory(script) > 0 && ModScriptMemory(script) < MOD_SCRIPT_MEMORY_LIMIT);
    int64_t argument = 123, result = -9;
    CHECK(ModScriptCall(script, "filter_input", &argument, 1, &result, 1));
    CHECK(result == 132 && calls == 1);
    CHECK(ModScriptCall(script, "nonexistent", NULL, 0, &result, 1));
    CHECK(result == 132);
    int64_t values[] = {99,99,99,99};
    CHECK(ModScriptCall(script, "values", NULL, 0, values, 4));
    CHECK(values[0] == 1 && values[1] == 0 && values[2] == 99 && values[3] == -42);
    for (int64_t i = 1; i <= 1024; ++i) {
        CHECK(ModScriptCall(script, "tick", NULL, 0, &result, 1));
        CHECK(result == i);
    }
    CHECK(ModScriptCall(script, "reset", NULL, 0, NULL, 0));
    CHECK(ModScriptCall(script, "tick", NULL, 0, &result, 1));
    CHECK(result == 1);
    int64_t atomic[] = {31,32};
    CHECK(!ModScriptCall(script, "bad_values", NULL, 0, atomic, 2));
    CHECK(atomic[0] == 31 && atomic[1] == 32);
    CHECK(!ModScriptEnabled(script));
    ModScriptDestroy(script);

    rejects_source("while true do end", "instruction budget");
    rejects_source("local x={}; while true do x[#x+1]=string.rep('x',65536) end", "memory");
    rejects_source("return {", "expected");
    rejects_source("return 12", "callback table");
    rejects_source("\x1bLua\x54", "binary");
    rejects_source("error({})", "non-text");
    rejects_callback("while true do end", "instruction budget");
    rejects_callback("local x=string.rep('x',2147483647); return #x", "memory");
    rejects_callback("local x={}; while true do x[#x+1]=string.rep('x',65536) end", "memory");
    rejects_callback("return 'wrong'", "integer, boolean or nil");
    rejects_callback("error('deliberate fault')", "deliberate fault");
    rejects_callback("local f; f=function() return 1+f() end; return f()", "memory");

    script = ModScriptCreate("x", MOD_SCRIPT_SOURCE_LIMIT + 1u, NULL, NULL, error, sizeof(error));
    CHECK(script == NULL);
    script = ModScriptCreate(NULL, 0, NULL, NULL, error, sizeof(error));
    CHECK(script == NULL);
    script = create("return {tick=9}", &calls, error, sizeof(error));
    CHECK(script != NULL);
    CHECK(!ModScriptCall(script, "tick", NULL, 0, NULL, 0));
    CHECK(strstr(ModScriptError(script), "not a function") != NULL);
    ModScriptDestroy(script);
    CHECK(!ModScriptEnabled(NULL));
    CHECK(!ModScriptCall(NULL, "tick", NULL, 0, NULL, 0));
    ModScriptDestroy(NULL);
    printf("{\"test\":\"mod_script_sandbox\",\"assertions\":%u,\"passed\":true,"
           "\"lua_version\":\"%s\",\"memory_limit_bytes\":%u,\"instruction_limit\":%u}\n",
           assertions, LUA_RELEASE, MOD_SCRIPT_MEMORY_LIMIT, MOD_SCRIPT_INSTRUCTION_LIMIT);
    return 0;
}

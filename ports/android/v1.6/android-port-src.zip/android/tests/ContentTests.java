package com.ylports.dkc1recomp;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public final class ContentTests {
    static int checks;
    static void check(boolean b){checks++;if(!b)throw new AssertionError("Check "+checks);}
    interface Test{void run()throws Exception;}
    static void rejects(Test f)throws Exception{boolean rejected=false;try{f.run();}catch(IOException e){rejected=true;}check(rejected);}
    static byte[] pcm(){byte[] b=new byte[40];b[0]='M';b[1]='S';b[2]='U';b[3]='1';for(int i=8;i<b.length;i++)b[i]=(byte)(i*7);return b;}
    static byte[] zip(Map<String,byte[]> entries)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(out)){for(Map.Entry<String,byte[]> e:entries.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}}return out.toByteArray();}
    static Map<String,byte[]> tracks(){Map<String,byte[]> e=new LinkedHashMap<>();for(int i=1;i<=27;i++)e.put("album/track-"+i+".pcm",pcm());return e;}
    public static void main(String[] args)throws Exception{
        Path root=Files.createTempDirectory("dkc-content-test");
        try{
            Map<String,byte[]> full=tracks();MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(full)));
            File current=root.resolve("music/current").toFile();check(MusicPack.isComplete(current));
            for(int i=1;i<=27;i++)check(Arrays.equals(Files.readAllBytes(new File(current,"track-"+i+".pcm").toPath()),pcm()));
            Map<String,byte[]> partial=tracks();partial.remove("album/track-27.pcm");rejects(()->MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(partial))));check(MusicPack.isComplete(current));
            for(String bad:new String[]{"../escape.pcm","/absolute.pcm","D:/evil.pcm","x/../../escape"}){Map<String,byte[]> e=tracks();e.put(bad,pcm());rejects(()->MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(e))));check(!root.resolve("escape.pcm").toFile().exists());}
            Map<String,byte[]> duplicate=tracks();duplicate.put("second/dkc_msu-1.pcm",pcm());rejects(()->MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(duplicate))));check(MusicPack.isComplete(current));
            Map<String,byte[]> badHeader=tracks();badHeader.put("album/track-8.pcm",new byte[40]);rejects(()->MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(badHeader))));check(MusicPack.isComplete(current));
            for(int size:new int[]{0,8,12,15,17}){byte[] b=Arrays.copyOf(pcm(),size);File f=root.resolve("bad.pcm").toFile();Files.write(f.toPath(),b);rejects(()->MusicPack.validatePcm(f));}
            byte[] badLoop=pcm();badLoop[4]=100;File f=root.resolve("bad.pcm").toFile();Files.write(f.toPath(),badLoop);rejects(()->MusicPack.validatePcm(f));
            Arrays.fill(badLoop,4,8,(byte)255);Files.write(f.toPath(),badLoop);MusicPack.validatePcm(f);check(true);
            Map<String,byte[]> tooMany=tracks();for(int i=0;i<512;i++)tooMany.put("doc"+i,new byte[0]);rejects(()->MusicPack.fromZip(root.toFile(),new ByteArrayInputStream(zip(tooMany))));
            MusicPack.install(root.toFile(),writer->{for(int i=1;i<=27;i++)writer.add("dkc-"+i+".pcm",new ByteArrayInputStream(pcm()));});check(MusicPack.isComplete(current));
            File old=root.resolve("music/previous").toFile();check(current.renameTo(old));MusicPack.recover(root.resolve("music").toFile());check(MusicPack.isComplete(current));
            for(String content:new String[]{"format=2\nname=Test\npalette=1","format=1\nname=Test\npalette=9","format=1\nname=Test\nscript=payload","format=1\nname=\npalette=1","format=1\nname=Test","x".repeat(9000)})rejects(()->VisualMod.read(new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8))));
            VisualMod mod=VisualMod.read(new ByteArrayInputStream("format=1\nname=CRT\nsampling=2\npalette=3\nscanlines=25\nedge=3".getBytes(StandardCharsets.UTF_8)));check(mod.values.size()==4);check(mod.name.equals("CRT"));
            check(SaveBackup.allowed("game/autosave-4x3-msu1.state"));check(SaveBackup.allowed("game/quicksave-21x9-msu1-slot5.state"));check(!SaveBackup.allowed("game/quicksave-4x3-msu1-slot99.state"));
            MusicPack.remove(root.toFile());check(!MusicPack.isComplete(current));
            System.out.println("Content tests passed: "+checks+" assertions (synthetic MSU-1, rollback, path limits, visual profiles, save names)");
        }finally{MusicPack.delete(root.toFile());}
    }
}

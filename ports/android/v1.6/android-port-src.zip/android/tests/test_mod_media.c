#include "mod_media.h"
#include "legacy/sonic_audio.h"
#include "snes/ppu.h"

#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned s_checks;
#define CHECK(condition) do { assert(condition); ++s_checks; } while (0)

static void Put32(uint8_t *p, uint32_t x) {
  for (unsigned n = 0; n < 4; ++n) p[n] = (uint8_t)(x >> (n * 8));
}
static uint32_t Get32(const uint8_t *p) {
  return (uint32_t)p[0] | (uint32_t)p[1] << 8 |
         (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}
static void Put16(uint8_t *p, int x) {
  unsigned u = (unsigned)(uint16_t)x;
  p[0] = (uint8_t)u; p[1] = (uint8_t)(u >> 8);
}
static size_t Clip(uint8_t *out, uint32_t event, uint32_t rate,
                   uint32_t channels, uint32_t frames, int amplitude) {
  Put32(out, event); Put32(out + 4, rate); Put32(out + 8, channels);
  Put32(out + 12, frames);
  for (uint32_t i = 0; i < frames; ++i)
    for (uint32_t c = 0; c < channels; ++c)
      Put16(out + 16 + 2 * (i * channels + c), c ? -amplitude : amplitude);
  return 16 + (size_t)frames * channels * 2;
}
static void InitPpu(Ppu *p, unsigned width) {
  memset(p, 0, sizeof(*p));
  p->renderPitch = width * 4;
  p->renderBuffer = calloc((size_t)width * 224, 4);
  CHECK(p->renderBuffer);
  for (unsigned i = 0; i < 32; ++i) p->brightnessMult[i] = (uint8_t)(i * 255 / 31);
}
static void TestBanksAndAudio(void) {
  uint8_t atlas[128] = {'D','K','C','A','T','L','1',0};
  Put32(atlas + 8, 4); Put32(atlas + 12, 3);
  Put32(atlas + 16, 2); Put32(atlas + 20, 3);
  const uint8_t palette[] = {0,0,0,0, 255,0,0,255, 0,255,0,0};
  memcpy(atlas + 24, palette, sizeof(palette));
  atlas[36 + 4 + 1] = 1; atlas[36 + 8 + 3] = 1;
  atlas[36 + 12] = 2; /* Alpha-zero entry must not expand bounds. */
  size_t atlas_size = 36 + 24;
  uint8_t bank[4096] = {'D','K','C','S','N','D','1',0};
  Put32(bank + 8, 1);
  size_t bank_size = 12 + Clip(bank + 12, 0x80000000u, 16000, 2, 4, 20000);
  char error[128]; int first, last; unsigned width, height;
  CHECK(ModMediaLoad(atlas, atlas_size, bank, bank_size, error, sizeof(error)) && !error[0]);
  CHECK(ModMediaFrameBounds(0, &first, &last, &width, &height));
  CHECK(first == 1 && last == 2 && width == 4 && height == 3);
  CHECK(!ModMediaFrameBounds(1, &first, &last, &width, &height));
  CHECK(first == -1 && last == -1);
  CHECK(!ModMediaFrameBounds(2, NULL, NULL, NULL, NULL));
  CHECK(!ModMediaFrameBounds(UINT_MAX, NULL, NULL, NULL, NULL));
  for (size_t cut = 0; cut < atlas_size; ++cut) {
    CHECK(!ModMediaLoad(atlas, cut, bank, bank_size, error, sizeof(error)) && error[0]);
    CHECK(ModMediaFrameBounds(0, &first, &last, &width, &height));
    CHECK(first == 1 && last == 2 && width == 4 && height == 3);
  }
  for (size_t cut = 0; cut < bank_size; ++cut) {
    CHECK(!ModMediaLoad(atlas, atlas_size, bank, cut, error, sizeof(error)) && error[0]);
    CHECK(ModMediaFrameBounds(0, NULL, NULL, NULL, NULL));
  }
  CHECK(!ModMediaLoad(atlas, atlas_size + 1, bank, bank_size, error, sizeof(error)));
  CHECK(!ModMediaLoad(atlas, atlas_size, bank, bank_size + 1, error, sizeof(error)));
  atlas[36] = 3;
  CHECK(!ModMediaLoad(atlas, atlas_size, bank, bank_size, error, sizeof(error)));
  atlas[36] = 0;
  for (unsigned field = 8; field <= 20; field += 4) {
    uint32_t old = Get32(atlas + field);
    Put32(atlas + field, 0);
    CHECK(!ModMediaLoad(atlas, atlas_size, bank, bank_size, error, sizeof(error)));
    Put32(atlas + field, UINT32_MAX);
    CHECK(!ModMediaLoad(atlas, atlas_size, bank, bank_size, error, sizeof(error)));
    Put32(atlas + field, old);
  }
  int16_t pcm[64] = {0};
  ModMediaPlay(0x80000000u, 0);
  for (int i = 0; i < 4; ++i) { pcm[i * 2] = 25000; pcm[i * 2 + 1] = -25000; }
  ModMediaMix(pcm, 4, 16000);
  for (int i = 0; i < 4; ++i) CHECK(pcm[i * 2] == 32767 && pcm[i * 2 + 1] == -32768);
  memset(pcm, 0, sizeof(pcm));
  ModMediaMix(pcm, 4, 16000);
  for (int i = 0; i < 8; ++i) CHECK(pcm[i] == 0);
  ModMediaPlay(0x80000000u, 0x80000000u); ModMediaMix(pcm, 4, 16000);
  CHECK(pcm[0] == 0);
  ModMediaPlay(0x80000000u, 0); ModMediaResetAudio(); ModMediaMix(pcm, 4, 16000);
  CHECK(pcm[0] == 0);

  bank_size = 12 + Clip(bank + 12, 1, 16000, 1, 4, 0);
  for (unsigned i = 0; i < 4; ++i) Put16(bank + 28 + i * 2, (int)i * 1000);
  CHECK(ModMediaLoad(NULL, 0, bank, bank_size, error, sizeof(error)));
  CHECK(!ModMediaFrameBounds(0, NULL, NULL, NULL, NULL));
  ModMediaPlay(1, 0); ModMediaMix(pcm, 8, 32000);
  for (int i = 0; i < 8; ++i) {
    int expected = i < 6 ? i * 500 : 3000;
    CHECK(pcm[i * 2] == expected && pcm[i * 2 + 1] == expected);
  }
  const uint32_t bad_values[] = {0, 3, 100, 3, UINT32_MAX};
  const unsigned bad_offsets[] = {12, 12, 16, 20, 24};
  for (unsigned i = 0; i < sizeof(bad_values) / sizeof(bad_values[0]); ++i) {
    uint32_t old = Get32(bank + bad_offsets[i]);
    Put32(bank + bad_offsets[i], bad_values[i]);
    CHECK(!ModMediaLoad(NULL, 0, bank, bank_size, error, sizeof(error)));
    Put32(bank + bad_offsets[i], old);
  }
  Put32(bank + 8, 32); bank_size = 12;
  for (unsigned i = 0; i < 32; ++i)
    bank_size += Clip(bank + bank_size, UINT32_C(1) << i, 8000, 1, 1, 1000);
  CHECK(ModMediaLoad(NULL, 0, bank, bank_size, error, sizeof(error)));
  memset(pcm, 0, sizeof(pcm));
  ModMediaPlay(UINT32_MAX, 0); ModMediaMix(pcm, 1, 8000);
  CHECK(pcm[0] == 32000 && pcm[1] == 32000);
  Put32(bank + 8, 33);
  CHECK(!ModMediaLoad(NULL, 0, bank, bank_size, error, sizeof(error)));
  Put32(bank + 8, 32); Put32(bank + 12 + 18, 1);
  CHECK(!ModMediaLoad(NULL, 0, bank, bank_size, error, sizeof(error)));
  Put32(bank + 8, 0);
  CHECK(ModMediaLoad(atlas, atlas_size, bank, 12, error, sizeof(error)));
  CHECK(ModMediaFrameBounds(0, NULL, NULL, NULL, NULL));
  CHECK(ModMediaLoad(NULL, 0, NULL, 0, error, sizeof(error)));
  CHECK(!ModMediaFrameBounds(0, NULL, NULL, NULL, NULL));
  ModMediaUnload();
}

static void TestDraw(void) {
  uint8_t atlas[] = {'D','K','C','A','T','L','1',0,
    2,0,0,0, 2,0,0,0, 1,0,0,0, 3,0,0,0,
    0,0,0,0, 255,0,0,255, 0,255,0,128, 1,2,0,1};
  char error[128];
  CHECK(ModMediaLoad(atlas, sizeof(atlas), NULL, 0, error, sizeof(error)));
  Ppu p; InitPpu(&p, 256);
  uint32_t *pixels = (uint32_t *)p.renderBuffer;
  ModMediaDraw(&p, 0, 100, 20, false, 1, 1);
  CHECK(pixels[20 * 256 + 99] == 0xffff0000u);
  CHECK(pixels[20 * 256 + 100] == 0xff008000u);
  CHECK(pixels[21 * 256 + 99] == 0);
  CHECK(pixels[21 * 256 + 100] == 0xffff0000u);
  memset(p.renderBuffer, 0, (size_t)p.renderPitch * 224);
  ModMediaDraw(&p, 0, 100, 20, true, 1, 1);
  CHECK(pixels[20 * 256 + 100] == 0xffff0000u);
  CHECK(pixels[20 * 256 + 99] == 0xff008000u);
  ModMediaDraw(&p, UINT_MAX, INT_MIN, INT_MAX, true, 1, 1);
  ModMediaDraw(&p, 0, INT_MIN, INT_MAX, true, 1, 1);
  ModMediaDraw(&p, 0, INT_MAX, INT_MIN, false, 4, 1);
  ModMediaDraw(&p, 0, INT_MAX, INT_MIN, false, 1, 4);
  ModMediaDraw(&p, 0, 100, 20, true, 0, 1);
  ModMediaDraw(&p, 0, 100, 20, true, 1, 0);
  ModMediaDraw(&p, 0, 100, 20, true, UINT_MAX, 1);
  CHECK(pixels[20 * 256 + 100] == 0xffff0000u);
  free(p.renderBuffer); InitPpu(&p, 342); pixels = (uint32_t *)p.renderBuffer;
  ModMediaDraw(&p, 0, 0, 0, false, 2, 1);
  CHECK(pixels[41] == 0xffff0000u && pixels[42] == 0xffff0000u);
  CHECK(pixels[43] == 0xff008000u && pixels[44] == 0xff008000u);
  CHECK(pixels[342 + 41] == 0xffff0000u);
  ModMediaDraw(&p, 0, -43, 223, true, 4, 1);
  free(p.renderBuffer); ModMediaUnload();
}

/* This is the previous release's scalar rendering oracle. Comparing every
 * original frame proves the generic media conversion preserves its output.
 */
static void LegacyDraw(Ppu *p, const uint8_t *atlas, unsigned frame,
                        int cx, int oy, bool flip, unsigned num, unsigned den) {
  unsigned w = Get32(atlas + 8), h = Get32(atlas + 12);
  unsigned width = p->renderPitch / 4, extra = (width - 256) / 2;
  const uint8_t *src = atlas + 88 + (size_t)frame * w * h;
  unsigned dw = w * num / den, dh = h * num / den;
  for (unsigned y = 0; y < dh; ++y) {
    int dy = oy + (int)y;
    if (dy < 0 || dy >= 224) continue;
    uint32_t *dst = (uint32_t *)(p->renderBuffer + (size_t)dy * p->renderPitch);
    for (unsigned x = 0; x < dw; ++x) {
      unsigned color = src[(size_t)(y * den / num) * w + x * den / num];
      if (!color) continue;
      int local = (int)x - (int)dw / 2;
      int dx = cx + (flip ? -1 - local : local) + (int)extra;
      if (dx < 0 || dx >= (int)width) continue;
      const uint8_t *rgb = atlas + 24 + color * 4;
      uint32_t r = p->brightnessMult[rgb[0] >> 3];
      uint32_t g = p->brightnessMult[rgb[1] >> 3];
      uint32_t b = p->brightnessMult[rgb[2] >> 3];
      dst[dx] = 0xff000000u | r << 16 | g << 8 | b;
    }
  }
}

static void TestActualResources(const char *path) {
  FILE *f = fopen(path, "rb"); CHECK(f);
  CHECK(!fseek(f, 0, SEEK_END)); long length = ftell(f); CHECK(length > 88);
  rewind(f); uint8_t *old = malloc((size_t)length); CHECK(old);
  CHECK(fread(old, 1, (size_t)length, f) == (size_t)length); fclose(f);
  CHECK(!memcmp(old, "S2MOD13\0", 8));
  unsigned width = Get32(old + 8), height = Get32(old + 12);
  unsigned count = Get32(old + 16) + Get32(old + 20);
  size_t atlas_size = 88 + (size_t)width * height * count;
  CHECK(atlas_size + 8 < (size_t)length);
  uint8_t *atlas = malloc(atlas_size); CHECK(atlas);
  memcpy(atlas, old, atlas_size); memcpy(atlas, "DKCATL1\0", 8);
  Put32(atlas + 16, count); Put32(atlas + 20, 16);
  size_t audio_size = (size_t)length - atlas_size + 4;
  uint8_t *audio = malloc(audio_size); CHECK(audio);
  memcpy(audio, "DKCSND1\0", 8);
  memcpy(audio + 8, old + atlas_size + 4, audio_size - 8);
  char error[128];
  CHECK(ModMediaLoad(atlas, atlas_size, audio, audio_size, error, sizeof(error)));
  Ppu generic, legacy; InitPpu(&generic, 342); InitPpu(&legacy, 342);
  size_t bytes = (size_t)generic.renderPitch * 224;
  for (unsigned frame = 0; frame < count; ++frame) {
    const uint8_t *src = old + 88 + (size_t)frame * width * height;
    int first = -1, last = -1, actual_first = -2, actual_last = -2;
    for (unsigned y = 0; y < height; ++y)
      for (unsigned x = 0; x < width; ++x)
        if (src[(size_t)y * width + x]) { if (first < 0) first = (int)y; last = (int)y; }
    unsigned actual_width, actual_height;
    CHECK(ModMediaFrameBounds(frame, &actual_first, &actual_last,
                              &actual_width, &actual_height) == (first >= 0));
    CHECK(first == actual_first && last == actual_last && actual_width == width && actual_height == height);
    for (unsigned variant = 0; variant < 4; ++variant) {
      unsigned num = variant & 2 ? 2 : 1, den = variant & 2 ? 3 : 1;
      memset(generic.renderBuffer, 0x40, bytes); memset(legacy.renderBuffer, 0x40, bytes);
      ModMediaDraw(&generic, frame, 128, 70, (variant & 1) != 0, num, den);
      LegacyDraw(&legacy, old, frame, 128, 70, (variant & 1) != 0, num, den);
      CHECK(!memcmp(generic.renderBuffer, legacy.renderBuffer, bytes));
    }
  }
  CHECK(SonicAudioLoad(old + atlas_size, (size_t)length - atlas_size, error, sizeof(error)));
  int16_t pcm_generic[2048], pcm_legacy[2048];
  for (unsigned effect = 1; effect <= 128; effect <<= 1) {
    ModMediaResetAudio(); SonicAudioReset();
    ModMediaPlay(effect, 0); SonicAudioEvents(effect);
    for (unsigned part = 0; part < 64; ++part) {
      memset(pcm_generic, 0, sizeof(pcm_generic)); memset(pcm_legacy, 0, sizeof(pcm_legacy));
      ModMediaMix(pcm_generic, 1024, 32040); SonicAudioMix(pcm_legacy, 1024, 32040);
      CHECK(!memcmp(pcm_generic, pcm_legacy, sizeof(pcm_generic)));
    }
  }
  ModMediaResetAudio(); SonicAudioReset();
  ModMediaPlay(4, 0); SonicAudioEvents(4);
  ModMediaPlay(8, 4 | 2); SonicAudioEvents(8);
  memset(pcm_generic, 0, sizeof(pcm_generic)); memset(pcm_legacy, 0, sizeof(pcm_legacy));
  ModMediaMix(pcm_generic, 1024, 32040); SonicAudioMix(pcm_legacy, 1024, 32040);
  CHECK(!memcmp(pcm_generic, pcm_legacy, sizeof(pcm_generic)));
  free(generic.renderBuffer); free(legacy.renderBuffer);
  free(atlas); free(audio); free(old); ModMediaUnload(); SonicAudioUnload();
}

int main(int argc, char **argv) {
  TestBanksAndAudio(); TestDraw();
  if (argc > 1) TestActualResources(argv[1]);
  printf("Generic mod media: %u parser, transaction, audio and rendering checks passed.\n", s_checks);
  return 0;
}

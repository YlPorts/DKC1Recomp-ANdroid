#define _POSIX_C_SOURCE 200809L
#include "content_mod.h"
#include "sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#define SIZE 4194304u
static int checks;
#define CHECK(x) do { checks++; if(!(x)){fprintf(stderr,"check %d failed at line %d\n",checks,__LINE__);abort();}}while(0)
static void be(uint8_t *b,uint32_t v){b[0]=v>>24;b[1]=v>>16;b[2]=v>>8;b[3]=v;}
static void hashhex(const uint8_t *b,size_t n,char out[65]){uint8_t h[32];sha256_compute(b,n,h);for(int i=0;i<32;i++)sprintf(out+i*2,"%02x",h[i]);}
static void writefile(const char *p,const uint8_t *b,size_t n){FILE *f=fopen(p,"wb");CHECK(f);CHECK(fwrite(b,1,n,f)==n);CHECK(fclose(f)==0);}
static uint8_t *readfile(const char *p,size_t *n){FILE *f=fopen(p,"rb");CHECK(f);CHECK(!fseek(f,0,SEEK_END));long z=ftell(f);CHECK(z>=0);*n=(size_t)z;rewind(f);uint8_t *b=malloc(*n+1);CHECK(b);CHECK(fread(b,1,*n,f)==*n);fclose(f);return b;}
static int apply(uint8_t *rom,const uint8_t *plan,size_t n,const char *path){char sha[65],error[200];hashhex(plan,n,sha);writefile(path,plan,n);return DkcContentModApply(rom,SIZE,path,sha,error,sizeof error);}
int main(int argc,char **argv){
 uint8_t *rom=malloc(SIZE),*original=malloc(SIZE);CHECK(rom&&original);for(size_t i=0;i<SIZE;i++)original[i]=(uint8_t)(i*17u+i/256u);memcpy(rom,original,SIZE);
 char file[]="/tmp/dkc-content-test-XXXXXX";int fd=mkstemp(file);CHECK(fd>=0);close(fd);
 uint8_t plan[124]={0};memcpy(plan,"DKCMOD02",8);be(plan+8,1);sha256_compute(rom,SIZE,plan+12);be(plan+76,0x10000);be(plan+80,8);sha256_compute(rom+0x10000,8,plan+84);
 for(int i=0;i<8;i++)plan[116+i]=(uint8_t)(200+i);memcpy(rom+0x10000,plan+116,8);sha256_compute(rom,SIZE,plan+44);memcpy(rom,original,SIZE);
 CHECK(apply(rom,plan,sizeof plan,file));CHECK(!memcmp(rom+0x10000,plan+116,8));CHECK(!memcmp(rom,original,0x10000));CHECK(!memcmp(rom+0x10008,original+0x10008,SIZE-0x10008));memcpy(rom,original,SIZE);
 for(size_t len=0;len<sizeof plan;len++){CHECK(!apply(rom,plan,len,file));CHECK(!memcmp(rom,original,SIZE));}
 for(size_t pos=0;pos<sizeof plan;pos++){uint8_t bad[sizeof plan];memcpy(bad,plan,sizeof plan);bad[pos]^=0xff;CHECK(!apply(rom,bad,sizeof bad,file));CHECK(!memcmp(rom,original,SIZE));}
 uint8_t bad[sizeof plan+1];memcpy(bad,plan,sizeof plan);bad[sizeof plan]=1;CHECK(!apply(rom,bad,sizeof bad,file));
 memcpy(bad,plan,sizeof plan);be(bad+76,0x8000);sha256_compute(rom+0x8000,8,bad+84);CHECK(!apply(rom,bad,sizeof plan,file));CHECK(!memcmp(rom,original,SIZE));
 char err[200];CHECK(!DkcContentModApply(rom,SIZE,file,"bad",err,sizeof err));CHECK(!DkcContentModApply(rom,SIZE-1,file,"bad",err,sizeof err));
 /* A runtime-only mod carries a verified empty data transaction. It must not
  * bypass either ROM identity, result identity, or exact-length checks. */
 uint8_t empty[77]={0};memcpy(empty,"DKCMOD02",8);sha256_compute(original,SIZE,empty+12);memcpy(empty+44,empty+12,32);
 CHECK(apply(rom,empty,76,file));CHECK(!memcmp(rom,original,SIZE));
 CHECK(!apply(rom,empty,77,file));CHECK(!memcmp(rom,original,SIZE));
 empty[44]^=1;CHECK(!apply(rom,empty,76,file));CHECK(!memcmp(rom,original,SIZE));empty[44]^=1;
 empty[12]^=1;CHECK(!apply(rom,empty,76,file));CHECK(!memcmp(rom,original,SIZE));
 if(argc==5){size_t z,n;uint8_t *input=readfile(argv[1],&z),*p=readfile(argv[2],&n);CHECK(z==SIZE);CHECK(DkcContentModApply(input,z,argv[2],argv[3],err,sizeof err));writefile(argv[4],input,z);free(input);free(p);}
 unlink(file);free(original);free(rom);printf("Native mod tests passed: %d checks (transactional validation, every-byte corruption and truncation)\n",checks);return 0;
}

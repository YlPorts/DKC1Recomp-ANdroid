package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Format-4 import, arbitrary selectors, exact profile migration and transaction regressions. */
public final class IndependentModTests {
    private static int checks;
    private static final String[] MODES={"both","sonic","tails"};
    interface Operation {void run()throws Exception;}
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void rejects(Operation op)throws Exception {try{op.run();throw new AssertionError("Invalid package or operation accepted");}catch(IOException expected){checks++;}}
    private static byte[] utf8(String value){return value.getBytes(StandardCharsets.UTF_8);}
    private static String sha(byte[] data)throws Exception{return ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(data));}
    private static String descriptor(String engine,byte[] bytes)throws Exception {
        return "{\"engine\":\""+engine+"\",\"file\":\"runtime/mod.bin\",\"size\":"+bytes.length+",\"sha256\":\""+sha(bytes)+"\""+(engine.equals("sonic2-v1")?",\"character_choice\":\"characters\"":"")+"}";
    }
    private static byte[] source(String script){byte[] code=utf8(script),bytes=new byte[20+code.length];System.arraycopy(utf8("DKCLUA1"),0,bytes,0,7);for(int i=0;i<4;i++)bytes[8+i]=(byte)(code.length>>>(8*i));System.arraycopy(code,0,bytes,20,code.length);return bytes;}
    private static String choices(String id,String... options){
        StringBuilder b=new StringBuilder("{\"id\":\""+id+"\",\"label\":\"Elección\",\"default\":\""+options[0]+"\",\"options\":[");
        for(String option:options){if(b.charAt(b.length()-1)!='[')b.append(',');b.append("{\"id\":\"").append(option).append("\",\"label\":\"").append(option).append("\",\"patches\":[]}");}return b.append("]}").toString();
    }
    private static String manifest(String id,int format,String choices,String alias,byte[] data)throws Exception {
        return "{\"format\":"+format+",\"min_port\":"+(format==4?105:103)+",\"id\":\""+id+"\",\"name\":\"Independent\",\"version\":\"2\",\"category\":\"data\",\"base_sha256\":\""+ContentMods.BASE_SHA+"\",\"patches\":[]"+(choices.isEmpty()?"":",\"choices\":["+choices+"]")+(alias.isEmpty()?"":",\"save_profile_sha256\":\""+alias+"\"")+",\"runtime\":"+descriptor(format==4?"dkc-lua-v1":"sonic2-v1",data)+"}";
    }
    private static byte[] archive(String manifest,byte[] resource)throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();try(ZipOutputStream zip=new ZipOutputStream(out)){
            for(Map.Entry<String,byte[]> e:new LinkedHashMap<String,byte[]>(){{put("manifest.json",utf8(manifest));put("runtime/mod.bin",resource);}}.entrySet()){
                ZipEntry entry=new ZipEntry(e.getKey());entry.setTime(0);zip.putNextEntry(entry);zip.write(e.getValue());zip.closeEntry();
            }
        }return out.toByteArray();
    }
    private static ContentMods.Info install(File root,File cache,byte[] archive)throws Exception{return ContentMods.install(root,cache,new ByteArrayInputStream(archive));}
    private static void selectLegacy(File root,String digest,String value)throws Exception {
        Path path=root.toPath().resolve("mods-v2/selections/"+digest+".txt");Files.createDirectories(path.getParent());Files.writeString(path,"characters="+value+"\n");
    }
    private static void enableLegacy(File root,String digest,String companion)throws Exception {
        SortedSet<String> ids=new TreeSet<>();ids.add(digest);if(!companion.isEmpty())ids.add(companion);Files.writeString(root.toPath().resolve("mods-v2/enabled.txt"),String.join("\n",ids)+"\n");
    }
    public static void main(String[] args)throws Exception {
        if(args.length<1)throw new IllegalArgumentException("clean ROM [Spanish mod] [report.json]");
        Path tmp=Files.createTempDirectory("dkc-independent-");
        try{
            File root=tmp.resolve("root").toFile(),cache=tmp.resolve("cache").toFile();Path game=root.toPath().resolve("game");Files.createDirectories(game);byte[] rom=Files.readAllBytes(Path.of(args[0]));Files.write(game.resolve("dkc1.sfc"),rom);
            check(sha(rom).equals(ContentMods.BASE_SHA),"clean ROM identity");
            String spanish="";if(args.length>1){ContentMods.Info es=install(root,cache,Files.readAllBytes(Path.of(args[1])));spanish=es.digest;}
            byte[] legacy=new byte[32];System.arraycopy(utf8("S2MOD13"),0,legacy,0,7);String characters=choices("characters",MODES);
            byte[] oldZip=archive(manifest("test.independent",3,characters,"",legacy),legacy);ContentMods.Info old=install(root,cache,oldZip);
            Map<String,String> oldKeys=new LinkedHashMap<>(),mixedKeys=new LinkedHashMap<>();
            for(String mode:MODES){selectLegacy(root,old.digest,mode);enableLegacy(root,old.digest,"");oldKeys.put(mode,ContentMods.activeKey(root));enableLegacy(root,old.digest,spanish);mixedKeys.put(mode,ContentMods.activeKey(root));}
            selectLegacy(root,old.digest,"tails");enableLegacy(root,old.digest,spanish);rejects(()->ContentMods.prepare(root));
            String oldKey=ContentMods.activeKey(root);Path state=game.resolve("quicksave-4x3-mod-"+oldKey+".state");byte[] stateBytes={9,8,7,6};Files.write(state,stateBytes);
            byte[] script=source("return {}\n"),newZip=archive(manifest("test.independent",4,characters,old.digest,script),script);
            ContentMods.Info mod=install(root,cache,newZip);ContentMods.Session session=ContentMods.prepare(root);
            check(mod.runtime.scripted(),"Lua runtime discovered");check(mod.saveProfile.equals(old.digest),"explicit profile alias");
            check(ContentMods.active(root).contains(mod.digest)&&!ContentMods.active(root).contains(old.digest),"active predecessor swapped atomically");
            check(ContentMods.selected(root,mod).get("characters").equals("tails"),"old selection migrated");check(session.key.equals(oldKey),"exact existing save profile");
            check(session.runtimeOptions.equals("characters=tails\n"),"generic selection forwarding");check(session.runtimeMode==-1,"native character mode removed");
            check(ContentMods.installed(root).stream().anyMatch(i->i.digest.equals(old.digest)),"old package retained");check(Arrays.equals(Files.readAllBytes(state),stateBytes),"old save bytes retained");
            for(String mode:MODES){ContentMods.select(root,mod.digest,"characters",mode);check(ContentMods.prepare(root).key.equals(mixedKeys.get(mode)),"mixed old profile "+mode);}
            if(!spanish.isEmpty())ContentMods.toggle(root,spanish);
            for(String mode:MODES){ContentMods.select(root,mod.digest,"characters",mode);check(ContentMods.prepare(root).key.equals(oldKeys.get(mode)),"solo old profile "+mode);}
            ContentMods.select(root,mod.digest,"characters","sonic");String preserved=ContentMods.activeKey(root);install(root,cache,newZip);check(ContentMods.activeKey(root).equals(preserved),"reimport keeps current choice");
            // A new script version reuses the stable profile while replacing the active update.
            byte[] updatedScript=source("-- independent update\nreturn {}\n"),updateZip=archive(manifest("test.independent",4,characters,old.digest,updatedScript),updatedScript);
            ContentMods.Info update=install(root,cache,updateZip);check(ContentMods.active(root).contains(update.digest)&&!ContentMods.active(root).contains(mod.digest),"second update replaces active version");
            check(ContentMods.activeKey(root).equals(preserved),"second update same save profile");check(ContentMods.selected(root,update).get("characters").equals("sonic"),"active predecessor choice wins over original");
            String beforeKey=ContentMods.activeKey(root);SortedSet<String> beforeActive=ContentMods.active(root);
            byte[] badSchema=archive(manifest("test.independent",4,choices("characters","both","sonic"),old.digest,script),script);rejects(()->install(root,cache,badSchema));
            byte[] wrongId=archive(manifest("test.other",4,characters,old.digest,script),script);rejects(()->install(root,cache,wrongId));
            check(ContentMods.active(root).equals(beforeActive)&&ContentMods.activeKey(root).equals(beforeKey),"rejected migrations leave activation untouched");
            // Runtime choices are arbitrary and are sorted without recognizing character names.
            String arbitrary=choices("speed","slow","fast")+","+choices("color","blue","red");
            ContentMods.Info custom=install(root,cache,archive(manifest("test.custom",4,arbitrary,"",script),script));rejects(()->ContentMods.toggle(root,custom.digest));
            check(ContentMods.activeKey(root).equals(beforeKey),"runtime conflict preserves active mod");ContentMods.disableAll(root);ContentMods.toggle(root,custom.digest);
            ContentMods.select(root,custom.digest,"speed","fast");check(ContentMods.prepare(root).runtimeOptions.equals("color=blue\nspeed=fast\n"),"all generic selectors forwarded canonically");
            ContentMods.disableAll(root);ContentMods.Info noChoices=install(root,cache,archive(manifest("test.nochoices",4,"","",script).replace("\"patches\":[]","\"patches\":[],\"choices\":[]"),script));ContentMods.toggle(root,noChoices.digest);
            check(ContentMods.prepare(root).runtimeOptions.isEmpty(),"script-only mod needs no selectors");
            Path resource=noChoices.runtime.source.toPath();byte[] changed=script.clone();changed[changed.length-1]=' ';Files.write(resource,changed);rejects(()->ContentMods.prepare(root));Files.write(resource,script);
            check(!ContentMods.prepare(root).runtimePath.isEmpty(),"resource restored");ContentMods.disableAll(root);check(ContentMods.prepare(root).runtimePath.isEmpty(),"disabled scripts absent");
            check(Arrays.equals(rom,Files.readAllBytes(game.resolve("dkc1.sfc"))),"clean ROM unchanged");check(Arrays.equals(stateBytes,Files.readAllBytes(state)),"old save unchanged after all operations");
            if(args.length>2)Files.writeString(Path.of(args[2]),"{\n  \"passed\": true,\n  \"assertions\": "+checks+",\n  \"scope\": \"Host Java format-4 import, Lua bundle validation and exact legacy save profile migration\",\n  \"generic_choices\": true,\n  \"legacy_profiles_preserved\": true,\n  \"old_packages_retained\": true,\n  \"rejected_migrations_transactional\": true,\n  \"rom_and_save_bytes_unchanged\": true\n}\n");
            System.out.println("Independent-mod tests passed: "+checks+" assertions.");
        }finally{try(java.util.stream.Stream<Path> paths=Files.walk(tmp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}}
    }
}

#include "sonic_audio.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void Put32(uint8_t *p, uint32_t x) {
  for (unsigned n = 0; n < 4; ++n) p[n] = (uint8_t)(x >> (n * 8));
}
static void Put16(uint8_t *p, int x) {
  unsigned u = (unsigned)(uint16_t)x;
  p[0] = (uint8_t)u; p[1] = (uint8_t)(u >> 8);
}
static size_t Clip(uint8_t *out, uint32_t event, uint32_t rate,
                   uint32_t channels, uint32_t frames, int amplitude) {
  Put32(out, event); Put32(out + 4, rate); Put32(out + 8, channels);
  Put32(out + 12, frames);
  for (uint32_t i = 0; i < frames; ++i)
    for (uint32_t c = 0; c < channels; ++c)
      Put16(out + 16 + 2 * (i * channels + c), c ? -amplitude : amplitude);
  return 16 + (size_t)frames * channels * 2;
}
int main(int argc, char **argv) {
  uint8_t block[128] = {'S','A','U','1'};
  char error[128];
  int16_t pcm[64] = {0};
  Put32(block + 4, 1);
  size_t n = 8 + Clip(block + 8, 1, 16000, 2, 4, 20000);
  assert(SonicAudioLoad(block, n, error, sizeof(error)) && !error[0]);
  /* Every truncation must reject cleanly and retain the previous good bank. */
  for (size_t cut = 0; cut < n; ++cut) {
    assert(!SonicAudioLoad(block, cut, error, sizeof(error)));
    assert(error[0]);
  }
  SonicAudioEvents(1);
  for (int i = 0; i < 4; ++i) { pcm[i * 2] = 25000; pcm[i * 2 + 1] = -25000; }
  SonicAudioMix(pcm, 4, 16000);
  for (int i = 0; i < 4; ++i) assert(pcm[i * 2] == 32767 && pcm[i * 2 + 1] == -32768);
  memset(pcm, 0, sizeof(pcm));
  SonicAudioMix(pcm, 4, 16000);
  for (int i = 0; i < 8; ++i) assert(pcm[i] == 0);
  SonicAudioEvents(1); SonicAudioReset(); SonicAudioMix(pcm, 4, 16000);
  assert(pcm[0] == 0);

  /* Resampling must preserve channel mapping, length and half-frame values. */
  n = 8 + Clip(block + 8, 1, 16000, 1, 4, 0);
  for (unsigned i = 0; i < 4; ++i) Put16(block + 24 + i * 2, (int)i * 1000);
  assert(SonicAudioLoad(block, n, error, sizeof(error)));
  SonicAudioEvents(1); SonicAudioMix(pcm, 8, 32000);
  for (int i = 0; i < 8; ++i) {
    int expected = i < 6 ? i * 500 : 3000;
    assert(pcm[i * 2] == expected && pcm[i * 2 + 1] == expected);
  }
  block[n] = 0;
  assert(!SonicAudioLoad(block, n + 1, error, sizeof(error)));
  Put32(block + 12, 100);
  assert(!SonicAudioLoad(block, n, error, sizeof(error)));
  Put32(block + 12, 16000); Put32(block + 16, 3);
  assert(!SonicAudioLoad(block, n, error, sizeof(error)));
  Put32(block + 16, 1); Put32(block + 20, UINT32_MAX);
  assert(!SonicAudioLoad(block, n, error, sizeof(error)));
  Put32(block + 20, 4); Put32(block + 8, 3);
  assert(!SonicAudioLoad(block, n, error, sizeof(error)));

  /* A release event must interrupt the charge voice, not stack both clips. */
  Put32(block + 4, 2);
  n = 8 + Clip(block + 8, 4, 16000, 1, 4, 10000);
  n += Clip(block + n, 8, 16000, 1, 4, 5000);
  assert(SonicAudioLoad(block, n, error, sizeof(error)));
  memset(pcm, 0, sizeof(pcm));
  SonicAudioEvents(4); SonicAudioEvents(8); SonicAudioMix(pcm, 1, 16000);
  assert(pcm[0] == 5000 && pcm[1] == 5000);
  Put32(block + 8 + 24, 4);
  assert(!SonicAudioLoad(block, n, error, sizeof(error)));
  SonicAudioUnload();
  memset(pcm, 0, sizeof(pcm));
  SonicAudioEvents(255); SonicAudioMix(pcm, 4, 32040);
  assert(pcm[0] == 0);

  if (argc > 1) {
    FILE *f = fopen(argv[1], "rb"); assert(f);
    assert(!fseek(f, 0, SEEK_END)); long bytes = ftell(f); assert(bytes > 0);
    rewind(f); uint8_t *packed = malloc((size_t)bytes); assert(packed);
    assert(fread(packed, 1, (size_t)bytes, f) == (size_t)bytes); fclose(f);
    assert(SonicAudioLoad(packed, (size_t)bytes, error, sizeof(error)));
    free(packed);
    int16_t *samples = calloc(32040 * 4u, sizeof(int16_t)); assert(samples);
    for (unsigned effect = 1; effect <= 128; effect <<= 1) {
      memset(samples, 0, 32040 * 4u * sizeof(int16_t));
      SonicAudioReset(); SonicAudioEvents(effect); SonicAudioMix(samples, 32040 * 2u, 32040);
      size_t nonzero = 0;
      for (size_t i = 0; i < 32040 * 4u; ++i) nonzero += samples[i] != 0;
      assert(nonzero > 10);
    }
    free(samples); SonicAudioUnload();
  }
  puts("Sonic audio: parser bounds, transactional load, clipping, resampling, reset and events passed.");
  return 0;
}

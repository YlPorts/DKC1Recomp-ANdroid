#!/usr/bin/env python3
import sys,unittest,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from mod_regions import permitted,TEXT,ranges
from mod_pack import data_chunks
from build_spanish_mod import wrap
class ModTools(unittest.TestCase):
 def test_protected_code(self):
  for x in [0,0x8000,0x18100,0xa8000,0x3b8000]:self.assertFalse(permitted(x,1))
  self.assertFalse(permitted(0x1fffffff,100))
  self.assertFalse(permitted(0x400000,1))
 def test_v12_exact_data_boundaries(self):
  for a,b in [(0x1340,0x1a40),(0x1a41,0x7a21),(0x1efde,0x1efe8)]:
   self.assertTrue(permitted(a,b-a))
  for a in (0x133f,0x1a40,0x7a21,0x1efdd,0x7fff,0x8000,0xffc0,0xfffc):
   self.assertFalse(permitted(a,1))
  for a,b in [(0x1340,0x1a40),(0x1a41,0x7a21)]:
   self.assertFalse(permitted(a-1,b-a+1));self.assertFalse(permitted(a,b-a+1))
  self.assertFalse(permitted(0x1340,0x7a21-0x1340))
 def test_language(self):
  for a,b in TEXT:
   self.assertTrue(permitted(a,b-a,True));self.assertFalse(permitted(a-1,b-a+1,True));self.assertFalse(permitted(a,b-a+1,True))
 def test_normal_ranges(self):
  rs=ranges();self.assertTrue(all(a<b and b<=4194304 for a,b in rs));self.assertTrue(all(rs[i][1]<rs[i+1][0] for i in range(len(rs)-1)))
 def test_wrap_no_truncation(self):
  self.assertEqual(wrap('Solo tres vidas y tres intentos!',[24,18]),['Solo tres vidas y tres','intentos!'])
  self.assertIsNone(wrap('unapalabrademasiadolarga',[4,4]))
  random.seed(7)
  for _ in range(1000):
   s=' '.join(random.choice(['uno','dos','tres','cuatro']) for i in range(random.randint(1,20)))
   caps=[random.randint(6,30) for i in range(3)];out=wrap(s,caps)
   if out is not None:self.assertEqual(' '.join(x for x in out if x),s);self.assertTrue(all(len(t)<=c for t,c in zip(out,caps)))
 def test_data_diff(self):
  before=bytes(4194304);after=bytearray(before);after[0x10000]=1;after[0x10020]=2
  self.assertEqual(data_chunks(before,bytes(after)),[(0x10000,0x10021)])
  after[0x8000]=1
  with self.assertRaises(ValueError):data_chunks(before,bytes(after))
 def test_snes_tiles(self):
  try:
   from PIL import Image
   from png_to_snes4bpp import convert
  except ImportError:self.skipTest('Optional Pillow authoring tool')
  image=Image.new('P',(8,8));image.putpalette([0,0,0,255,0,0]+[0]*762);image.putpixel((0,0),1)
  tile,palette=convert(image);self.assertEqual(len(tile),32);self.assertEqual(tile[0],128);self.assertEqual(sum(tile[1:]),0);self.assertEqual(palette[2:4],b'\x1f\0')
  for y in range(8):
   for x in range(8):image.putpixel((x,y),(x+y)%16)
  tile,palette=convert(image)
  for y in range(8):
   for x in range(8):self.assertEqual(sum(((tile[(p//2)*16+2*y+p%2]>>(7-x))&1)<<p for p in range(4)),(x+y)%16)
  with self.assertRaises(ValueError):convert(image.convert('RGB'))
  image.putpixel((0,0),16)
  with self.assertRaises(ValueError):convert(image)
if __name__=='__main__':unittest.main(verbosity=2)

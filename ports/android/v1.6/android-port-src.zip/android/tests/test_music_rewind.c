#define _POSIX_C_SOURCE 200809L
#include "dkc1_msu1.h"
#include "desktop_rewind.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(void){
 char directory[]="/tmp/dkc-msu-XXXXXX";assert(mkdtemp(directory));char path[200],error[256];
 snprintf(path,sizeof path,"%s/track-1.pcm",directory);FILE *f=fopen(path,"wb");assert(f);
 const unsigned char header[8]={'M','S','U','1',0,0,0,0};assert(fwrite(header,1,8,f)==8);
 const unsigned char sample[4]={0x10,0x27,0xf0,0xd8};for(int i=0;i<2000;i++)assert(fwrite(sample,1,4,f)==4);assert(fclose(f)==0);
 Dkc1Msu1 *music=Dkc1Msu1Open(directory,error,sizeof error);assert(music);
 int16_t buffer[256];for(int i=0;i<256;i++)buffer[i]=100;
 Dkc1Msu1ObserveMusicState(music,0,1);assert(Dkc1Msu1CurrentTrack(music)==1);
 Dkc1Msu1Mix(music,buffer,128,2,32040);assert(buffer[0]==10100&&buffer[1]==-9900);
 Dkc1Msu1ObserveMusicState(music,0,0);for(int i=0;i<256;i++)buffer[i]=100;
 Dkc1Msu1Mix(music,buffer,128,2,32040);assert(buffer[0]==100&&buffer[1]==100);
 Dkc1Msu1Reset(music);Dkc1Msu1ObserveMusicState(music,0,1);memset(buffer,0,sizeof buffer);Dkc1Msu1Mix(music,buffer,128,2,32040);assert(buffer[0]==10000);
 Dkc1Msu1Close(music);unlink(path);rmdir(directory);
 uint8_t *rom=calloc(1,4194304);assert(rom);assert(!Dkc1Msu1ApplySpcMusicMute(rom,4194304,error,sizeof error));rom[0xaa9e5]=1;rom[0xaa9e6]=0xd4;
 assert(Dkc1Msu1ApplySpcMusicMute(rom,4194304,error,sizeof error));assert(rom[0xaa9e5]==0&&rom[0xaa9e6]==0x6f);free(rom);
 Dkc1RewindHistory history={0};assert(Dkc1RewindHistoryInit(&history,sizeof(uint64_t),3));
 for(uint64_t i=0;i<10;i++)assert(Dkc1RewindHistoryPush(&history,&i));
 for(uint64_t i=9;i>=7;i--){uint64_t actual=0;assert(Dkc1RewindHistoryPop(&history,&actual));assert(i==actual);}
 uint64_t value=0;assert(!Dkc1RewindHistoryPop(&history,&value));Dkc1RewindHistoryDestroy(&history);
 puts("MSU1_REWIND_PASS: mapped PCM mixing, SFX addition, stop/reset, mute byte guard, bounded history");return 0;
}

#include "sonic_mod.h"
#include "dkc1_wram_gen.h"
#include "sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
static uint8_t w[0x20000],before[0x20000];
static void set_player(unsigned state,int vx,int vy){
 Dkc1WramSetU16(w,DKC1_WRAM_Player_CurrentKongLo,1);
 Dkc1Actor_SetSpriteIDLo(w,2,1);
 Dkc1Actor_SetRAMTable1029Lo(w,2,(uint16_t)state);
 Dkc1Actor_SetSprXVelocity(w,2,(uint16_t)vx);
 Dkc1Actor_SetSprYVelocity(w,2,(uint16_t)vy);
}
int main(int argc,char **argv){
 assert(argc==2);memset(w,0x55,sizeof w);memcpy(before,w,sizeof w);
 assert(SonicModFilterInput(0xabcfff)==0xabcfff);SonicModBeforeVelocity(w,2);SonicModAfterFrame(w);assert(!memcmp(w,before,sizeof w));
 FILE *f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);long len=ftell(f);rewind(f);uint8_t *data=malloc((size_t)len);assert(data&&fread(data,1,(size_t)len,f)==(size_t)len);fclose(f);
 uint8_t h[32];char sha[65],err[192];sha256_compute(data,(size_t)len,h);for(int j=0;j<32;j++)snprintf(sha+j*2,3,"%02x",h[j]);free(data);
 assert(!SonicModLoad(argv[1],"0000000000000000000000000000000000000000000000000000000000000000",0,err,sizeof err));assert(!SonicModEnabled());
 assert(SonicModLoad(argv[1],sha,0,err,sizeof err));assert(SonicModEnabled());
 memset(w,0,sizeof w);Dkc1WramSetU16(w,DKC1_WRAM_Player_CurrentKongLo,1);Dkc1Actor_SetSpriteIDLo(w,2,1);Dkc1Actor_SetSprYVelocity(w,2,(uint16_t)-768);
 SonicModFilterInput(128);SonicModBeforeVelocity(w,2);assert(Dkc1Actor_SprXVelocity(w,2)==12);assert((int16_t)Dkc1Actor_SprYVelocity(w,2)==-768);
 SonicModBeforeVelocity(w,2);assert(Dkc1Actor_SprXVelocity(w,2)==12);
 /* Diddy is raw actor slot4. Preserve snapshot velocity after a reset and
  * apply only one increment; an inactive DK actor must remain unchanged. */
 SonicModResetState();Dkc1WramSetU16(w,DKC1_WRAM_Player_CurrentKongLo,2);Dkc1Actor_SetSpriteIDLo(w,4,2);Dkc1Actor_SetSprXVelocity(w,4,100);SonicModFilterInput(128);
 SonicModBeforeVelocity(w,2);assert(Dkc1Actor_SprXVelocity(w,2)==12);SonicModBeforeVelocity(w,4);assert(Dkc1Actor_SprXVelocity(w,4)==112);
 /* A native jump can be detected after its velocity boundary. If a scripted
  * state interrupts before the next boundary, the queued jump must be dropped
  * before returning to airborne movement. State 24 is native barrel carry. */
 SonicModResetState();memset(w,0,sizeof w);set_player(0,0,-768);
 SonicModFilterInput(0);SonicModBeforeVelocity(w,2);SonicModAfterFrame(w);
 SonicModFilterInput(1);set_player(1,0,512);SonicModAfterFrame(w);
 set_player(24,0,512);SonicModBeforeVelocity(w,2);SonicModAfterFrame(w);
 SonicModFilterInput(0);set_player(1,0,512);SonicModBeforeVelocity(w,2);
 assert((int16_t)Dkc1Actor_SprYVelocity(w,2)==512-0x38);
 /* A collision from before a scripted state must not erase the native speed
  * on return. With a clean adapter, right adds 12 to the restored 1024. */
 SonicModResetState();memset(w,0,sizeof w);set_player(0,1024,-768);
 SonicModFilterInput(0);SonicModBeforeVelocity(w,2);SonicModAfterFrame(w);
 set_player(24,0,-768);SonicModBeforeVelocity(w,2);SonicModAfterFrame(w);
 SonicModFilterInput(128);set_player(0,1024,-768);SonicModBeforeVelocity(w,2);
 assert((int16_t)Dkc1Actor_SprXVelocity(w,2)==1024+12);
 SonicModUnload();memcpy(before,w,sizeof w);SonicModBeforeVelocity(w,4);SonicModAfterFrame(w);assert(!memcmp(w,before,sizeof w));
 puts("Sonic host: SHA identity, disabled no-op, actor ownership, slot4 Tails and scripted-state reset tests passed");return 0;
}

#define _POSIX_C_SOURCE 200809L
#include "addon_runtime.h"
#include "sha256.h"
#include "snes/ppu.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static unsigned checks;
#define CHECK(x) do{assert(x);checks++;}while(0)
static unsigned char wram[0x20000],before[0x20000];
static void put32(unsigned char *p,unsigned v){for(unsigned i=0;i<4;i++)p[i]=(unsigned char)(v>>(i*8));}
static bool load(const char *script,const char *options){
 size_t n=strlen(script),size=20+n;unsigned char *data=calloc(1,size);CHECK(data);
 memcpy(data,"DKCLUA1\0",8);put32(data+8,(unsigned)n);memcpy(data+20,script,n);
 unsigned char digest[32];char sha[65],error[256];sha256_compute(data,size,digest);
 for(unsigned i=0;i<32;i++)snprintf(sha+2*i,3,"%02x",digest[i]);
 char path[]="/tmp/dkc-script-XXXXXX";int fd=mkstemp(path);CHECK(fd>=0);FILE *f=fdopen(fd,"wb");CHECK(f);
 CHECK(fwrite(data,1,size,f)==size);CHECK(fclose(f)==0);free(data);
 bool ok=AddonRuntimeLoad(path,sha,options,error,sizeof error);unlink(path);return ok;
}
int main(void){
 memset(wram,0x55,sizeof wram);memcpy(before,wram,sizeof wram);
 CHECK(AddonRuntimeFilterInput(0xabcdef,wram)==0xabcdef);AddonRuntimeBeforeVelocity(wram,2);AddonRuntimeAfterFrame(wram);CHECK(!memcmp(wram,before,sizeof wram));
 CHECK(load("return {filter_input=function(i) return i ~ 1 end, before_velocity=function(s) dkc.write16(0xe89+s,384) end}",""));
 CHECK(AddonRuntimeFilterInput(0xab0000,wram)==0xab0001);AddonRuntimeBeforeVelocity(wram,2);CHECK(wram[0xe8b]==128&&wram[0xe8c]==1);CHECK(!AddonRuntimeFaulted());
 CHECK(load("local speed=dkc.choice('speed')=='fast' and 768 or 256; return {before_velocity=function(s) dkc.write16(0xe89+s,speed) end}","speed=fast\n"));
 AddonRuntimeBeforeVelocity(wram,4);CHECK(wram[0xe8d]==0&&wram[0xe8e]==3);
 CHECK(load("return {before_velocity=function(s) dkc.write16(0xe89+s,123); error('fixture') end}",""));
 memcpy(before,wram,sizeof wram);AddonRuntimeBeforeVelocity(wram,2);CHECK(AddonRuntimeFaulted());CHECK(!memcmp(before,wram,sizeof wram));CHECK(strstr(AddonRuntimeError(),"fixture"));
 CHECK(load("return {before_velocity=function(s) dkc.write16(0xe89+s,123); while true do end end}",""));
 AddonRuntimeBeforeVelocity(wram,2);CHECK(AddonRuntimeFaulted());CHECK(!memcmp(before,wram,sizeof wram));
 CHECK(load("return {filter_input=function(i) dkc.write16(0xe89,1); return i end}",""));
 CHECK(AddonRuntimeFilterInput(19,wram)==19);CHECK(AddonRuntimeFaulted());CHECK(!memcmp(before,wram,sizeof wram));
 CHECK(load("return {filter_input=function(i) return 0x1000000 end}",""));CHECK(AddonRuntimeFilterInput(23,wram)==23);CHECK(AddonRuntimeFaulted());
 CHECK(load("return {apu_command=function(c) return 0x413==c and 0x400 or c end}",""));CHECK(AddonRuntimeApuCommand(0x413,wram)==0x400);CHECK(AddonRuntimeApuCommand(0x100,wram)==0x100);
 CHECK(load("return {prepare_frame=function() dkc.hide_oam(0); error('restore') end}",""));
 Ppu *ppu=calloc(1,sizeof *ppu);CHECK(ppu);ppu->oam[0]=0x8070;AddonRuntimePrepareFrame(ppu,wram,0);CHECK(ppu->oam[0]==0x8070);CHECK(AddonRuntimeFaulted());free(ppu);
 CHECK(!load("return {}","bad options\n"));
 CHECK(!load("return {}","speed=fast"));
 CHECK(load("return {}",""));AddonRuntimeUnload();CHECK(!AddonRuntimeFaulted());CHECK(!AddonRuntimeEnabled());
 printf("{\"passed\":true,\"assertions\":%u,\"scope\":\"generic host bridge, script-only behavior, rollback, phases and OAM restoration\"}\n",checks);
 return 0;
}

#include "sonic_physics.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 SonicPhysics s;SonicPhysicsInput i={.grounded=true,.right=true};
 SonicPhysicsReset(&s,0,0,false);
 for(int frame=1;frame<=128;frame++){SonicPhysicsStep(&s,&i);assert(s.vx==frame*12);}
 for(int frame=0;frame<60;frame++){SonicPhysicsStep(&s,&i);assert(s.vx==1536);}
 i.right=false;for(int frame=127;frame>=0;frame--){SonicPhysicsStep(&s,&i);assert(s.vx==frame*12);}
 i.left=true;SonicPhysicsStep(&s,&i);assert(s.vx==-12&&s.left);
 SonicPhysicsReset(&s,0,0,false);i=(SonicPhysicsInput){.grounded=true,.down=true,.jump_pressed=true,.jump_held=true};
 assert(SonicPhysicsStep(&s,&i)==SONIC_EV_CHARGE&&s.charge==0&&s.charging);
 assert(SonicPhysicsStep(&s,&i)==SONIC_EV_CHARGE&&s.charge==0x200);
 i.down=false;i.jump_pressed=false;assert(SonicPhysicsStep(&s,&i)==SONIC_EV_RELEASE&&s.vx==0x900&&s.rolling);
 SonicPhysicsReset(&s,0,0,false);i=(SonicPhysicsInput){.just_jumped=true,.jump_held=true};
 assert(SonicPhysicsStep(&s,&i)==SONIC_EV_JUMP&&s.vy==-0x680);
 i.just_jumped=false;SonicPhysicsStep(&s,&i);assert(s.vy==-0x680+0x38);
 i.jump_held=false;SonicPhysicsStep(&s,&i);assert(s.vy==-0x400+0x38);
 i.ceiling_blocked=true;SonicPhysicsStep(&s,&i);assert(s.vy==0x38);
 SonicPhysicsReset(&s,0x800,0,false);s.rolling=true;i=(SonicPhysicsInput){.grounded=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==0x800-6);
 i.wall_blocked=true;SonicPhysicsStep(&s,&i);assert(s.vx==0&&!s.rolling);
 /* A roll-jump preserves momentum and intentionally prevents air steering. */
 SonicPhysicsReset(&s,0x800,0,false);s.rolling=true;i=(SonicPhysicsInput){.just_jumped=true,.jump_held=true,.left=true};
 SonicPhysicsStep(&s,&i);i.just_jumped=false;SonicPhysicsStep(&s,&i);assert(s.vx==0x800&&s.roll_jump);
 /* Sonic_ChgJumpDir caps only in the pressed direction. Braking an airborne
  * launch must not instantly destroy its speed on the opposite side. Use an
  * upward speed below the drag interval to isolate the directional control. */
 SonicPhysicsReset(&s,0x900,-0x600,false);i=(SonicPhysicsInput){.left=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==0x900-24&&s.left);
 SonicPhysicsReset(&s,-0x900,-0x600,true);i=(SonicPhysicsInput){.right=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==-0x900+24&&!s.left);
 /* Pressing with the launch still applies Sonic 2's same-direction cap. */
 SonicPhysicsReset(&s,0x900,-0x600,false);i=(SonicPhysicsInput){.right=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==0x600);
 SonicPhysicsReset(&s,-0x900,-0x600,true);i=(SonicPhysicsInput){.left=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==-0x600);
 /* Crossing the normal speed limit by one air-acceleration step clamps. */
 SonicPhysicsReset(&s,0x5ff,-0x600,false);i=(SonicPhysicsInput){.right=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==0x600);
 SonicPhysicsReset(&s,-0x5ff,-0x600,true);i=(SonicPhysicsInput){.left=true};
 SonicPhysicsStep(&s,&i);assert(s.vx==-0x600);
 puts("Sonic2 movement: acceleration, friction, directional air cap, spindash, jump release, wall and roll-jump checks passed");return 0;
}

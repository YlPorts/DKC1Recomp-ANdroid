package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Install the delivered packages over an exact previous-installation metadata fixture. */
public final class ActualMigrationTests {
    private static int checks;
    private static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    private static String sha(byte[] bytes)throws Exception{return ContentMods.hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    private static ContentMods.Info install(File root,File cache,String path)throws Exception{try(InputStream in=Files.newInputStream(Path.of(path))){return ContentMods.install(root,cache,in);}}
    public static void main(String[] args)throws Exception {
        if(args.length!=5)throw new IllegalArgumentException("clean ROM, Spanish mod, previous Sonic mod, independent Sonic mod, report.json");
        Path tmp=Files.createTempDirectory("dkc-real-migration-");
        try{
            File root=tmp.resolve("root").toFile(),cache=tmp.resolve("cache").toFile();Path game=root.toPath().resolve("game");Files.createDirectories(game);byte[] rom=Files.readAllBytes(Path.of(args[0]));Files.write(game.resolve("dkc1.sfc"),rom);
            ContentMods.Info spanish=install(root,cache,args[1]),old=install(root,cache,args[2]);
            check(old.digest.equals("7b27397baf6cf198ae80c1751a2e1fd1e0352d482ff3cb3ba41b295c334ae1db"),"actual previously delivered package identity");
            Map<String,String> soloKeys=new TreeMap<>(),mixedKeys=new TreeMap<>();Path selection=root.toPath().resolve("mods-v2/selections/"+old.digest+".txt");Files.createDirectories(selection.getParent());
            String[] modes={"both","sonic","tails"};Map<Path,byte[]> retained=new LinkedHashMap<>();
            for(String mode:modes){
                Files.writeString(selection,"characters="+mode+"\n");
                Files.writeString(root.toPath().resolve("mods-v2/enabled.txt"),old.digest+"\n");soloKeys.put(mode,ContentMods.activeKey(root));
                SortedSet<String> ids=new TreeSet<>(Arrays.asList(old.digest,spanish.digest));Files.writeString(root.toPath().resolve("mods-v2/enabled.txt"),String.join("\n",ids)+"\n");mixedKeys.put(mode,ContentMods.activeKey(root));
                for(String key:Arrays.asList(soloKeys.get(mode),mixedKeys.get(mode)))for(String profile:Arrays.asList("4x3","16x9","16x10-msu1")){
                    Path save=game.resolve("quicksave-"+profile+"-mod-"+key+".state");byte[] bytes=("previous-user-save:"+mode+":"+profile).getBytes(StandardCharsets.UTF_8);Files.write(save,bytes);retained.put(save,bytes);
                }
            }
            // The previous app last ran Tails with the Spanish package enabled.
            byte[] preferences=Files.readAllBytes(selection);ContentMods.Info updated=install(root,cache,args[3]);
            check(updated.saveProfile.equals(old.digest),"new package explicitly preserves previous profile");
            check(updated.id.equals(old.id),"same mod identity");check(updated.runtime.scripted(),"independent Lua package");
            check(ContentMods.selected(root,updated).get("characters").equals("tails"),"actual selection migrated");
            check(ContentMods.active(root).equals(new TreeSet<>(Arrays.asList(updated.digest,spanish.digest))),"activation migrated with Spanish preserved");
            check(ContentMods.prepare(root).key.equals(mixedKeys.get("tails")),"resume points to the previous save");
            for(String mode:modes){ContentMods.select(root,updated.digest,"characters",mode);ContentMods.Session current=ContentMods.prepare(root);check(current.key.equals(mixedKeys.get(mode)),"same mixed profile for "+mode);check(current.runtimeOptions.equals("characters="+mode+"\n"),"selection passed to Lua for "+mode);}
            ContentMods.toggle(root,spanish.digest);for(String mode:modes){ContentMods.select(root,updated.digest,"characters",mode);check(ContentMods.prepare(root).key.equals(soloKeys.get(mode)),"same standalone profile for "+mode);}
            for(Map.Entry<Path,byte[]> entry:retained.entrySet())check(Arrays.equals(Files.readAllBytes(entry.getKey()),entry.getValue()),"save bytes retained: "+entry.getKey().getFileName());
            check(Arrays.equals(Files.readAllBytes(selection),preferences),"previous choices retained for rollback");
            check(ContentMods.installed(root).size()==3,"both old and new packages retained alongside Spanish");
            ContentMods.disableAll(root);check(ContentMods.prepare(root).key.isEmpty(),"stock profile restored");check(Arrays.equals(rom,Files.readAllBytes(game.resolve("dkc1.sfc"))),"original ROM unchanged");
            Files.writeString(Path.of(args[4]),"{\n  \"passed\": true,\n  \"assertions\": "+checks+",\n  \"scope\": \"Actual delivered packages over previous-installation Java metadata fixture; state bytes are preservation sentinels, not gameplay execution\",\n  \"old_package_sha256\": \""+old.digest+"\",\n  \"new_package_sha256\": \""+updated.digest+"\",\n  \"spanish_package_sha256\": \""+spanish.digest+"\",\n  \"rom_sha256\": \""+sha(rom)+"\",\n  \"all_three_profiles_migrated\": true,\n  \"spanish_combination_preserved\": true,\n  \"active_selection_migrated\": true,\n  \"save_files_preserved\": "+retained.size()+",\n  \"old_package_and_choices_retained\": true\n}\n");
            System.out.println("Actual package migration passed: "+checks+" assertions.");
        }finally{try(java.util.stream.Stream<Path> paths=Files.walk(tmp)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException e){throw new UncheckedIOException(e);}});}}
    }
}

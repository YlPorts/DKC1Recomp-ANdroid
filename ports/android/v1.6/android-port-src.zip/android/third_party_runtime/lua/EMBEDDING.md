# Embedded independent mod VM

Lua 5.4.9 comes from the official archive recorded in `PROVENANCE.json`. All
63 files in `src/` are byte-identical to that release; `LICENSE.txt` reproduces
the license in `src/lua.h`. No download is needed to build this dependency.

The APK links the core, auxiliary library, base, math, string and table units.
Do not compile the CLI (`lua.c`, `luac.c`), generic library opener (`linit.c`),
or the unused `liolib.c`, `loslib.c`, `loadlib.c`, `ldblib.c`, `lcorolib.c`,
`lutf8lib.c`. Compile the Lua target with the function-like definition
`-Dluai_makeseed(L)=0x444b4331u` to remove the stock time/address hash seed.
Use position-independent code when linking into the Android shared library.

The host in `../../native/mod_script.c` loads text sources only, at most
256 KiB. A source chunk returns a table of named callback functions. The host
calls those functions using at most eight integer arguments and results.
Boolean results become 0/1; nil results retain the caller's default. Missing
callbacks are allowed. Wrong result types, Lua exceptions, or exceeded limits
disable that instance and leave the call's result values unchanged.

Each VM has an 8 MiB allocator limit and each source initialization/callback
has a one-million-instruction limit. Host callbacks execute as C code: their
implementations must separately check addresses, lengths and workload bounds.
The VM cannot roll back game memory that a host callback has already changed;
the game adapter owns any transaction or error rollback policy.

Only these additional libraries are exposed:

- `math`: numeric operations and constants; no random or randomseed.
- `string`: byte, char, len, lower, rep, reverse, sub, upper.
- `table`: concat, pack, unpack.

The base library omits collectgarbage, dofile, load, loadfile, require, print,
warn, pcall, xpcall, getmetatable and setmetatable. `tostring` of a table or
function returns its type name without a process-specific pointer. IO, OS,
package, debug, coroutine and UTF-8 libraries are not opened. Neither binary
chunks nor native libraries can be loaded by a script. String pattern matching
and table movement/sorting functions are intentionally excluded because their
C loops do not consume VM instructions. Use explicit Lua loops for those
operations so the budget remains effective. Numeric iteration is recommended
where callback behavior requires an explicit, portable order.

Run the standalone regression without the game engine or ROM:

```sh
python android/tools/test_mod_script.py --out verification/mod-script
```

It checks ordinary callbacks, missing functions, defaults, atomic result
decoding, the restricted environment, source rejection, instruction exhaustion,
memory exhaustion, recursive failure and permanent fault behavior. The default
build uses AddressSanitizer and UndefinedBehaviorSanitizer; LeakSanitizer is
disabled for debugger/ptrace environments. This test does not establish Android
device compatibility or correctness of game-specific script behavior.

# Third-party notices for this Android overlay

This Android overlay adds a host and a general scripting API to DKC1Recomp.
It does not contain retail ROMs, generated game sources, private save states
or SDK binaries. The separately packaged Sonic mod and gameplay evidence have
their own content provenance; the host's license does not relicense those assets.

The new host, tools, tests and documentation are covered by `LICENSE` in this
folder. They use the project's existing APIs; the project and its dependencies
retain their original conditions. In particular:

- DKC1Recomp's authored host/tooling is MIT licensed. Retain its original root
  `LICENSE` and `THIRD_PARTY_NOTICES.md` when using the prepared checkout.
- The pinned `snesrecomp` fork identifies its framework license as PolyForm
  Noncommercial 1.0.0 and contains additional notices for incorporated code.
  An MIT notice on these new Android files does not remove those conditions.
- Structural metadata in the original project's `recomp/` retains its stated
  GPL-3 disassembly provenance. Do not remove its file headers or root notices.
- SDL2 is downloaded unmodified at the same commit for its Java and native
  components. Its zlib license and source notices remain in the downloaded tree.
- Lua 5.4.9 is included as source in `third_party_runtime/lua/` under its MIT
  license. Retain `LICENSE.txt`, `PROVENANCE.json` and the original source
  notices. The APK includes the notice as `assets/licenses/Lua-LICENSE.txt`.
  `EMBEDDING.md` describes the restricted host API and excluded libraries.
- `runner/desktop_audio_rate.c` and the other reused game/runtime units remain
  upstream files, subject to the original project's documented third-party
  provenance. They are not copied into this overlay or relicensed here.
- Gradle, AGP and the Android SDK/NDK remain under their own licenses. The
  preparation tools do not accept SDK licenses, download ROMs or upload private
  inputs on the developer's behalf.

Review and include the relevant upstream notices before distributing a built
binary. This source-only overlay does not itself establish permission to
redistribute game content or a conclusion about the licensing of a final build.

Donkey Kong Country, Nintendo, Rare and related names and trademarks belong to
their respective owners. This is an unofficial development project.

# Voces de Donkey/Diddy con el addon Sonic — 1.3.1

El cambio actúa al enviar un efecto al controlador SPC. Mientras el addon está
cargado, sustituye doce IDs de voz de Donkey/Diddy por el efecto vacío original.
Los IDs de daño también activan el sonido de daño Sonic del banco existente.
No necesita otro addon ni cambia su hash, sus opciones, los perfiles de partida,
la ROM, el volumen maestro ni las reglas de enemigos/animales.

## Fuente y bytes

ROM admitida, headerless USA 1.0:
`fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15`.

Fuentes primarias consultadas:

- https://github.com/Yoshifanatic1/Donkey-Kong-Country-1-Disassembly/blob/main/DKC1/Misc_Defines_DKC1.asm
- https://github.com/Yoshifanatic1/Donkey-Kong-Country-1-Disassembly/blob/main/DKC1/Routine_Macros_DKC1.asm
- https://github.com/Yoshifanatic1/Donkey-Kong-Country-1-Disassembly/blob/main/DKC1/SPC700/SPC700_Engine_DKC1.asm

Los nombres son ayudas de navegación. La ruta de envío, los canales y el efecto
vacío fueron contrastados con bytes de la ROM limpia:

- `$BF:FB03`, `$BF:FB16`, `$BF:FB34` seleccionan canales `$04`, `$05`, `$06`.
  `$BF:FB19` combina canal e ID en X y llama `$8A:B1AA`.
- `$8A:B1AA` envía X a `$2141/$2142`, efectúa el protocolo de confirmación y
  preserva X y las banderas. Se llama a la función real; el wrapper cambia sólo
  el ID durante el envío y restaura X al retornar.
- El bloque `$C9:2D95` carga `$0E26` bytes en SPC `$2380`. Su entrada ID cero
  apunta a `$2FB4`; allí hay un opcode `$00`. La tabla SPC `$100F` dirige ese
  opcode a `$0A69`, que termina el efecto de ese canal. El juego original usa
  también ID cero, por ejemplo al terminar el efecto de K. Rool en `$BE:EEB8`.
- El filtro exige el canal completo entre 4 y 6; nunca selecciona otros
  comandos por coincidencia casual de su byte bajo.

| IDs | Uso original | Nuevo resultado |
| --- | --- | --- |
| 05 | Diddy muerde el dedo | Efecto vacío |
| 13 | Aullido DK | Efecto vacío |
| 3E / 3F | Voz Diddy / DK | Efecto vacío |
| 40 / 41 | Voz de equilibrio DK / Diddy | Efecto vacío |
| 43 / 46 | Daño Diddy / DK | Efecto vacío + daño Sonic (evento 16) |
| 44 / 45 | Tragar DK / Diddy, sin uso normal documentado | Efecto vacío |
| 5D / 5E | Diddy / DK atrapado en barril | Efecto vacío |

Se preservan las pisadas, el agua, el salto del animal, el ruido de vagoneta,
la música, los efectos de enemigos y los de personajes NPC. Los otros efectos
no vocales de los Kongs (aterrizajes, rascarse, cambio) no son parte de este
filtro. El addon sigue usando los ocho efectos de Sonic incluidos en v1.0.

## Compilación y prueba de contrato

Añadir `native/sonic_sfx_hook.c` al target y estas opciones del enlazador:

```
-Wl,--wrap=APU_SubmitCommand_M0X0
-Wl,--wrap=APU_SubmitCommand_M1X0
```

Desde la raíz del engine con el overlay aplicado:

```sh
cc -O2 -std=c11 -I android/native -I snesrecomp/runner/src \
  -I snesrecomp/runner/src/snes android/tests/test_sonic_sfx_hook.c \
  android/native/sonic_sfx_hook.c -o /tmp/test_sonic_sfx_hook
/tmp/test_sonic_sfx_hook
```

La prueba recorre los 65.536 comandos para ambos anchos de acumulador, con el
addon activo e inactivo: 262.144 llamadas. Comprueba el argumento realmente
recibido por la función original, una sola llamada por envío, los eventos,
el estado CPU entero frente a los efectos de la original y la propagación de
retornos no locales. Hay exactamente 36 comandos sustituidos (12 IDs × 3
canales). No sustituye ninguno con el addon desactivado.

El tap opcional `DKC_SONIC_SFX_TRACE=1` escribe exclusivamente los envíos
sustituidos. Por defecto no escribe nada. No controla el filtro.

## Evidencia real y límites

`audio-v131/evidence/report.json` registra el hash del ejecutable y del estado
inmutable, las entradas, hashes de memorias/fotograma/PCM y los IDs enviados.
El runner usa los objetos nativos de 1.3 y añade únicamente el wrapper de audio
para aislar su efecto. Las pruebas de integración final deben usar además el
APK 1.3.1 y sus demás cambios.

Se compararon reposo (600 frames), salto (160), avance/daño (480) y cambio de
turno (181) desde un estado auténtico de Jungle Hijinxs con ambos compañeros
rescatados. Todos conservan frame/WRAM/VRAM/CGRAM/OAM entre 1.3 y el wrapper.
Con el addon desactivado conservan también el PCM completo. El caso de salto,
sin voz filtrada, conserva el PCM exacto incluso con el addon activo.
Reposo, daño y cambio cubren envíos `$0413`, `$0546` y `$063E`; sólo el de daño
activa evento Sonic 16. Tres reproducciones del candidato coinciden byte a byte en reposo, daño y
cambio, incluido el PCM completo. Una entrada fresca mediante controles desde
el arranque, con `recipes/route_jungle.dks`, completa 7.594 frames: conserva los
seis hashes de imagen/memorias frente a 1.3 y observa además `$063F`, `$0513`
y `$065D` (Diddy atrapado). El JSON es la autoridad sobre su terminación.

No constituye una partida completa ni una prueba en un teléfono. Los otros
IDs tienen cobertura del contrato exhaustivo y de la fuente, pero no se
etiquetan como observados en gameplay si no aparecen en el registro.

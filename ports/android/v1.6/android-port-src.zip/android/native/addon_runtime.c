#include "addon_runtime.h"
#include "mod_script.h"
#include "mod_media.h"
#include "sha256.h"
#include "snes/ppu.h"
#include "lua.h"
#include "lauxlib.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Generic, versioned capability bridge. Character identities, game states,
 * movement constants, frame selection and sound policy live in the package. */
enum { MAX_BUNDLE=24*1024*1024, MAX_WRITES=256, MAX_DRAWS=128, MAX_SOUNDS=64 };
enum Phase { PHASE_INIT,PHASE_RESET,PHASE_INPUT,PHASE_VELOCITY,PHASE_AFTER,PHASE_END,PHASE_APU,PHASE_PREPARE,PHASE_DRAW };
typedef struct { unsigned addr;uint16_t old; } Write;
typedef struct { unsigned frame,num,den;int x,y;bool flip; } Draw;
typedef struct { uint32_t play,stop; } Sound;
static ModScript *s_script;
static uint8_t *s_wram;
static Ppu *s_ppu,*s_hidden_ppu;
static enum Phase s_phase;
static char s_options[4097],s_error[256];
static Write s_writes[MAX_WRITES];static unsigned s_write_count;
static Draw s_draws[MAX_DRAWS];static unsigned s_draw_count;
static uint64_t s_draw_pixels;
static Sound s_sounds[MAX_SOUNDS];static unsigned s_sound_count;
static uint16_t s_oam[128];static bool s_hidden[128];
static bool s_render_ready;

static uint32_t le32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static bool fail(char *e,size_t n,const char *m){if(e&&n)snprintf(e,n,"%s",m);return false;}
static bool check_hash(const uint8_t *p,size_t n,const char *hex){
 if(!hex||strlen(hex)!=64)return false;
 uint8_t digest[32];sha256_compute(p,n,digest);
 static const char digits[]="0123456789abcdef";
 for(unsigned i=0;i<32;i++)if(hex[2*i]!=digits[digest[i]>>4]||hex[2*i+1]!=digits[digest[i]&15])return false;
 return true;
}
static void restore_oam(void){
 if(s_hidden_ppu)for(unsigned i=0;i<128;i++)if(s_hidden[i])s_hidden_ppu->oam[i*2]=s_oam[i];
 memset(s_hidden,0,sizeof s_hidden);s_hidden_ppu=NULL;
}
bool AddonRuntimeEnabled(void){return s_script&&ModScriptEnabled(s_script)&&!s_error[0];}
bool AddonRuntimeFaulted(void){return s_error[0]||(s_script&&!ModScriptEnabled(s_script));}
const char *AddonRuntimeError(void){return s_error[0]?s_error:s_script?ModScriptError(s_script):"";}
static void fault(const char *reason){
 snprintf(s_error,sizeof s_error,"El mod se detuvo: %.220s",reason);
 restore_oam();ModMediaResetAudio();s_render_ready=false;
}
static bool call(const char *name,enum Phase phase,const int64_t *args,size_t nargs,int64_t *result,size_t nresult){
 if(!AddonRuntimeEnabled())return false;
 s_phase=phase;s_write_count=s_draw_count=s_sound_count=0;s_draw_pixels=0;
 bool ok=ModScriptCall(s_script,name,args,nargs,result,nresult);
 if(!ok){
  if(s_wram)while(s_write_count){Write *w=&s_writes[--s_write_count];s_wram[w->addr]=(uint8_t)w->old;s_wram[w->addr+1]=(uint8_t)(w->old>>8);}
  fault(ModScriptError(s_script));return false;
 }
 for(unsigned i=0;i<s_sound_count;i++)ModMediaPlay(s_sounds[i].play,s_sounds[i].stop);
 for(unsigned i=0;i<s_draw_count;i++){Draw *d=&s_draws[i];ModMediaDraw(s_ppu,d->frame,d->x,d->y,d->flip,d->num,d->den);}
 return true;
}
static lua_Integer integer(lua_State *l,int index,lua_Integer min,lua_Integer max){
 lua_Integer value=luaL_checkinteger(l,index);
 if(value<min||value>max)luaL_error(l,"argumento %d fuera de rango",index);
 return value;
}
static int read16(lua_State *l){
 unsigned addr=(unsigned)integer(l,1,0,0x1fffe);
 if(!s_wram)return luaL_error(l,"memoria del juego no disponible en este evento");
 lua_pushinteger(l,s_wram[addr]|(unsigned)s_wram[addr+1]<<8);return 1;
}
static int write16(lua_State *l){
 unsigned addr=(unsigned)integer(l,1,0,0x1fffe),value=(unsigned)integer(l,2,0,65535);
 if(!s_wram||(s_phase!=PHASE_VELOCITY&&s_phase!=PHASE_AFTER))return luaL_error(l,"escritura fuera de un evento de juego");
 if(s_write_count==MAX_WRITES)return luaL_error(l,"demasiadas escrituras en un evento");
 s_writes[s_write_count++]=(Write){addr,(uint16_t)(s_wram[addr]|(unsigned)s_wram[addr+1]<<8)};
 s_wram[addr]=(uint8_t)value;s_wram[addr+1]=(uint8_t)(value>>8);return 0;
}
static int choice(lua_State *l){
 size_t length;const char *key=luaL_checklstring(l,1,&length);
 if(!length||length>32)return luaL_error(l,"selector invalido");
 for(const char *line=s_options;*line;){
  const char *end=strchr(line,'\n');if(!end)end=line+strlen(line);
  const char *eq=memchr(line,'=',(size_t)(end-line));
  if(eq&&(size_t)(eq-line)==length&&!memcmp(line,key,length)){lua_pushlstring(l,eq+1,(size_t)(end-eq-1));return 1;}
  line=*end?end+1:end;
 }
 lua_pushnil(l);return 1;
}
static bool display(void){return s_ppu&&!PPU_forcedBlank(s_ppu)&&PPU_brightness(s_ppu)&&((s_ppu->screenEnabled[0]|s_ppu->screenEnabled[1])&0x10);}
static int display_enabled(lua_State *l){lua_pushboolean(l,display());return 1;}
static int oam(lua_State *l){
 unsigned i=(unsigned)integer(l,1,0,127);
 if(!s_ppu||s_phase!=PHASE_PREPARE)return luaL_error(l,"OAM solo disponible al preparar la imagen");
 unsigned low=s_ppu->oam[i*2],high=s_ppu->oam[i*2+1],extra=s_ppu->highOam[i>>2]>>((i&3)*2);
 int x=(int)((low&255)|((extra&1)<<8));if(x>=256)x-=512;
 unsigned raw_y=low>>8;int y=raw_y>=224?(int)raw_y-256:(int)raw_y;
 static const unsigned sizes[8][2]={{8,16},{8,32},{8,64},{16,32},{16,64},{32,64},{16,32},{16,32}};
 lua_pushinteger(l,x);lua_pushinteger(l,y);lua_pushinteger(l,high>>8);lua_pushinteger(l,high&511);
 lua_pushinteger(l,sizes[PPU_objSize(s_ppu)][(extra>>1)&1]);lua_pushinteger(l,raw_y);return 6;
}
static int hide_oam(lua_State *l){
 unsigned i=(unsigned)integer(l,1,0,127);
 if(!s_ppu||s_phase!=PHASE_PREPARE)return luaL_error(l,"ocultacion OAM fuera de preparacion");
 if(!s_hidden[i]){s_hidden_ppu=s_ppu;s_hidden[i]=true;s_oam[i]=s_ppu->oam[i*2];s_ppu->oam[i*2]=(s_oam[i]&255)|0xf000;}
 return 0;
}
static int frame_bounds(lua_State *l){
 unsigned frame=(unsigned)integer(l,1,0,4095),w,h;int first,last;
 if(!ModMediaFrameBounds(frame,&first,&last,&w,&h))return luaL_error(l,"fotograma inexistente");
 lua_pushinteger(l,first);lua_pushinteger(l,last);lua_pushinteger(l,w);lua_pushinteger(l,h);return 4;
}
static int draw(lua_State *l){
 if(s_phase!=PHASE_DRAW)return luaL_error(l,"dibujo fuera del evento draw_frame");
 Draw d;d.frame=(unsigned)integer(l,1,0,4095);d.x=(int)integer(l,2,-4096,4096);d.y=(int)integer(l,3,-65536,65536);
 if(!lua_isboolean(l,4))return luaL_error(l,"flip debe ser booleano");
 d.flip=lua_toboolean(l,4)!=0;
 d.num=(unsigned)integer(l,5,1,4);d.den=(unsigned)integer(l,6,1,4);
 if(d.num>4*d.den||d.den>4*d.num)return luaL_error(l,"escala de dibujo fuera de rango");
 int first,last;unsigned w,h;if(!ModMediaFrameBounds(d.frame,&first,&last,&w,&h))return luaL_error(l,"fotograma inexistente");
 if(s_draw_count==MAX_DRAWS)return luaL_error(l,"demasiados sprites en un evento");
 uint64_t pixels=(uint64_t)(w*d.num/d.den)*(h*d.num/d.den);
 if(s_draw_pixels+pixels>2u*1024u*1024u)return luaL_error(l,"presupuesto de dibujo agotado");
 s_draw_pixels+=pixels;
 if(display())s_draws[s_draw_count++]=d;
 return 0;
}
static int sound(lua_State *l){
 uint32_t play=(uint32_t)integer(l,1,0,UINT32_MAX),stop=(uint32_t)integer(l,2,0,UINT32_MAX);
 if(s_phase==PHASE_INIT||s_phase==PHASE_RESET||s_phase==PHASE_PREPARE||s_phase==PHASE_DRAW)return luaL_error(l,"audio fuera de evento de juego");
 if(s_sound_count==MAX_SOUNDS)return luaL_error(l,"demasiados sonidos en un evento");
 s_sounds[s_sound_count++]=(Sound){play,stop};return 0;
}
static void register_host(lua_State *l,void *userdata){
 (void)userdata;
 static const luaL_Reg functions[]={{"read16",read16},{"write16",write16},{"choice",choice},{"display_enabled",display_enabled},
 {"oam",oam},{"hide_oam",hide_oam},{"draw",draw},{"frame_bounds",frame_bounds},{"sound",sound},{NULL,NULL}};
 luaL_newlib(l,functions);lua_setglobal(l,"dkc");
}
static bool valid_options(const char *text){
 if(!text)return true;
 size_t len=strlen(text);if(len>4096)return false;
 const char *line=text;unsigned lines=0;
 while(*line){const char *end=strchr(line,'\n');if(!end)return false;const char *eq=memchr(line,'=',(size_t)(end-line));
  if(!eq||eq==line||eq-line>32||end-eq<2||end-eq>33||++lines>8)return false;
  for(const char *p=line;p<end;p++)if(p!=eq&&!((*p>='a'&&*p<='z')||(*p>='0'&&*p<='9')||*p=='_'||*p=='-'))return false;
  line=end+1;
 }return true;
}
void AddonRuntimeUnload(void){
 restore_oam();ModScriptDestroy(s_script);s_script=NULL;ModMediaUnload();s_wram=NULL;s_ppu=NULL;
 s_options[0]=s_error[0]=0;s_render_ready=false;
}
bool AddonRuntimeLoad(const char *path,const char *sha,const char *options,char *error,size_t n){
 if(!path||!valid_options(options))return fail(error,n,"Opciones de mod invalidas.");
 FILE *f=fopen(path,"rb");if(!f)return fail(error,n,"No se puede abrir el mod.");
 if(fseek(f,0,SEEK_END)){fclose(f);return fail(error,n,"No se puede leer el mod.");}
 long len=ftell(f);if(len<20||len>MAX_BUNDLE||fseek(f,0,SEEK_SET)){fclose(f);return fail(error,n,"Tamano de mod no valido.");}
 uint8_t *data=malloc((size_t)len);if(!data){fclose(f);return fail(error,n,"Sin memoria para el mod.");}
 bool read_ok=fread(data,1,(size_t)len,f)==(size_t)len&&fgetc(f)==EOF;fclose(f);
 if(!read_ok||!check_hash(data,(size_t)len,sha)||memcmp(data,"DKCLUA1\0",8)){free(data);return fail(error,n,"El mod esta incompleto o ha cambiado.");}
 uint32_t script=le32(data+8),atlas=le32(data+12),audio=le32(data+16);
 if(!script||script>MOD_SCRIPT_SOURCE_LIMIT||(uint64_t)20+script+atlas+audio!=(uint64_t)len){free(data);return fail(error,n,"Secciones del mod invalidas.");}
 AddonRuntimeUnload();snprintf(s_options,sizeof s_options,"%s",options?options:"");
 if(!ModMediaLoad(atlas?data+20+script:NULL,atlas,audio?data+20+script+atlas:NULL,audio,error,n)){free(data);return false;}
 s_phase=PHASE_INIT;s_script=ModScriptCreate(data+20,script,register_host,NULL,error,n);free(data);
 if(!s_script){ModMediaUnload();return false;}
 if(!call("init",PHASE_INIT,NULL,0,NULL,0)||!call("reset",PHASE_RESET,NULL,0,NULL,0))return fail(error,n,AddonRuntimeError());
 if(error&&n)error[0]=0;
 return true;
}
void AddonRuntimeResetState(void){
 restore_oam();ModMediaResetAudio();s_render_ready=false;s_wram=NULL;s_ppu=NULL;
 if(AddonRuntimeEnabled())(void)call("reset",PHASE_RESET,NULL,0,NULL,0);
}
uint32_t AddonRuntimeFilterInput(uint32_t input,uint8_t *wram){
 s_wram=wram;int64_t arg=input,result=input;
 if(call("filter_input",PHASE_INPUT,&arg,1,&result,1)&&(result<0||result>0xffffff)){fault("entrada de mando fuera de rango");return input;}
 return AddonRuntimeEnabled()?(uint32_t)result:input;
}
void AddonRuntimeBeforeVelocity(uint8_t *wram,uint16_t slot){s_wram=wram;int64_t arg=slot;(void)call("before_velocity",PHASE_VELOCITY,&arg,1,NULL,0);}
void AddonRuntimeAfterFrame(uint8_t *wram){s_wram=wram;(void)call("after_frame",PHASE_AFTER,NULL,0,NULL,0);}
void AddonRuntimeEndFrame(void){(void)call("end_frame",PHASE_END,NULL,0,NULL,0);}
uint16_t AddonRuntimeApuCommand(uint16_t command,uint8_t *wram){
 s_wram=wram;int64_t arg=command,result=command;
 if(call("apu_command",PHASE_APU,&arg,1,&result,1)&&(result<0||result>65535)){fault("comando de audio fuera de rango");return command;}
 return AddonRuntimeEnabled()?(uint16_t)result:command;
}
void AddonRuntimePrepareFrame(Ppu *ppu,const uint8_t *wram,int bias){
 restore_oam();s_render_ready=false;s_ppu=ppu;s_wram=(uint8_t *)wram;int64_t arg=bias;
 if(!ppu||!wram)return;
 s_render_ready=call("prepare_frame",PHASE_PREPARE,&arg,1,NULL,0);
}
void AddonRuntimeDrawFrame(Ppu *ppu){
 restore_oam();s_ppu=ppu;
 if(s_render_ready&&ppu)(void)call("draw_frame",PHASE_DRAW,NULL,0,NULL,0);
 s_render_ready=false;
}

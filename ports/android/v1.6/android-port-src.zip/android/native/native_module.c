#include "native_module.h"
#include "native_module_abi.h"
#include "sha256.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __ANDROID__
#include <android/dlext.h>
#endif

static void *s_module;
static int fail(char *out, size_t n, const char *message) {
    if (out && n) snprintf(out, n, "%s", message);
    return 0;
}
static int digest_equal(const char *hex, const uint8_t digest[32]) {
    if (!hex || strnlen(hex, 65) != 64) return 0;
    static const char chars[] = "0123456789abcdef";
    for (unsigned i = 0; i < 32; ++i)
        if (hex[i*2] != chars[digest[i] >> 4] ||
            hex[i*2+1] != chars[digest[i] & 15]) return 0;
    return 1;
}
int DkcNativeModuleLoad(const char *path, const char *sha,
                        const uint8_t *rom, size_t rom_size,
                        char *error, size_t error_size) {
    if (s_module || cpu_dispatch_has_external_program() || !path || path[0] != '/' ||
        !rom || rom_size != 4194304)
        return fail(error, error_size, "Entrada de modulo nativo invalida.");
    int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return fail(error, error_size, "No se pudo abrir el modulo nativo.");
    struct stat st;
    uint8_t *bytes = NULL, actual[32];
    void *handle = NULL;
    int result = 0;
    const char *message = "Modulo nativo incompleto o alterado.";
    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_uid != getuid() ||
        (st.st_mode & 0222) || st.st_size < 64 || st.st_size > 24*1024*1024) {
        message = "El modulo debe estar protegido contra escritura en el almacenamiento de la app.";
        goto done;
    }
    bytes = malloc((size_t)st.st_size);
    if (!bytes) { message = "Sin memoria para verificar el modulo."; goto done; }
    size_t used = 0;
    while (used < (size_t)st.st_size) {
        ssize_t n = read(fd, bytes + used, (size_t)st.st_size - used);
        if (n <= 0) goto done;
        used += (size_t)n;
    }
    uint8_t extra;
    if (read(fd, &extra, 1) != 0) goto done;
    sha256_compute(bytes, used, actual);
    if (!digest_equal(sha, actual)) goto done;
    free(bytes); bytes = NULL;
#ifdef __ANDROID__
    android_dlextinfo ext = {0};
    ext.flags = ANDROID_DLEXT_USE_LIBRARY_FD;
    ext.library_fd = fd;
    handle = android_dlopen_ext(path, RTLD_NOW | RTLD_LOCAL, &ext);
#else
    char fd_path[64];
    snprintf(fd_path, sizeof fd_path, "/proc/self/fd/%d", fd);
    handle = dlopen(fd_path, RTLD_NOW | RTLD_LOCAL);
#endif
    if (!handle) {
        fprintf(stderr, "[native-module] load error: %s\n", dlerror());
        message = "El modulo nativo no corresponde a este dispositivo o APK.";
        goto done;
    }
    DkcNativeEntryV1 entry = (DkcNativeEntryV1)dlsym(handle, "DkcGetNativeProgramV1");
    const DkcNativeProgramV1 *p = entry ? entry() : NULL;
    if (!p || p->magic != DKC_NATIVE_MAGIC || p->version != DKC_NATIVE_VERSION ||
        p->descriptor_size != sizeof *p || p->cpu_size != sizeof(CpuState) ||
        p->dispatch_size != sizeof(DispatchEntry) || p->guard_size != sizeof(RamRoutineGuard) ||
        memcmp(p->abi_sha256, DKC_NATIVE_ABI_SHA256, 65)) {
        message = "El modulo necesita otra version del motor nativo."; goto done;
    }
    sha256_compute(rom, rom_size, actual);
    if (!digest_equal(p->rom_sha256, actual)) {
        message = "El codigo nativo no corresponde al contenido de este mod."; goto done;
    }
    if (!cpu_dispatch_set_program(p->dispatch, p->dispatch_count, p->guards, p->guard_count)) {
        message = "Tabla de codigo nativo invalida."; goto done;
    }
    fprintf(stderr, "[native-module] active entries=%u guards=%u ABI=%s\n",
            p->dispatch_count, p->guard_count, p->abi_sha256);
    s_module = handle; handle = NULL; result = 1;
done:
    if (handle) dlclose(handle);
    free(bytes); close(fd);
    return result ? 1 : fail(error, error_size, message);
}
void DkcNativeModuleUnload(void) {
    if (s_module) {
        cpu_dispatch_set_program(NULL, 0, NULL, 0);
        dlclose(s_module); s_module = NULL;
    }
}

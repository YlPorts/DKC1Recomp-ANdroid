#include "addon_runtime.h"
#include "cpu_state.h"
#include "common_cpu_infra.h"
/* Stable game hook ABI. These hooks contain no character or sound policy. */
RecompReturn __real_Sprite_ApplyVelocity_M0X0(CpuState *cpu);
RecompReturn __real_CODE_BFB0D1_M0X0(CpuState *cpu);
RecompReturn __real_APU_SubmitCommand_M0X0(CpuState *cpu);
RecompReturn __real_APU_SubmitCommand_M1X0(CpuState *cpu);
RecompReturn __wrap_Sprite_ApplyVelocity_M0X0(CpuState *cpu){
 if(AddonRuntimeEnabled())AddonRuntimeBeforeVelocity(cpu->ram,cpu_read16(cpu,0,(uint16_t)(cpu->D+0x82)));
 return __real_Sprite_ApplyVelocity_M0X0(cpu);
}
RecompReturn __wrap_CODE_BFB0D1_M0X0(CpuState *cpu){
 if(AddonRuntimeEnabled())AddonRuntimeBeforeVelocity(cpu->ram,cpu->X);
 return __real_CODE_BFB0D1_M0X0(cpu);
}
typedef RecompReturn (*Submit)(CpuState *);
static RecompReturn submit(CpuState *cpu,Submit original){
 if(!AddonRuntimeEnabled())return original(cpu);
 uint16_t command=cpu->X;cpu->X=AddonRuntimeApuCommand(command,cpu->ram);
 RecompReturn result=original(cpu);cpu->X=command;return result;
}
RecompReturn __wrap_APU_SubmitCommand_M0X0(CpuState *cpu){return submit(cpu,__real_APU_SubmitCommand_M0X0);}
RecompReturn __wrap_APU_SubmitCommand_M1X0(CpuState *cpu){return submit(cpu,__real_APU_SubmitCommand_M1X0);}

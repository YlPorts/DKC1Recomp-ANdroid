#ifndef DKC1_ADDON_RUNTIME_H
#define DKC1_ADDON_RUNTIME_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
typedef struct Ppu Ppu;
bool AddonRuntimeLoad(const char *path,const char *sha,const char *options,char *error,size_t size);
void AddonRuntimeUnload(void);
void AddonRuntimeResetState(void);
bool AddonRuntimeEnabled(void);
bool AddonRuntimeFaulted(void);
const char *AddonRuntimeError(void);
uint32_t AddonRuntimeFilterInput(uint32_t input,uint8_t *wram);
void AddonRuntimeBeforeVelocity(uint8_t *wram,uint16_t slot);
void AddonRuntimeAfterFrame(uint8_t *wram);
void AddonRuntimeEndFrame(void);
uint16_t AddonRuntimeApuCommand(uint16_t command,uint8_t *wram);
void AddonRuntimePrepareFrame(Ppu *ppu,const uint8_t *wram,int bias);
void AddonRuntimeDrawFrame(Ppu *ppu);
#endif

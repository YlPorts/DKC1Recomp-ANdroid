/* Keep the existing optional-character hook ABI. With no runtime mod loaded
 * every hook is a strict no-op, preserving the original Android path. */
#include "dkc1_baby_kong.h"
#include "addon_runtime.h"
void Dkc1BabyKongInitializeFromEnvironment(void) {}
void Dkc1BabyKongApplyMoves(uint8_t *wram) {AddonRuntimeAfterFrame(wram);}
void Dkc1BabyKongPrepareFrame(Ppu *ppu,const uint8_t *wram,int bias) {AddonRuntimePrepareFrame(ppu,wram,bias);}
void Dkc1BabyKongDrawFrame(Ppu *ppu) {AddonRuntimeDrawFrame(ppu);}

#ifndef DKC1_ANDROID_MOD_MEDIA_H
#define DKC1_ANDROID_MOD_MEDIA_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct Ppu Ppu;

/* The caller owns all calls, including mixing, on the game thread.
 * A successful load copies its input and atomically replaces both banks.
 * NULL/0 omits a bank. No file, game-state or script access is performed.
 *
 * DKCATL1\0: u32 width, height, frame count, palette count; RGBA palette;
 * indexed frames in row-major order. All integers are little endian.
 * Frame indices start at zero; palette index zero is always transparent.
 * DKCSND1\0: u32 clip count, then u32 event bit, rate, channels, frame count
 * and signed little-endian PCM16 for every clip. Each bit is unique.
 */
bool ModMediaLoad(const uint8_t *atlas, size_t atlas_size,
                  const uint8_t *audio, size_t audio_size,
                  char *error, size_t error_size);
void ModMediaUnload(void);
void ModMediaResetAudio(void);
void ModMediaPlay(uint32_t play, uint32_t stop);
void ModMediaMix(int16_t *stereo, size_t frames, unsigned rate);

/* Transparent or invalid frames return false. First and last are inclusive
 * unscaled source rows. Width and height describe the complete frame.
 */
bool ModMediaFrameBounds(unsigned frame, int *first, int *last,
                         unsigned *width, unsigned *height);

/* Draws over the current PPU output using its brightness conversion.
 * center_x uses the native 256-pixel coordinate origin, including negative
 * positions in the left margin; origin_y is the top row of the source frame.
 * The rational scale must be between 1/4 and 4 inclusive, with terms 1..4.
 */
void ModMediaDraw(Ppu *ppu, unsigned frame, int center_x, int origin_y,
                   bool flip, unsigned scale_num, unsigned scale_den);

#endif

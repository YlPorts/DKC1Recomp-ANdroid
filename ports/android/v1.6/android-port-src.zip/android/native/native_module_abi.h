#ifndef DKC_NATIVE_MODULE_ABI_H
#define DKC_NATIVE_MODULE_ABI_H
#include <stddef.h>
#include <stdint.h>
#include "cpu_state.h"
#include "native_module_fingerprint.h"

/* This interface is for trusted native code. It is NOT the Lua sandbox.
 * Complete programs own every dispatch row; missing rows never fall through
 * into the linked stock game's code. PPU/audio/core helpers stay in the host. */
#define DKC_NATIVE_MAGIC UINT32_C(0x444b434e)
#define DKC_NATIVE_VERSION 1u
typedef struct DkcNativeProgramV1 {
    uint32_t magic, version, descriptor_size, cpu_size;
    uint32_t dispatch_size, guard_size;
    char abi_sha256[65];
    char rom_sha256[65];
    const DispatchEntry *dispatch;
    uint32_t dispatch_count;
    const RamRoutineGuard *guards;
    uint32_t guard_count;
} DkcNativeProgramV1;
typedef const DkcNativeProgramV1 *(*DkcNativeEntryV1)(void);
#endif

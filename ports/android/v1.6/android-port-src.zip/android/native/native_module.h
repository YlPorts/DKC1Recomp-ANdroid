#ifndef DKC_NATIVE_MODULE_H
#define DKC_NATIVE_MODULE_H
#include <stddef.h>
#include <stdint.h>
/* Host thread only, before SnesInit. The caller has obtained explicit native
 * code trust approval for this exact package and supplied its verified hash. */
int DkcNativeModuleLoad(const char *path, const char *sha256,
                        const uint8_t *rom, size_t rom_size,
                        char *error, size_t error_size);
void DkcNativeModuleUnload(void);
#endif

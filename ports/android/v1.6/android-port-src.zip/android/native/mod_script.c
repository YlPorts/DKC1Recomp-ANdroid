#include "mod_script.h"
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* All platform/game behavior is registered by the generic host adapter. This
 * module knows no game addresses, character names, asset names or physics. */
struct ModScript {
    lua_State *state;
    size_t allocated;
    unsigned instructions_left;
    bool enabled;
    int callback_ref;
    char error[384];
    ModScriptRegisterHost register_host;
    void *userdata;
};

typedef struct ScriptCall {
    ModScript *script;
    const char *name;
    const int64_t *arguments;
    size_t argument_count;
    int64_t values[MOD_SCRIPT_ARGUMENT_LIMIT];
    size_t result_count;
} ScriptCall;

typedef struct ScriptSource {
    ModScript *script;
    const void *bytes;
    size_t length;
} ScriptSource;

static void copy_error(char *out, size_t size, const char *message) {
    if (out && size) snprintf(out, size, "%s", message ? message : "Mod script error");
}

static void *bounded_allocator(void *userdata, void *pointer,
                               size_t old_size, size_t new_size) {
    ModScript *script = (ModScript *)userdata;
    /* Lua supplies an object type, not an old allocation size, for new objects. */
    if (!pointer) old_size = 0;
    if (!new_size) {
        free(pointer);
        script->allocated -= old_size;
        return NULL;
    }
    if (new_size > MOD_SCRIPT_MEMORY_LIMIT ||
        script->allocated - old_size > MOD_SCRIPT_MEMORY_LIMIT - new_size)
        return NULL;
    void *result = realloc(pointer, new_size);
    if (result) script->allocated = script->allocated - old_size + new_size;
    return result;
}

static void instruction_hook(lua_State *state, lua_Debug *debug) {
    (void)debug;
    ModScript *script = *(ModScript **)lua_getextraspace(state);
    if (script->instructions_left <= 1000u) {
        script->instructions_left = 0;
        luaL_error(state, "Mod script exceeded its instruction budget");
    }
    script->instructions_left -= 1000u;
}

static void begin_budget(ModScript *script) {
    script->instructions_left = MOD_SCRIPT_INSTRUCTION_LIMIT;
    lua_sethook(script->state, instruction_hook, LUA_MASKCOUNT, 1000);
}

static void fault(ModScript *script, const char *context) {
    lua_State *state = script->state;
    const char *detail = lua_type(state, -1) == LUA_TSTRING ? lua_tostring(state, -1) : NULL;
    snprintf(script->error, sizeof(script->error), "%s: %s", context,
             detail ? detail : "non-text script error");
    script->enabled = false;
    lua_sethook(state, NULL, 0, 0);
    lua_settop(state, 0);
}

static void remove_global(lua_State *state, const char *name) {
    lua_pushnil(state);
    lua_setglobal(state, name);
}

static int deterministic_tostring(lua_State *state) {
    luaL_checkany(state, 1);
    switch (lua_type(state, 1)) {
    case LUA_TSTRING:
    case LUA_TNUMBER:
        lua_pushvalue(state, 1);
        lua_tolstring(state, -1, NULL);
        break;
    case LUA_TBOOLEAN:
        lua_pushstring(state, lua_toboolean(state, 1) ? "true" : "false");
        break;
    default:
        /* Base tostring embeds pointer identities for tables/functions. Mods
         * need a portable textual type, not process-specific address entropy. */
        lua_pushstring(state, luaL_typename(state, 1));
        break;
    }
    return 1;
}

static void restrict_library(lua_State *state, const char *name,
                             lua_CFunction open_library,
                             const char *const *allowed) {
    luaL_requiref(state, name, open_library, 1);
    int original = lua_gettop(state);
    lua_newtable(state);
    int restricted = lua_gettop(state);
    for (const char *const *entry = allowed; *entry; ++entry) {
        lua_getfield(state, original, *entry);
        lua_setfield(state, restricted, *entry);
    }
    /* String methods look up a metatable created by luaopen_string. Point its
     * __index at the restricted table too, so ("x"):dump() cannot evade this. */
    if (!strcmp(name, LUA_STRLIBNAME)) {
        lua_pushliteral(state, "");
        if (lua_getmetatable(state, -1)) {
            lua_pushvalue(state, restricted);
            lua_setfield(state, -2, "__index");
            lua_pop(state, 1);
        }
        lua_pop(state, 1);
    }
    lua_pushvalue(state, restricted);
    lua_setglobal(state, name);
    lua_pop(state, 2);
}

static int initialize_environment(lua_State *state) {
    ModScript *script = *(ModScript **)lua_getextraspace(state);
    static const char *const removed[] = {
        "collectgarbage", "dofile", "load", "loadfile", "require", "print", "warn",
        "pcall", "xpcall", "getmetatable", "setmetatable", NULL
    };
    static const char *const safe_math[] = {
        "abs", "acos", "asin", "atan", "ceil", "cos", "deg", "exp", "floor",
        "fmod", "huge", "log", "max", "maxinteger", "min", "mininteger", "modf",
        "pi", "rad", "sin", "sqrt", "tan", "tointeger", "type", "ult", NULL
    };
    static const char *const safe_string[] = {
        "byte", "char", "len", "lower", "rep", "reverse", "sub", "upper", NULL
    };
    /* Native table.move/insert/remove can iterate an arbitrarily large sparse
     * length without a VM instruction hook. Scripts implement bounded loops
     * themselves. Pattern string functions are excluded for the same reason. */
    static const char *const safe_table[] = {"concat", "pack", "unpack", NULL};
    luaL_requiref(state, LUA_GNAME, luaopen_base, 1);
    lua_pop(state, 1);
    for (const char *const *name = removed; *name; ++name) remove_global(state, *name);
    lua_pushcfunction(state, deterministic_tostring);
    lua_setglobal(state, "tostring");
    restrict_library(state, LUA_MATHLIBNAME, luaopen_math, safe_math);
    restrict_library(state, LUA_STRLIBNAME, luaopen_string, safe_string);
    restrict_library(state, LUA_TABLIBNAME, luaopen_table, safe_table);
    /* io, os, package, debug, utf8 and coroutine libraries are never opened.
     * There is no time/random source, binary loader, dynamic loader or JIT. */
    if (script->register_host) script->register_host(state, script->userdata);
    return 0;
}

static int evaluate_source(lua_State *state) {
    ScriptSource *source = (ScriptSource *)lua_touserdata(state, 1);
    /* 't' rejects precompiled chunks even if their bytecode looks legitimate. */
    if (luaL_loadbufferx(state, (const char *)source->bytes, source->length,
                         "@mod/runtime.lua", "t") != LUA_OK)
        return lua_error(state);
    lua_call(state, 0, 1);
    if (!lua_istable(state, -1))
        return luaL_error(state, "Mod source must return a callback table");
    /* Referencing may allocate. Keep it in this protected trampoline too. */
    source->script->callback_ref = luaL_ref(state, LUA_REGISTRYINDEX);
    return 0;
}

ModScript *ModScriptCreate(const void *source, size_t length,
                          ModScriptRegisterHost register_host, void *userdata,
                          char *error, size_t error_size) {
    if (error && error_size) error[0] = '\0';
    if (!source || !length || length > MOD_SCRIPT_SOURCE_LIMIT) {
        copy_error(error, error_size, "Mod script must contain 1 to 262144 source bytes");
        return NULL;
    }
    ModScript *script = (ModScript *)calloc(1, sizeof(*script));
    if (!script) {
        copy_error(error, error_size, "Cannot allocate mod script instance");
        return NULL;
    }
    script->register_host = register_host;
    script->userdata = userdata;
    script->callback_ref = LUA_NOREF;
    script->state = lua_newstate(bounded_allocator, script);
    if (!script->state) {
        copy_error(error, error_size, "Cannot allocate bounded Lua state");
        free(script);
        return NULL;
    }
    *(ModScript **)lua_getextraspace(script->state) = script;
    script->enabled = true;
    begin_budget(script);
    lua_pushcfunction(script->state, initialize_environment);
    if (lua_pcall(script->state, 0, 0, 0) != LUA_OK) {
        fault(script, "Initializing mod script");
        goto failure;
    }
    ScriptSource input = {script, source, length};
    begin_budget(script);
    lua_pushcfunction(script->state, evaluate_source);
    lua_pushlightuserdata(script->state, &input);
    if (lua_pcall(script->state, 1, 0, 0) != LUA_OK) {
        fault(script, "Loading mod source");
        goto failure;
    }
    lua_sethook(script->state, NULL, 0, 0);
    return script;
failure:
    copy_error(error, error_size, script->error);
    ModScriptDestroy(script);
    return NULL;
}

void ModScriptDestroy(ModScript *script) {
    if (!script) return;
    if (script->state) lua_close(script->state);
    free(script);
}

bool ModScriptEnabled(const ModScript *script) { return script && script->enabled; }
const char *ModScriptError(const ModScript *script) { return script ? script->error : ""; }
size_t ModScriptMemory(const ModScript *script) { return script ? script->allocated : 0; }

static int invoke_callback(lua_State *state) {
    ScriptCall *call = (ScriptCall *)lua_touserdata(state, 1);
    lua_rawgeti(state, LUA_REGISTRYINDEX, call->script->callback_ref);
    lua_pushstring(state, call->name);
    lua_rawget(state, -2);
    if (lua_isnil(state, -1)) return 0;
    if (!lua_isfunction(state, -1)) return luaL_error(state, "Callback is not a function");
    for (size_t i = 0; i < call->argument_count; ++i)
        lua_pushinteger(state, (lua_Integer)call->arguments[i]);
    lua_call(state, (int)call->argument_count, (int)call->result_count);
    for (size_t i = 0; i < call->result_count; ++i) {
        int index = (int)i - (int)call->result_count;
        if (lua_isnil(state, index)) continue;
        if (lua_isboolean(state, index)) call->values[i] = lua_toboolean(state, index);
        else if (lua_isinteger(state, index)) call->values[i] = (int64_t)lua_tointeger(state, index);
        else return luaL_error(state, "Callback must return integer, boolean or nil");
    }
    return 0;
}

bool ModScriptCall(ModScript *script, const char *callback,
                   const int64_t *arguments, size_t argument_count,
                   int64_t *results, size_t result_count) {
    if (!ModScriptEnabled(script)) return false;
    if (!callback || argument_count > MOD_SCRIPT_ARGUMENT_LIMIT ||
        result_count > MOD_SCRIPT_ARGUMENT_LIMIT ||
        (argument_count && !arguments) || (result_count && !results)) {
        copy_error(script->error, sizeof(script->error), "Invalid host callback arguments");
        script->enabled = false;
        return false;
    }
    ScriptCall call = { .script = script, .name = callback, .arguments = arguments,
                        .argument_count = argument_count, .result_count = result_count };
    for (size_t i = 0; i < result_count; ++i) call.values[i] = results[i];
    lua_State *state = script->state;
    begin_budget(script);
    lua_pushcfunction(state, invoke_callback);
    lua_pushlightuserdata(state, &call);
    if (lua_pcall(state, 1, 0, 0) != LUA_OK) {
        fault(script, callback);
        return false;
    }
    lua_sethook(state, NULL, 0, 0);
    for (size_t i = 0; i < result_count; ++i) results[i] = call.values[i];
    return true;
}

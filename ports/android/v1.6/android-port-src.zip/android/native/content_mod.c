/* Strict host-side patches after original-ROM verification.
 * A failed transaction leaves the caller's ROM buffer byte-identical. */
#include "content_mod.h"
#include "sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mod_regions.h"
static int fail(char *out,size_t n,const char *s){if(out&&n)snprintf(out,n,"%s",s);return 0;}
static uint32_t be32(const uint8_t *p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static int hex32(const char *s,uint8_t out[32]){
 if(!s||strlen(s)!=64)return 0;for(int i=0;i<32;i++){unsigned n=0;for(int j=0;j<2;j++){char c=s[i*2+j];if(c>='0'&&c<='9')n=(n<<4)|(c-'0');else if(c>='a'&&c<='f')n=(n<<4)|(c-'a'+10);else return 0;}out[i]=(uint8_t)n;}return 1;
}
static int allowed(uint32_t o,uint32_t n){for(size_t i=0;i<sizeof kModDataRanges/sizeof *kModDataRanges;i++)if(o>=kModDataRanges[i][0]&&o<kModDataRanges[i][1]&&n<=kModDataRanges[i][1]-o)return 1;return 0;}
static int apply_impl(uint8_t *rom,size_t size,const char *path,const char *sha,int *compatibility,int allow_native,char *error,size_t n);
int DkcContentModApply(uint8_t *rom,size_t size,const char *path,const char *sha,char *error,size_t n){
 return DkcContentModApplyEx(rom,size,path,sha,NULL,error,n);
}
int DkcContentModApplyEx(uint8_t *rom,size_t size,const char *path,const char *sha,int *compatibility,char *error,size_t n){
 return apply_impl(rom,size,path,sha,compatibility,0,error,n);
}
int DkcContentModApplyMode(uint8_t *rom,size_t size,const char *path,const char *sha,int *mode,char *error,size_t n){
 return apply_impl(rom,size,path,sha,mode,1,error,n);
}
static int apply_impl(uint8_t *rom,size_t size,const char *path,const char *sha,int *compatibility,int allow_native,char *error,size_t n){
 if(compatibility)*compatibility=0;
 if(!rom||size!=4194304||!path)return fail(error,n,"Entrada de mod invalida.");
 FILE *f=fopen(path,"rb");if(!f)return fail(error,n,"No se pudo abrir el paquete activo.");
 if(fseek(f,0,SEEK_END)){fclose(f);return fail(error,n,"No se pudo leer el mod.");}long length=ftell(f);
 if(length<76||length>4194304+4096*40+76||fseek(f,0,SEEK_SET)){fclose(f);return fail(error,n,"Tamano de mod invalido.");}
 uint8_t *b=malloc((size_t)length),*copy=NULL;int result=0;uint8_t expected[32],actual[32];
 if(!b){fclose(f);return fail(error,n,"Sin memoria para el mod.");}
 if(fread(b,1,(size_t)length,f)!=(size_t)length||fgetc(f)!=EOF){fail(error,n,"Paquete incompleto.");goto done;}
 if(!hex32(sha,expected)){fail(error,n,"Identidad de paquete invalida.");goto done;}
 const int native=!memcmp(b,"DKCMOD06",8),compat=!memcmp(b,"DKCMOD05",8)||native;
 if(native&&(!allow_native||!compatibility)){fail(error,n,"Este plan necesita un modulo nativo verificado.");goto done;}
 sha256_compute(b,(size_t)length,actual);if(memcmp(expected,actual,32)||(!compat&&memcmp(b,"DKCMOD02",8))){fail(error,n,"El paquete activo ha cambiado.");goto done;}
 if(compat&&!compatibility){fail(error,n,"Este plan necesita el modo de compatibilidad SNES.");goto done;}
 sha256_compute(rom,size,actual);if(memcmp(actual,b+12,32)){fail(error,n,"El mod no coincide con la ROM original.");goto done;}
 if(compat){hex32("fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15",expected);if(memcmp(actual,expected,32)){fail(error,n,"La compatibilidad necesita la ROM limpia USA v1.0.");goto done;}}
 uint32_t count=be32(b+8);if(count>4096){fail(error,n,"Numero de parches invalido.");goto done;}
 if(compat&&!count){fail(error,n,"El romhack no contiene cambios.");goto done;}
 copy=malloc(size);if(!copy){fail(error,n,"Sin memoria para el contenido.");goto done;}memcpy(copy,rom,size);
 size_t cursor=76;uint32_t end=0,total=0;
 for(uint32_t i=0;i<count;i++){
  if((size_t)length-cursor<40){fail(error,n,"Cabecera de parche incompleta.");goto done;}
  uint32_t offset=be32(b+cursor),bytes=be32(b+cursor+4);const uint8_t *before=b+cursor+8;cursor+=40;
  if(!bytes||offset<end||offset>size||bytes>size-offset||bytes>(size_t)length-cursor||bytes>4194304-total||(!compat&&!allowed(offset,bytes))){fail(error,n,"El mod toca codigo o datos no admitidos.");goto done;}
  sha256_compute(copy+offset,bytes,actual);if(memcmp(before,actual,32)){fail(error,n,"Los datos originales no coinciden con el mod.");goto done;}
  memcpy(copy+offset,b+cursor,bytes);cursor+=bytes;end=offset+bytes;total+=bytes;
 }
 if(cursor!=(size_t)length){fail(error,n,"Datos adicionales no declarados.");goto done;}
 sha256_compute(copy,size,actual);if(memcmp(actual,b+44,32)){fail(error,n,"Resultado del mod no valido.");goto done;}
 if(compat&&(memcmp(rom+0xffd5,copy+0xffd5,7)||memcmp(rom+0xffe0,copy+0xffe0,32))){fail(error,n,"El hack cambia el hardware o los vectores DKC1 no admitidos.");goto done;}
 memcpy(rom,copy,size);if(compatibility)*compatibility=native?2:compat;result=1;
 done:free(copy);free(b);fclose(f);return result;
}

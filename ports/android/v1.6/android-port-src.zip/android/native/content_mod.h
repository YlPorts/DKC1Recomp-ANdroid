#ifndef DKC_CONTENT_MOD_H
#define DKC_CONTENT_MOD_H
#include <stddef.h>
#include <stdint.h>
int DkcContentModApply(uint8_t *rom,size_t size,const char *plan,const char *sha,
                       char *error,size_t error_size);
/* Format 5 requires the caller to honor the returned compatibility mode.
 * Output remains zero and ROM unchanged on any validation failure. */
int DkcContentModApplyEx(uint8_t *rom,size_t size,const char *plan,const char *sha,
                        int *compatibility,char *error,size_t error_size);
/* Mode 0=data/Lua, 1=whole-cartridge compatibility, 2=external native AOT.
 * Mode 2 must be paired with a verified matching native module before boot. */
int DkcContentModApplyMode(uint8_t *rom,size_t size,const char *plan,const char *sha,
                          int *execution_mode,char *error,size_t error_size);
#endif

#include "mod_media.h"
#include "snes/ppu.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MOD_MEDIA_MAX_BYTES (16u * 1024u * 1024u)
#define MOD_MEDIA_MAX_FRAMES 4096u
#define MOD_MEDIA_MAX_CLIPS 32u

typedef struct {
  unsigned width, height, count, colors;
  uint8_t *pixels;
  uint32_t palette[256];
  int16_t first[MOD_MEDIA_MAX_FRAMES], last[MOD_MEDIA_MAX_FRAMES];
} ModAtlas;

typedef struct {
  uint32_t event, rate, channels, frames;
  int16_t *samples;
} ModClip;

typedef struct {
  bool playing;
  uint64_t position;
} ModVoice;

static ModAtlas s_atlas;
static ModClip s_clips[MOD_MEDIA_MAX_CLIPS];
static ModVoice s_voices[MOD_MEDIA_MAX_CLIPS];
static unsigned s_count;

static uint32_t Read32(const uint8_t *p) {
  return (uint32_t)p[0] | (uint32_t)p[1] << 8 |
         (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static bool Fail(char *error, size_t error_size, const char *message) {
  if (error && error_size) snprintf(error, error_size, "%s", message);
  return false;
}

static void FreeClips(ModClip *clips, unsigned count) {
  for (unsigned i = 0; i < count; ++i) {
    free(clips[i].samples);
    clips[i].samples = NULL;
  }
}

static bool LoadAtlas(ModAtlas *atlas, const uint8_t *data, size_t size,
                      char *error, size_t error_size) {
  if (!data && !size) return true;
  if (!data || size < 24 || size > MOD_MEDIA_MAX_BYTES ||
      memcmp(data, "DKCATL1\0", 8))
    return Fail(error, error_size, "Atlas del mod no valido.");
  atlas->width = Read32(data + 8);
  atlas->height = Read32(data + 12);
  atlas->count = Read32(data + 16);
  atlas->colors = Read32(data + 20);
  if (!atlas->width || atlas->width > 256 ||
      !atlas->height || atlas->height > 256 ||
      !atlas->count || atlas->count > MOD_MEDIA_MAX_FRAMES ||
      !atlas->colors || atlas->colors > 256)
    return Fail(error, error_size, "Dimensiones del atlas no validas.");
  size_t frame_size = (size_t)atlas->width * atlas->height;
  size_t pixels = frame_size * atlas->count;
  size_t offset = 24 + (size_t)atlas->colors * 4;
  if (offset > size || pixels != size - offset)
    return Fail(error, error_size, "Tamano del atlas no valido.");
  for (unsigned i = 0; i < atlas->colors; ++i) {
    const uint8_t *p = data + 24 + i * 4;
    atlas->palette[i] = (uint32_t)p[3] << 24 | (uint32_t)p[0] << 16 |
                        (uint32_t)p[1] << 8 | p[2];
  }
  for (size_t i = 0; i < pixels; ++i)
    if (data[offset + i] >= atlas->colors)
      return Fail(error, error_size, "Indice de color del atlas no valido.");
  atlas->pixels = malloc(pixels);
  if (!atlas->pixels)
    return Fail(error, error_size, "Sin memoria para el atlas del mod.");
  memcpy(atlas->pixels, data + offset, pixels);
  for (unsigned frame = 0; frame < atlas->count; ++frame) {
    int first = -1, last = -1;
    const uint8_t *p = atlas->pixels + (size_t)frame * frame_size;
    for (unsigned y = 0; y < atlas->height; ++y) {
      for (unsigned x = 0; x < atlas->width; ++x) {
        unsigned index = p[(size_t)y * atlas->width + x];
        if (index && (atlas->palette[index] >> 24)) {
          if (first < 0) first = (int)y;
          last = (int)y;
        }
      }
    }
    atlas->first[frame] = (int16_t)first;
    atlas->last[frame] = (int16_t)last;
  }
  return true;
}

static bool LoadAudio(ModClip *clips, unsigned *clip_count,
                      const uint8_t *data, size_t size,
                      char *error, size_t error_size) {
  if (!data && !size) return true;
  if (!data || size < 12 || size > MOD_MEDIA_MAX_BYTES ||
      memcmp(data, "DKCSND1\0", 8))
    return Fail(error, error_size, "Banco de sonidos del mod no valido.");
  unsigned count = Read32(data + 8);
  if (count > MOD_MEDIA_MAX_CLIPS)
    return Fail(error, error_size, "Cantidad de sonidos del mod no valida.");
  size_t offset = 12;
  uint32_t used = 0;
  for (unsigned i = 0; i < count; ++i) {
    if (size - offset < 16)
      return Fail(error, error_size, "Cabecera de sonido incompleta.");
    ModClip *clip = &clips[i];
    clip->event = Read32(data + offset);
    clip->rate = Read32(data + offset + 4);
    clip->channels = Read32(data + offset + 8);
    clip->frames = Read32(data + offset + 12);
    offset += 16;
    if (!clip->event || (clip->event & (clip->event - 1)) ||
        (used & clip->event) || clip->rate < 8000 || clip->rate > 96000 ||
        (clip->channels != 1 && clip->channels != 2) ||
        !clip->frames || clip->frames > clip->rate * 8u)
      return Fail(error, error_size, "Parametros de sonido no validos.");
    size_t samples = (size_t)clip->frames * clip->channels;
    size_t bytes = samples * sizeof(int16_t);
    if (bytes > size - offset)
      return Fail(error, error_size, "Muestras de sonido incompletas.");
    clip->samples = malloc(bytes);
    if (!clip->samples)
      return Fail(error, error_size, "Sin memoria para los sonidos del mod.");
    *clip_count = i + 1;
    for (size_t j = 0; j < samples; ++j) {
      unsigned value = data[offset + j * 2] |
                       (unsigned)data[offset + j * 2 + 1] << 8;
      clip->samples[j] = (int16_t)(value < 32768u ? (int)value : (int)value - 65536);
    }
    offset += bytes;
    used |= clip->event;
  }
  if (offset != size)
    return Fail(error, error_size, "Datos adicionales en el banco de sonidos.");
  return true;
}

bool ModMediaLoad(const uint8_t *atlas, size_t atlas_size,
                  const uint8_t *audio, size_t audio_size,
                  char *error, size_t error_size) {
  ModAtlas pending_atlas = {0};
  ModClip pending_clips[MOD_MEDIA_MAX_CLIPS] = {{0}};
  unsigned pending_count = 0;
  if (!LoadAtlas(&pending_atlas, atlas, atlas_size, error, error_size) ||
      !LoadAudio(pending_clips, &pending_count, audio, audio_size, error, error_size)) {
    free(pending_atlas.pixels);
    FreeClips(pending_clips, pending_count);
    return false;
  }
  ModMediaUnload();
  s_atlas = pending_atlas;
  memcpy(s_clips, pending_clips, sizeof(pending_clips));
  s_count = pending_count;
  if (error && error_size) error[0] = 0;
  return true;
}

void ModMediaResetAudio(void) {
  memset(s_voices, 0, sizeof(s_voices));
}

void ModMediaUnload(void) {
  ModMediaResetAudio();
  free(s_atlas.pixels);
  memset(&s_atlas, 0, sizeof(s_atlas));
  FreeClips(s_clips, s_count);
  memset(s_clips, 0, sizeof(s_clips));
  s_count = 0;
}

void ModMediaPlay(uint32_t play, uint32_t stop) {
  for (unsigned i = 0; i < s_count; ++i) {
    if (s_clips[i].event & stop) s_voices[i].playing = false;
    if (s_clips[i].event & play & ~stop) {
      s_voices[i].position = 0;
      s_voices[i].playing = true;
    }
  }
}

static int32_t SampleAt(const ModClip *clip, uint32_t frame,
                        uint32_t fraction, unsigned channel) {
  unsigned c = clip->channels == 1 ? 0 : channel;
  int32_t a = clip->samples[(size_t)frame * clip->channels + c];
  uint32_t next = frame + 1 < clip->frames ? frame + 1 : frame;
  int32_t b = clip->samples[(size_t)next * clip->channels + c];
  return a + (int32_t)((int64_t)(b - a) * fraction / 4294967296LL);
}

void ModMediaMix(int16_t *stereo, size_t frames, unsigned rate) {
  if (!stereo || !frames || !s_count || rate < 8000 || rate > 192000) return;
  bool active = false;
  for (unsigned i = 0; i < s_count; ++i) active |= s_voices[i].playing;
  if (!active) return;
  uint64_t steps[MOD_MEDIA_MAX_CLIPS];
  for (unsigned i = 0; i < s_count; ++i)
    steps[i] = ((uint64_t)s_clips[i].rate << 32) / rate;
  for (size_t frame = 0; frame < frames; ++frame) {
    int32_t left = stereo[frame * 2], right = stereo[frame * 2 + 1];
    for (unsigned i = 0; i < s_count; ++i) {
      ModVoice *voice = &s_voices[i];
      if (!voice->playing) continue;
      ModClip *clip = &s_clips[i];
      uint32_t index = (uint32_t)(voice->position >> 32);
      if (index >= clip->frames) {
        voice->playing = false;
        continue;
      }
      uint32_t fraction = (uint32_t)voice->position;
      left += SampleAt(clip, index, fraction, 0);
      right += SampleAt(clip, index, fraction, 1);
      voice->position += steps[i];
    }
    if (left > 32767) left = 32767;
    if (left < -32768) left = -32768;
    if (right > 32767) right = 32767;
    if (right < -32768) right = -32768;
    stereo[frame * 2] = (int16_t)left;
    stereo[frame * 2 + 1] = (int16_t)right;
  }
}

bool ModMediaFrameBounds(unsigned frame, int *first, int *last,
                         unsigned *width, unsigned *height) {
  if (!s_atlas.pixels || frame >= s_atlas.count) return false;
  if (first) *first = s_atlas.first[frame];
  if (last) *last = s_atlas.last[frame];
  if (width) *width = s_atlas.width;
  if (height) *height = s_atlas.height;
  return s_atlas.first[frame] >= 0;
}

void ModMediaDraw(Ppu *p, unsigned frame, int center_x, int origin_y,
                   bool flip, unsigned scale_num, unsigned scale_den) {
  if (!p || !p->renderBuffer || !s_atlas.pixels || frame >= s_atlas.count ||
      !scale_num || scale_num > 4 || !scale_den || scale_den > 4 ||
      p->renderPitch < 256 * 4 || p->renderPitch % 4) return;
  unsigned width = p->renderPitch / 4, extra = (width - 256) / 2;
  unsigned draw_width = s_atlas.width * scale_num / scale_den;
  unsigned draw_height = s_atlas.height * scale_num / scale_den;
  const uint8_t *src = s_atlas.pixels +
                      (size_t)frame * s_atlas.width * s_atlas.height;
  if (s_atlas.first[frame] < 0) return;
  /* Clip before iterating so an enlarged sprite costs at most one visible
   * framebuffer of pixels. Coordinates stay widened until bounds prove
   * the conversions safe, including scripts placing sprites at INT_MIN.
   */
  int64_t y_begin = origin_y < 0 ? -(int64_t)origin_y : 0;
  int64_t y_end = 224 - (int64_t)origin_y;
  if (y_end > draw_height) y_end = draw_height;
  int64_t edge = (int64_t)center_x + extra +
                 (flip ? (int)draw_width / 2 - 1 : -(int)draw_width / 2);
  int64_t x_begin = flip ? edge - width + 1 : -edge;
  int64_t x_end = flip ? edge + 1 : (int64_t)width - edge;
  if (x_begin < 0) x_begin = 0;
  if (x_end > draw_width) x_end = draw_width;
  if (y_begin >= y_end || x_begin >= x_end) return;
  for (unsigned y = (unsigned)y_begin; y < (unsigned)y_end; ++y) {
    int64_t oy = (int64_t)origin_y + y;
    uint32_t *dst = (uint32_t *)(p->renderBuffer + (size_t)oy * p->renderPitch);
    unsigned sy = y * scale_den / scale_num;
    for (unsigned x = (unsigned)x_begin; x < (unsigned)x_end; ++x) {
      unsigned index = src[(size_t)sy * s_atlas.width + x * scale_den / scale_num];
      if (!index) continue;
      uint32_t rgb = s_atlas.palette[index], alpha = rgb >> 24;
      if (!alpha) continue;
      int local = (int)x - (int)draw_width / 2;
      int64_t ox = (int64_t)center_x + (flip ? -1 - local : local) + extra;
      uint32_t r = p->brightnessMult[(rgb >> 19) & 31];
      uint32_t g = p->brightnessMult[(rgb >> 11) & 31];
      uint32_t b = p->brightnessMult[(rgb >> 3) & 31];
      if (alpha < 255) {
        uint32_t old = dst[(size_t)ox], inverse = 255 - alpha;
        r = (r * alpha + ((old >> 16) & 255) * inverse + 127) / 255;
        g = (g * alpha + ((old >> 8) & 255) * inverse + 127) / 255;
        b = (b * alpha + (old & 255) * inverse + 127) / 255;
      }
      dst[(size_t)ox] = 0xff000000u | r << 16 | g << 8 | b;
    }
  }
}

#ifndef DKC1_MOD_SCRIPT_H
#define DKC1_MOD_SCRIPT_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct lua_State lua_State;
typedef struct ModScript ModScript;
typedef void (*ModScriptRegisterHost)(lua_State *state, void *userdata);

#define MOD_SCRIPT_SOURCE_LIMIT (256u * 1024u)
#define MOD_SCRIPT_MEMORY_LIMIT (8u * 1024u * 1024u)
#define MOD_SCRIPT_INSTRUCTION_LIMIT 1000000u
#define MOD_SCRIPT_ARGUMENT_LIMIT 8u

/* Source-only Lua 5.4. The chunk must return a plain callback table. The host
 * registration callback runs protected and may install bounded C capabilities.
 * No script bytes or host functions execute outside a protected, metered call. */
ModScript *ModScriptCreate(const void *source, size_t length,
                          ModScriptRegisterHost register_host, void *userdata,
                          char *error, size_t error_size);
void ModScriptDestroy(ModScript *script);
bool ModScriptEnabled(const ModScript *script);
const char *ModScriptError(const ModScript *script);
size_t ModScriptMemory(const ModScript *script);

/* Missing callbacks are successful no-ops. Integer and boolean results replace
 * caller-initialized defaults; nil leaves its default intact. An invalid
 * result, callback error, or exceeded budget permanently disables the instance
 * and returns false without changing any result. Never call concurrently. */
bool ModScriptCall(ModScript *script, const char *callback,
                   const int64_t *arguments, size_t argument_count,
                   int64_t *results, size_t result_count);
#endif

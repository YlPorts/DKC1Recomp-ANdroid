# Mods — DKC1 Android 1.4

Los perfiles visuales de texto (formato 1) siguen funcionando. Los paquetes ZIP
admiten parches de datos (formato 2), botones de selección (formato 3) y código
Lua independiente con recursos opcionales (formato 4). El APK aporta la API
`dkc-lua-v1`; los personajes, físicas y reglas se definen en el mod. La referencia
actual es **FORMATO_V14.md**, con una muestra en **independent-template/**.

## Instalar y activar

Desde el inicio: **Mods → Importar mod (.dkcmod) → Activar**. Después, **Juego →
Jugar**. Un paquete nuevo se activa manualmente. Una actualización de formato 4
que declara compatibilidad puede sustituir automáticamente la versión anterior
activa, conservando su selección y perfiles después de validarlos. Los parches
de datos se preparan antes de arrancar el núcleo; el script se ejecuta durante
la sesión mediante los eventos de la API. Desactivar todos vuelve al juego
original. Los botones de selección se cambian desde el inicio.

No cambies ni reemplaces tu ROM instalada por una ROM ya parcheada. El importador
continúa exigiendo la USA v1.0 exacta. Los parches se aplican a una copia en memoria.

## Español 1.0

El paquete separado `DKC1-Espanol-v1.0.dkcmod` exige DKC1 Android 1.2
(`min_port: 102`). Incluye los textos, fuente, menús y créditos de Español 0.2,
y los rótulos gráficos pendientes. Se aplica en memoria; no sustituye la ROM
limpia instalada. Desactiva la versión anterior del mismo mod antes de activar
esta. La importación por sí sola no activa el paquete.

Los mods de datos anteriores siguen siendo compatibles con el APK 1.4. La
misma identidad de aplicación y certificado permiten actualizar sin eliminar
datos. El cambio de huella de un mod usa un perfil separado, salvo que una
actualización de formato 4 declare un alias de perfil compatible. Español 1.0
continúa usando su paquete y su perfil anteriores.

## Parches de datos y scripts independientes

Traducciones y cambios de recursos/datos en regiones admitidas de la ROM. Las
carpetas `patches/`, `textures/`, `sprites/`, `levels/` y `audio/` pueden contener
bloques `.bin`, declarados por offset y tamaño. Los gráficos, mapas, animaciones,
paletas y muestras deben respetar el formato, compresión y referencias originales.
No se puede arrastrar un PNG o un mapa de otro juego y esperar una conversión
automática. Un reemplazo de personaje necesita preparar todas sus animaciones.

El formato 4 añade código Lua para física y otras reglas mediante eventos y
funciones generales. Incluye bancos de sprites `DKCATL1` y audio `DKCSND1`
opcionales; un mod que solo cambia reglas puede contener únicamente su script.
No carga DLL de PC, código nativo ni parches universales IPS/BPS. Los parches
que tocan código recompilado se rechazan. Los scripts no tienen acceso a
archivos, red o procesos y están limitados por memoria e instrucciones.
Superar la validación estructural no demuestra que la lógica o los recursos
funcionen correctamente en todas las escenas. La música MSU-1 conserva su
importador separado; sus archivos no son MP3 renombrados.

Máximo 32 paquetes instalados, ocho activos y un solo mod con scripts por sesión.
Cada paquete admite hasta 32 MiB comprimidos y extraídos. El contenedor Lua
tiene un máximo de 24 MiB y el código fuente de 256 KiB. Los parches de datos
incluyen SHA-256 original y de reemplazo; el contenedor de ejecución declara
su tamaño y SHA-256. Se comprueban
rutas, tamaños, campos, duplicados, regiones y conflictos antes de activarlo.
Dos paquetes que escriban el mismo intervalo no pueden activarse juntos. También
se rechaza activar simultáneamente dos versiones del mismo ID.

## Partidas

Los estados rápidos y automáticos se separan por formato, modalidad MSU-1 y
huella del conjunto de paquetes activos. La SRAM con mods tiene su propio archivo;
al usar un conjunto por primera vez, se copia en memoria la SRAM original, si
existe. El mod no escribe la SRAM del juego original. Cambiar o desactivar mods
puede mostrar otras ranuras, pero no elimina las anteriores. Dos archivos ZIP
reempacados pueden tener huellas distintas incluso si sus textos son iguales:
conserva el mismo `.dkcmod` o usa una actualización con un alias compatible.

El campo `save_profile_sha256` del formato 4 declara la huella estable de una
versión anterior. El mismo ID y los mismos selectores permiten conservar sus
perfiles y copiar la selección al actualizar. Los paquetes y archivos anteriores
permanecen intactos. Este mecanismo mantiene también los perfiles combinados
con una traducción; no convierte datos de partidas incompatibles.

Sonic y Tails 1.0 usaba un motor específico dentro de la aplicación. Para
continuar en 1.4 importa Sonic y Tails 2.0, que lleva esa lógica en su script y
declara el alias de la versión anterior. La activación y las tres selecciones
se conservan. El paquete 1.0 se mantiene como archivo anterior, pero no se
ejecuta mediante el motor retirado.

La copia de seguridad incluye los nuevos nombres de partidas, pero no los
paquetes. Conserva tus `.dkcmod` junto a la copia y reinstala exactamente los
mismos para recuperar el mismo conjunto. Eliminar un mod no elimina sus partidas.

## Crear mods independientes

```sh
python android/tools/pack_script_mod.py --manifest android/mods/independent-template/manifest.json --script android/mods/independent-template/main.lua --out Salto-configurable-v1.0.dkcmod
```

No requiere una ROM ni recompilar el APK. El constructor incluye el código y
genera los hashes del contenedor; admite `--atlas` y `--audio` opcionales.
Consulta **FORMATO_V14.md** antes de añadir recursos o escribir a WRAM.

## Crear paquetes de datos

Primero prepara una copia privada del juego con modificaciones solo de datos.
Después:

```sh
python android/tools/mod_pack.py --base-rom clean.sfc --modified-rom edited.sfc \
  --id autor.mi_mod --name "Mi mod" --category graphics --output MiMod.dkcmod
```

La herramienta no genera ni descarga ninguna ROM. Rechaza cambios fuera de
las regiones admitidas y produce el paquete, no una ROM para distribución.
`--category` admite `translation`, `graphics`, `data` y `audio`. Los cambios de
niveles se declaran como datos; el manifiesto también admite `kind: "level"`.

El manifiesto requiere `format: 2`, `min_port: 101` (o `102` para las nuevas regiones auditadas), `id`, `name`, `version`,
`category`, `base_sha256` y una lista `patches`. Cada registro exige `offset`
(desplazamiento en la ROM sin cabecera, entero), `size`, `file`, `sha256`,
`expected_sha256` y `kind`. Este último admite `text`, `graphics`, `level`,
`audio` o `data`. No hay interpretación automática del nombre de las carpetas.

El constructor antiguo sigue disponible para reproducir el español inicial:

```sh
python android/tools/build_spanish_mod.py --rom clean.sfc --output Espanol.dkcmod
```

Los textos están en `es_messages.txt` y `es_names.txt`. `es_layout.json` contiene
solo longitudes y direcciones numéricas, no texto inglés ni imágenes. El
compilador impide desbordar líneas y conserva los comandos originales.

Para preparar gráficos propios:

```sh
python android/tools/png_to_snes4bpp.py personaje_indexado.png \
  --tiles tiles.bin --palette colors.bin
```

Esta última utilidad requiere Pillow y convierte exclusivamente píxeles indexados
0–15 en tiles 4bpp sin comprimir y paleta RGB555. El índice 0 se reserva para
transparencia. No construye las animaciones, OAM, compresión ni punteros del juego.

## Notas técnicas

El generador C del juego sigue usando la ROM limpia; los datos nunca se confunden
con código generado. La ruta Android comprueba de nuevo el plan binario y su hash,
preimágenes, rangos, orden, longitud y hash final antes de sustituir el buffer
completo. Los fallos de validación no aplican cambios parciales. Las regiones
estructurales derivan de `recomp/*.cfg` del proyecto; los rangos de texto se
contrastaron con la ROM USA v1.0 aportada y la documentación de su desensamblado.

La compilación Android y las pruebas de importación son distintas de ejecutar el
APK en un móvil: esta entrega necesita prueba en el dispositivo del usuario.

Para Español 1.0 usa el directorio `traduccion` del paquete de esta entrega:
`python build_spanish_full.py --rom clean.sfc --output Espanol.dkcmod`.
Instala antes sus requisitos. Este constructor no depende de fuentes del sistema.
Los avisos gráficos del cartucho se traducen sin desactivar ninguna comprobación.

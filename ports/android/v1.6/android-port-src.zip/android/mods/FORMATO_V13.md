# DKC1 Android 1.3: opciones de mods y personajes

Los formatos anteriores siguen admitidos. El formato 3 añade botones de
selección declarados por el paquete. Una opción cambia los recursos que se
preparan para la próxima sesión; no ejecuta scripts ni carga bibliotecas del ZIP.

Un grupo se declara en `choices`:

```json
{
  "id": "characters",
  "label": "Personajes",
  "default": "both",
  "options": [
    {"id": "both", "label": "Sonic y Tails", "patches": []},
    {"id": "sonic", "label": "Solo Sonic", "patches": []},
    {"id": "tails", "label": "Solo Tails", "patches": []}
  ]
}
```

Los parches comunes permanecen en `patches` del manifiesto. Cada opción puede
añadir sus propios parches con el mismo esquema, hashes y regiones de datos
admitidas en el formato 2. También se comprueban las alternativas no elegidas.
Cambiar una opción comprueba conflictos antes de guardar la selección. El
panel no permite cambiar opciones de contenido con una partida en marcha.

Los mods que no declaran opciones mantienen exactamente el cálculo anterior de
su perfil. Los que tienen opciones incluyen los valores elegidos en su huella.
Volver a una selección anterior recupera su perfil, sin borrar los demás.

El motor 1.3 incluye un comportamiento nativo concreto, `sonic2-v1`. Su
descriptor `runtime` declara un archivo de sprites/audio validado por tamaño,
SHA-256, formato y límites. `character_choice` identifica el grupo con los
valores `both`, `sonic` y `tails`. Se admite un solo comportamiento nativo por
sesión, junto a traducciones y otros mods de datos compatibles. Un paquete no
puede añadir por su cuenta un motor nuevo ni suministrar código ejecutable.

Sonic y Tails usa un plan de parches vacío y conserva la ROM DKC1 limpia. La
combinación con Español 1.0 produce el mismo plan de datos que Español solo.
El selector de personajes, su estado persistente y sus perfiles se guardan por
separado de los archivos originales.

## Alcance de Sonic y Tails 1.0

- Sprites de Sonic 2 extraídos de la ROM proporcionada: 214 cuadros de Sonic y
  139 de Tails, con sus piezas de cola.
- Ocho efectos originales de Sonic 2, capturados al ejecutar su controlador
  sonoro y convertidos a PCM para reproducirlos en Android.
- Estos efectos se mezclan con el audio de DKC1; no se sustituyen todos los
  efectos originales de los Kongs.
- Aceleración, fricción, frenado, salto variable, giro y carga de spindash
  implementados con constantes de Sonic 2; adaptación al terreno de DKC1.
- Los enemigos, daño, vidas, objetos, barriles, cuerdas y animales conservan
  las reglas de DKC1. No se han trasplantado el motor de colisiones de Sonic,
  sus sensores de pendientes/bucles ni su inteligencia de compañero.
- En pareja se utiliza el sistema de compañero e intercambio de DKC1. En
  solitario se representa al protagonista seleccionado y se oculta al
  compañero; la reserva de salud/rescate sigue perteneciendo a DKC1.

No equivale a ejecutar Sonic 2 dentro de DKC1. Las diferencias anteriores son
parte de esta adaptación y deben considerarse al evaluar el resultado.
La carga de spindash y demás estado transitorio del mod se reinician al cargar
o rebobinar, reconstruyendo el movimiento a partir del estado del jugador.

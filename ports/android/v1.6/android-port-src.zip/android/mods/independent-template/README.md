# Salto configurable

Esta plantilla crea un mod independiente para DKC1 Android 1.4. El archivo
`.dkcmod` contiene su código Lua; puedes cambiarlo y volver a empaquetarlo sin
recompilar ni firmar el APK. No necesita gráficos, sonidos ni una ROM para
construirse. La aplicación sí necesita su ROM habitual para jugar.

Desde la carpeta que contiene `android`, ejecuta con Python 3.10 o posterior:

```bash
python android/tools/pack_script_mod.py --manifest android/mods/independent-template/manifest.json --script android/mods/independent-template/main.lua --out Salto-configurable-v1.0.dkcmod
```

Importa el resultado desde Mods, actívalo y elige:

- **Original:** conserva la entrada del mando y no escribe memoria del juego.
- **Suave:** reduce a tres cuartos el impulso ascendente inicial de un salto
  normal. La reducción se aplica una vez por salto, al personaje que lleva el
  turno. No multiplica la velocidad continuamente.

La muestra usa las direcciones del jugador verificadas para DKC1 USA v1.0.
Solo interviene en la transición del estado 0 al estado 1 causada por una nueva
pulsación de B. Barriles, cuerdas, monturas y otros estados conservan su lógica.
Al cargar un estado o rebobinar, se vacían las variables transitorias; un salto
que ya estuviera en curso no se modifica retroactivamente.

Para crear tu propio mod, cambia `id`, `name`, `version`, la descripción y los
selectores en `manifest.json`, y escribe tu comportamiento en `main.lua`.
El empaquetador añade `runtime` con el tamaño y SHA-256 correctos. Los nombres
`jump`, `original` y `suave` pertenecen a esta muestra; el APK no los reconoce
ni les asigna un comportamiento especial.

Un solo mod con scripts puede estar activo a la vez. Puedes combinarlo con
mods de datos compatibles, como la traducción. Para probar esta muestra,
desactiva primero otro mod con scripts que tengas activo.

Consulta `../FORMATO_V14.md` para conocer todos los eventos, las funciones de
la API, los bancos de recursos y la conservación de perfiles entre versiones.
La comprobación estructural del empaquetador no demuestra que una modificación
jugable funcione: prueba tus cambios en los escenarios que afecten.

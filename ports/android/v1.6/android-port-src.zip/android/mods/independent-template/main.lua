-- Salto configurable: ejemplo para dkc-lua-v1, licencia MIT.
-- El modo Original no escribe memoria y devuelve intacto el mando.
-- Suave reduce a 3/4 el impulso vertical UNA VEZ al comenzar un salto normal.
-- No modifica sprites, sonidos, enemigos, monturas ni la ROM.
local enabled, actors, previous_input, jump_pressed, frame

local function signed16(value)
  return value >= 0x8000 and value - 0x10000 or value
end

local function reset()
  enabled = dkc.choice('jump') == 'suave'
  actors, previous_input, jump_pressed, frame = {}, 0, false, 0
end

local function filter_input(input)
  jump_pressed = (input & 1) ~= 0 and (previous_input & 1) == 0
  previous_input = input
  return input
end

local function sample(slot, may_write)
  if not enabled or slot < 2 or slot > 0x32 or slot % 2 ~= 0 then return end
  local id = dkc.read16(0x0d45 + slot)
  if (id ~= 1 and id ~= 2) or id ~= dkc.read16(0x056f) then
    actors[slot] = nil
    return
  end
  local state = dkc.read16(0x1029 + slot)
  if state == 0 then
    actors[slot] = {armed=true}
    return
  end
  -- Solo la transición del suelo normal (0) al salto (1).
  -- Cuerdas, daño, rodar, barriles y monturas quedan en manos del juego.
  if state ~= 1 then actors[slot] = nil; return end
  local actor = actors[slot]
  if not actor or not actor.armed then return end
  if jump_pressed and not actor.pending_until then actor.pending_until = frame + 2 end
  if not actor.pending_until then return end
  if frame > actor.pending_until then actor.armed = false; return end
  local velocity = signed16(dkc.read16(0x0ef1 + slot))
  -- En DKC1 el impulso positivo apunta hacia arriba.
  -- El estado 1 puede aparecer antes de inicializar ese impulso. Esperamos
  -- hasta dos fotogramas; una caída larga no queda armada para un rebote.
  if velocity <= 0 then return end
  if may_write then
    dkc.write16(0x0ef1 + slot, (velocity * 3) // 4)
    actor.armed = false
  end
end

local function before_velocity(slot)
  sample(slot, true)
end

local function after_frame()
  for slot=2,0x32,2 do sample(slot, false) end
  frame = frame + 1
end

return {
  reset=reset,
  filter_input=filter_input,
  before_velocity=before_velocity,
  after_frame=after_frame
}

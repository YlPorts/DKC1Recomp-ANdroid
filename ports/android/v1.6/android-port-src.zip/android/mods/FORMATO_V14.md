# DKC1 Android 1.4: mods independientes

El formato 4 añade programas Lua externos mediante `dkc-lua-v1`. El APK ofrece
funciones generales de acceso a WRAM, controles, presentación y sonidos. Los
personajes, direcciones del juego, constantes físicas, animaciones y reglas de
sustitución se definen en el mod. Cambiar esas reglas requiere reconstruir el
`.dkcmod`; ampliar una capacidad que la API todavía no ofrece requiere una
nueva versión de la aplicación.

## Crear un paquete

Se incluye una muestra completa en `independent-template/`. Desde la carpeta
que contiene `android`, con Python 3.10 o posterior:

```bash
python android/tools/pack_script_mod.py --manifest android/mods/independent-template/manifest.json --script android/mods/independent-template/main.lua --out Salto-configurable-v1.0.dkcmod
```

El constructor acepta `--atlas atlas.bin` y `--audio audio.bin` cuando se
necesitan bancos gráficos o sonoros. Estos archivos deben usar los formatos
binarios indicados abajo. No convierte PNG o WAV automáticamente. El script
se conserva como fuente UTF-8; no se ejecuta al construir el paquete.

El JSON fuente puede omitir `format`, `min_port`, `base_sha256` y `patches`:
el constructor usa 4, 105, la huella de la ROM admitida y una lista vacía,
respectivamente. Los campos obligatorios son `id`, `name`, `version` y
`category`. El descriptor `runtime` se genera siempre a partir de los bytes.

Ejemplo de manifiesto fuente:

```json
{
  "format": 4,
  "min_port": 105,
  "id": "example.my-mod",
  "name": "Mi mod",
  "version": "1.0",
  "category": "data",
  "base_sha256": "fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15",
  "patches": [],
  "choices": [
    {
      "id": "style",
      "label": "Estilo",
      "default": "normal",
      "options": [
        {"id": "normal", "label": "Normal", "patches": []},
        {"id": "alternate", "label": "Alternativo", "patches": []}
      ]
    }
  ]
}
```

Se admiten hasta ocho selectores con entre dos y ocho opciones cada uno.
Sus IDs siguen `[a-z][a-z0-9_-]{0,31}`. Un script sin selectores puede omitir
`choices` o usar `[]`. `dkc.choice('style')` obtiene el ID de la opción elegida.
La aplicación valida y conserva todas las selecciones, y las aplica al empezar
la siguiente sesión. No existe una lista de personajes reconocidos por el
motor de scripts.

Los parches comunes y los de cada opción conservan el esquema de datos de los
formatos anteriores. El empaquetador incluye los `.bin` declarados, relativos
a la carpeta del manifiesto, y comprueba tamaño, huella y regiones permitidas.
La aplicación comprueba además las preimágenes contra la ROM limpia al
importar. `README.txt` o `README.md` y `LICENSE.txt` o `LICENSE.md`, si existen
junto al manifiesto, se incluyen como `README.txt` y `LICENSE.txt`.

El ZIP final contiene `manifest.json`, `runtime/mod.bin`, esos textos
opcionales y cualquier parche de datos declarado. El código Lua ya está dentro
de `runtime/mod.bin`; no se admite un `main.lua` suelto sin declarar dentro del
ZIP instalable. Conserva los fuentes aparte para editar tu proyecto.

## Eventos Lua

El archivo debe devolver una tabla de funciones. Cada evento es opcional:

```lua
return {
  reset = function()
    -- Reiniciar aquí las variables transitorias propias del mod.
  end,
  filter_input = function(input)
    return input
  end
}
```

| Evento | Momento y resultado |
| --- | --- |
| `init()` | Una vez después de cargar el código. No dispone de WRAM. |
| `reset()` | Después de `init` y al reiniciar/cargar/rebobinar. No dispone de WRAM. |
| `filter_input(input)` | Recibe el mando empaquetado antes del fotograma. Devuelve un entero de 0 a `0xffffff`; devolver `nil` conserva la entrada. |
| `before_velocity(slot)` | Antes de las rutas enlazadas de integración de movimiento. `slot` es el desplazamiento del actor, no un índice consecutivo. Puede ocurrir más de una vez por fotograma. |
| `after_frame()` | Al terminar la actualización del juego; permite observar el resultado y escribir WRAM. |
| `end_frame()` | Después de la ejecución del fotograma, útil para completar eventos de sonido. No permite escribir WRAM. |
| `apu_command(command)` | Intercepta un comando de sonido de 16 bits. Devuelve un comando de 0 a 65535; devolver `nil` conserva el original. |
| `prepare_frame(bias)` | Antes del renderizado. Permite leer y ocultar entradas OAM temporalmente y preparar la presentación. |
| `draw_frame()` | Después de renderizar la imagen original. Permite dibujar fotogramas del atlas sobre ella. |

Los controles del jugador 1 usan B=1, Y=2, Select=4, Start=8, arriba=16,
abajo=32, izquierda=64, derecha=128, A=256, X=512, L=1024 y R=2048.
Los doce bits del segundo jugador empiezan en el bit 12. Un filtro que cambie
el primer mando debe conservar también los bits del segundo.

La API pasa el estado disponible en cada evento. No supongas que el estado
Lua se guarda dentro de una partida: las variables transitorias se reinician
al cargar o rebobinar y deben reconstruirse desde WRAM cuando sea necesario.

## Funciones del objeto `dkc`

| Función | Contrato |
| --- | --- |
| `read16(address)` | Lee una palabra sin signo, little endian, de WRAM. Direcciones `0..0x1fffe`. Requiere memoria del juego disponible. |
| `write16(address, value)` | Escribe una palabra `0..65535` en WRAM. Solo en `before_velocity` y `after_frame`; máximo 256 escrituras por evento. |
| `choice(id)` | Devuelve la opción seleccionada como cadena, o `nil` si el selector no existe. Disponible incluso en `init` y `reset`. |
| `display_enabled()` | Indica si están visibles la pantalla y la capa de sprites según el estado PPU disponible. |
| `oam(index)` | En `prepare_frame`, devuelve `x, y, attributes, tile, size, raw_y` de la entrada `0..127`. X conserva los nueve bits con signo; Y se normaliza para las filas visibles. |
| `hide_oam(index)` | Oculta temporalmente la entrada `0..127` durante el renderizado. El host restaura su valor original después. Solo en `prepare_frame`. |
| `frame_bounds(frame)` | Devuelve `first_row, last_row, width, height`; filas inclusivas del contenido visible. El índice empieza en cero. Un fotograma inexistente o totalmente transparente produce un error. |
| `draw(frame, x, y, flip, num, den)` | Dibuja en `draw_frame`; X es el centro horizontal y Y la primera fila del cuadro completo. `flip` es booleano; `num/den` es la escala racional. Usa términos enteros de 1 a 4. |
| `sound(play_mask, stop_mask)` | Activa o detiene efectos del banco con máscaras de bits de 32 bits. Parar un efecto tiene prioridad sobre iniciarlo. Disponible en eventos de juego, excluidos `init`, `reset`, `prepare_frame` y `draw_frame`. |

Las coordenadas de dibujo usan el origen horizontal de los 256 píxeles
nativos. El host añade el margen del formato panorámico; el script no debe
sumarlo otra vez. Se admiten X de -4096 a 4096 e Y de -65536 a 65536.
El límite es 128 dibujos y dos millones de píxeles de destino solicitados por
evento; los píxeles fuera de pantalla se recortan. El dibujo respeta el brillo
del juego y luego recibe los filtros de imagen de la aplicación.

El host mezcla el PCM del mod con el audio normal antes del volumen y silencio
globales. Reproducir un efecto del mod no suprime automáticamente un sonido del
juego: la política de comandos debe definirse mediante `apu_command` usando
identificadores comprobados. No presupongas que todos los comandos son efectos;
también existen órdenes de música y del controlador sonoro.

## Contenedores binarios

Todos los enteros son little endian. El contenedor de ejecución comienza con
20 bytes:

| Desplazamiento | Contenido |
| --- | --- |
| 0 | Ocho bytes `DKCLUA1\0` |
| 8 | `u32` longitud del código Lua |
| 12 | `u32` longitud del atlas; cero si se omite |
| 16 | `u32` longitud del banco sonoro; cero si se omite |
| 20 | Código UTF-8, seguido del atlas y después el banco sonoro |

`runtime` declara `engine: "dkc-lua-v1"`, `file`, `size` y `sha256`.
El tamaño total debe coincidir exactamente con la suma de las secciones.
El código ocupa entre 1 byte y 256 KiB; el contenedor completo, hasta 24 MiB.
El ZIP y su contenido descomprimido tienen un máximo de 32 MiB y 512 entradas.

El atlas comienza con ocho bytes `DKCATL1\0`, seguidos de cuatro `u32`:
ancho, alto, cantidad de fotogramas y cantidad de colores. Luego contiene la
paleta RGBA de cuatro bytes por color y los índices de ocho bits de todos los
fotogramas, por filas. El índice cero siempre es transparente. Los límites son
256×256, 4096 fotogramas, 256 colores y 16 MiB para el banco completo.

El banco sonoro comienza con ocho bytes `DKCSND1\0` y un `u32` con la cantidad
de efectos, hasta 32. Cada efecto contiene cuatro `u32`: bit identificador,
frecuencia, canales y cantidad de cuadros PCM. Siguen muestras PCM16 con signo,
little endian, intercaladas si son estéreo. Cada identificador es un único bit
no repetido. Se admiten 8000–96000 Hz, uno o dos canales y hasta ocho segundos
por efecto. El banco completo tiene un máximo de 16 MiB.

## Ejecución y límites

Se usa Lua 5.4 con código fuente; no se acepta bytecode ni código nativo del
paquete. No se exponen archivos, red, procesos, sistema operativo, reloj,
`require`, cargadores dinámicos, depurador ni corrutinas. No se incluyen
`pcall`, `xpcall`, metatablas o funciones de evaluación que permitan eludir
los límites del host. Las bibliotecas de cadenas y tablas ofrecen un conjunto
reducido de operaciones; consulta `native/mod_script.c` antes de usar funciones
adicionales. `math.random` tampoco está disponible.

Cada instancia tiene hasta 8 MiB de memoria Lua y un presupuesto de un millón
de instrucciones por evento. Los errores o presupuestos agotados detienen el
mod. Las escrituras WRAM del evento fallido se revierten, las entradas OAM se
restauran y los sonidos pendientes se cancelan. Los cambios de eventos
anteriores no se deshacen automáticamente. La ROM no se escribe mediante esta
API; los parches de datos se aplican a una copia de trabajo validada.

Actualmente se permite un solo mod con scripts activo por sesión, combinado
con otros mods de datos compatibles, hasta ocho paquetes activos en total.
No se pueden sumar dos sistemas físicos de personajes sin una política de
composición adicional.

## Actualizaciones y partidas existentes

Sin alias, cada archivo `.dkcmod` tiene un perfil propio basado en su SHA-256
y en las selecciones. Los formatos 2 y 3 de mods de datos conservan sus claves
anteriores. Desactivar todos los mods vuelve al perfil original.

Una actualización deliberadamente compatible puede declarar el campo superior
`save_profile_sha256` con la huella de su paquete anterior. Debe mantener el
mismo `id` y el mismo conjunto de IDs de selectores y opciones. El importador
comprueba esa correspondencia cuando encuentra el paquete anterior, copia la
selección y sustituye su activación al final de la operación. Conserva el
paquete anterior, sus selecciones y los archivos de partidas. Las siguientes
actualizaciones pueden reutilizar ese mismo alias estable.

El alias preserva también las claves de combinaciones con una traducción y los
perfiles de distintas selecciones. No transforma datos incompatibles de una
partida: corresponde al autor verificar que su nueva lógica pueda reanudar el
estado anterior. No uses la huella de un mod diferente como alias.

El antiguo Sonic y Tails 1.0 usaba el motor específico `sonic2-v1`. La aplicación
1.4 conserva la lectura de su manifiesto para migrarlo, pero requiere importar
Sonic y Tails 2.0 para ejecutarlo como mod independiente. Ese paquete declara
la huella original y conserva sus selecciones y perfiles. Los mods de datos
anteriores, incluida la traducción al español, siguen funcionando.

## Verificación

El empaquetador comprueba estructura, límites, hashes, selectores y recursos.
El importador Java y el host nativo validan nuevamente el contenido. Esto no
sustituye pruebas de juego: un script puede tener una lógica incorrecta aun
cuando su estructura sea válida. Comprueba el modo desactivado, cada opción,
las transiciones afectadas y la carga de partidas antes de distribuir un mod.

# DKC1 Android 1.5: romhacks independientes

El formato 5 añade `snes-compat-v1` para modificaciones de código de cartucho.
El contenido sigue en el `.dkcmod`: el APK no contiene reglas, sprites ni música
de Mario. Al iniciar se comprueba la ROM original y se aplica el paquete a una
copia en memoria, nunca al archivo privado del usuario.

Esta modalidad interpreta las instrucciones SNES del cartucho modificado.
No es una recompilación nativa del hack ni una conversión de sus rutinas a Lua.
La ruta recompilada y Lua de los formatos 2–4 queda como antes. El núcleo tiene
un indicador de sesión, desactivado por defecto, que impide saltar al código
nativo del DKC1 original o usar adaptadores ligados a sus direcciones.

## Límites de esta primera modalidad

- ROM DKC1 USA v1.0 de 4 MiB; la aplicación admite su cabecera de copia usual.
- Sin expansión de ROM, nuevos coprocesadores ni cambios a vectores/hardware.
- Un romhack activo, sin combinarlo con otros mods, incluidos Sonic y Español.
- 4:3 con música propia; no MSU-1. No cambia las preferencias globales.
- SRAM, autoguardado y ranuras separados; no se siembran con la SRAM de DKC1.
- Sin selectores, scripts Lua ni alias de perfiles dentro del formato 5.
  Los selectores de los mods Lua anteriores siguen funcionando normalmente.
- Un formato admitido no garantiza compatibilidad con cualquier hack. Esta
  entrega verifica DKC X Mario 1.107, no todos los hacks ni todos sus niveles.

## Manifiesto

Usa el esquema de recursos de los formatos anteriores y estos valores:

```json
{
  "format": 5,
  "min_port": 106,
  "id": "rainbowsprinklez.dkc-x-mario",
  "name": "DKC X Mario",
  "version": "1.107",
  "category": "data",
  "base_sha256": "fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15",
  "execution": "snes-compat-v1",
  "patches": []
}
```

`patches` debe contener al menos un recurso. Cada entrada declara `offset`,
`size`, `file`, `sha256`, `expected_sha256` y `kind`. Se validan rutas, tamaños,
solapes, preimágenes y hashes finales antes de activar. En formato 5 se permite
código de cartucho, pero se conservan `$FFD5..FFDB` y `$FFE0..FFFF` de la ROM
base. Los formatos anteriores mantienen su lista de regiones de datos.

El plan privado del cargador tiene magic `DKCMOD05`; los planes antiguos
conservan `DKCMOD02`. Ambos usan contador big-endian, SHA de base/resultado y
registros con offset, longitud, SHA de preimagen y bytes. El cargador C antiguo
rechaza el plan 05; la API ampliada devuelve explícitamente el modo de ejecución.
Las validaciones fallidas no alteran la ROM ni la selección previa.

## Reconstruir Mario sin recompilar el APK

En el paquete de fuentes, `mario-mod/build_mod.py` acepta la ROM privada y el ZIP
IPS original. Comprueba las identidades del IPS y del resultado, conserva todos
sus cambios y genera el mismo `.dkcmod`. El ROM hack es de RainbowSprinklez;
su README original se conserva dentro del mod. La conversión no reclama autoría
sobre el hack ni sobre los recursos de Nintendo.

Para reconstruir el APK, `APLICAR_V15.py` crea un checkout nuevo, fijado a las
revisiones documentadas, y aplica `android/engine-patches/compat-v1.patch`.
El constructor solo admite las huellas exactas de esos dos archivos del núcleo.

# Informe histórico: DKC1 Android 1.2 y Español 1.0

Este documento conserva los resultados de la entrega 1.2; no describe la
compilación ni las pruebas actuales de la 1.5. Para la entrega vigente, consulta
`BUILD_V1_5.json`, el LEEME principal y los informes de pruebas que lo acompañan.

## APK

- assembleRelease y lintRelease completados con SDK 35, Build Tools 35.0.0,
  NDK 28.2.13676358, CMake 3.22.1 y Gradle 8.11.1.
- com.ylports.dkc1recomp.mobile, versionCode 102, versionName 1.2.
- Firma v1/v2/v3 verificada; mismo certificado que el APK 1.1 entregado.
- Alineación ZIP y segmentos ELF de 16 KiB; SDL_main y seis JNI verificados.
- No contiene un archivo de ROM. No se ha instalado en un teléfono en esta sesión.

## Paquete y motor

- 16.615 comprobaciones estructurales aprobadas. Se preservan los controles,
  terminadores y tiempos de los registros de texto; no se parchea código.
- Cargador Java 1.2 acepta Español 1.0; Java 1.1 lo rechaza por versión mínima.
- Activación, desactivación, persistencia, conflictos y recursos corruptos probados.
- Cargador nativo con ASan/UBSan: 1.275 comprobaciones; resultado idéntico al constructor.
- Pruebas de utilidades C/Java/Python aprobadas; una prueba Python de aplicador
  antiguo se omite por trabajar con un checkout de capa Android.
- Ruta Jungle Hijinxs de 8.070 frames: seis hashes finales y audio coinciden con
  la ejecución original. Esta ruta no constituye una partida completa del nivel.
- Reparto y créditos: 22.000 frames, retorno al inicio. Entradas de escenas
  seleccionadas mediante un ejecutable diagnóstico separado, no incluido en el APK.
- Las capturas proceden del renderizador del núcleo Linux, no de un teléfono.
- Los 217 mensajes y 14 glifos conservan exactamente los bytes de la v0.2;
  aquella entrega había probado sus 217 salidas de texto VRAM. En esta pasada
  no se han vuelto a recorrer las 217 conversaciones una por una.

## Límites

No hay prueba de instalación/actualización en Android ni recorrido exhaustivo
al 101 %. La secuencia natural de falsa victoria contra K. Rool no se recorrió:
un intento diagnóstico mediante flag prematuro falla también en el juego sin
mod y se EXCLUYE como validación. Su encabezado se comprobó estructuralmente,
conservando todas las filas y tiempos. Los modos anchos siguen experimentales;
esta validación de traducción usa 4:3. Los cambios no se han subido a GitHub.

Se han traducido todos los elementos del catálogo identificado. Se conservan
intencionadamente título, nombres propios, marcas, KONG, DK y TNT.

package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Declarative image presets only. No scripts, binary patches, DLL or executable code. */
public final class VisualMod {
    public static final String[] KEYS={"sampling","palette","scanlines","edge"};
    public final String name;
    public final Map<String,Integer> values;
    private VisualMod(String name,Map<String,Integer> values){this.name=name;this.values=Collections.unmodifiableMap(values);}
    private static boolean hasControl(String text){for(int i=0;i<text.length();i++)if(Character.isISOControl(text.charAt(i)))return true;return false;}
    public static VisualMod read(InputStream in)throws IOException{
        if(in==null)throw new IOException("No se pudo abrir el perfil.");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>8192)throw new IOException("Perfil demasiado grande.");out.write(buf,0,n);}
        Properties p=new Properties();
        try{p.load(new StringReader(out.toString(StandardCharsets.UTF_8.name())));}catch(IllegalArgumentException e){throw new IOException("Perfil inválido.",e);}
        if(!"1".equals(p.getProperty("format")))throw new IOException("El perfil debe usar format=1.");
        String name=p.getProperty("name","").trim();
        if(name.isEmpty()||name.length()>60||hasControl(name))throw new IOException("Nombre de perfil inválido.");
        Set<String> allowed=new HashSet<>(Arrays.asList(KEYS));allowed.add("format");allowed.add("name");
        for(String key:p.stringPropertyNames())if(!allowed.contains(key))throw new IOException("Opción no admitida: "+key);
        HashMap<String,Integer> values=new HashMap<>();int[] hi={2,3,60,3};
        for(int i=0;i<KEYS.length;i++)if(p.containsKey(KEYS[i])){
            int value;try{value=Integer.parseInt(p.getProperty(KEYS[i]).trim());}catch(NumberFormatException e){throw new IOException("Valor inválido: "+KEYS[i]);}
            if(value<0||value>hi[i])throw new IOException("Valor fuera de rango: "+KEYS[i]);values.put(KEYS[i],value);
        }
        if(values.isEmpty())throw new IOException("El perfil no contiene ajustes.");
        return new VisualMod(name,values);
    }
}

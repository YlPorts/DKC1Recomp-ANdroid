package com.ylports.dkc1recomp;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;

/** Same-app exit summaries can identify a previous native crash, ANR or kill. */
@TargetApi(30)
final class ExitHistory {
    static void record(Context app){
        try{
            ActivityManager manager=(ActivityManager)app.getSystemService(Context.ACTIVITY_SERVICE);
            if(manager==null)return;
            for(ApplicationExitInfo exit:manager.getHistoricalProcessExitReasons(app.getPackageName(),0,5)){
                String description=exit.getDescription();
                if(description!=null&&description.length()>2048)description=description.substring(0,2048);
                AppDiagnostics.record("Cierre anterior: proceso="+exit.getProcessName()+" fecha="+exit.getTimestamp()
                    +" motivo="+exit.getReason()+" estado="+exit.getStatus()+" pssKiB="+exit.getPss()
                    +" rssKiB="+exit.getRss()+" descripción="+description,null);
            }
        }catch(RuntimeException e){AppDiagnostics.record("Historial de cierres no disponible",e);}
    }
}

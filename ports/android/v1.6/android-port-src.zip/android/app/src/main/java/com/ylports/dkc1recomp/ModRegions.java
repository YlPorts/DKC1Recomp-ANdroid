package com.ylports.dkc1recomp;
/** Generated structural data map; see mod_regions.py. */
final class ModRegions {
 static final int[][] DATA={{4928,6720},{6721,31265},{65536,98304},{122837,123328},{126942,127975},{131072,688128},{720896,3506176},{3538944,3571712},{3604480,3702784},{3712269,3712999},{3735552,3768320},{3801088,3899392},{3932160,3964928},{3997696,4030464},{4063232,4096000},{4128768,4161536}};
 static final int[][] TEXT={{122837,123328},{126952,127975},{3712269,3712999},{3933128,3945930}};
 static boolean allowed(int offset,int size,boolean text){if(offset<0||size<=0)return false;long end=(long)offset+size;for(int[] r:text?TEXT:DATA)if(offset>=r[0]&&end<=r[1])return true;return false;}
}

package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Content packages for the fixed USA 1.0 recomp, not arbitrary PC plugins.
 * The original ROM is read-only. Only bounded data patches are applied to a
 * disposable native ROM buffer. Every patch has an exact preimage digest.
 * Install is transactional; activation checks conflicts before changing state. */
public final class ContentMods {
    public static final String BASE_SHA="fa8cacf5bbfc39ee6bbaa557adf89133d60d42f6cf9e1db30d5a36a469f74d15";
    private static final int MAX_ENTRIES=512,MAX_PATCHES=4096,MAX_ACTIVE=8;
    private static final int MAX_TOTAL=32*1024*1024,MAX_PAYLOAD=4*1024*1024,MAX_ARCHIVE=32*1024*1024;
    public static final class Patch {
        final int offset,length; final String path,sha,before,kind; final File source;
        Patch(int offset,int length,String path,String sha,String before,String kind,File source){this.offset=offset;this.length=length;this.path=path;this.sha=sha;this.before=before;this.kind=kind;this.source=source;}
    }
    /** Declarative buttons; options can only select validated data patches. */
    public static final class Option {
        public final String id,label;public final int patchCount;private final List<Patch> patches;
        private Option(String id,String label,List<Patch> patches){this.id=id;this.label=label;this.patches=patches;patchCount=patches.size();}
    }
    public static final class Choice {
        public final String id,label,defaultId;public final List<Option> options;
        private Choice(String id,String label,String defaultId,List<Option> options){this.id=id;this.label=label;this.defaultId=defaultId;this.options=Collections.unmodifiableList(options);}
        private Option option(String id)throws IOException {for(Option option:options)if(option.id.equals(id))return option;throw new IOException("Opción de mod desconocida: "+id);}
    }
    public static final class Info {
        public final String digest,id,name,version,description,category,locale,saveProfile;
        public final boolean compatibleProfile,romhack;
        public final List<Choice> choices;
        public final RuntimeMod.Info runtime;
        public final NativeModule.Info nativeModule;
        public final int patchCount; private final List<Patch> patches;
        private Info(String digest,Map<String,Object> m,List<Patch> patches,List<Choice> choices,RuntimeMod.Info runtime,NativeModule.Info nativeModule)throws IOException {
            this.nativeModule=nativeModule;this.digest=digest;romhack=ModJson.integer(m.get("format"))==5;compatibleProfile=m.containsKey("save_profile_sha256");saveProfile=compatibleProfile?label(m,"save_profile_sha256",64):digest;unhex(saveProfile);id=label(m,"id",64);name=label(m,"name",60);version=label(m,"version",24);
            description=m.containsKey("description")?label(m,"description",300):"";
            category=label(m,"category",20);locale=m.containsKey("locale")?label(m,"locale",20):"";
            if(!id.matches("[a-z0-9][a-z0-9._-]{1,63}"))throw new IOException("ID de mod inválido.");
            if(!Arrays.asList("translation","graphics","data","audio").contains(category))throw new IOException("Categoría no admitida.");
            if(!locale.isEmpty()&&!locale.matches("[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})?"))throw new IOException("Idioma inválido.");
            this.patches=patches;this.choices=Collections.unmodifiableList(choices);this.runtime=runtime;patchCount=patches.size();
        }
    }
    public static final class Session {
        public final String key,plan,planSha;
        public final String runtimePath,runtimeSha,runtimeOptions;public final int runtimeMode;
        public final NativeModule.Info nativeModule;
        Session(String key,String plan,String planSha,String runtimePath,String runtimeSha,int runtimeMode,String runtimeOptions,NativeModule.Info nativeModule){this.nativeModule=nativeModule;this.key=key;this.plan=plan;this.planSha=planSha;this.runtimePath=runtimePath;this.runtimeSha=runtimeSha;this.runtimeMode=runtimeMode;this.runtimeOptions=runtimeOptions;}
        public boolean compatibility(){return runtimeMode==-2;}
    }
    private ContentMods(){}
    private static String label(Map<String,Object> m,String key,int max)throws IOException {
        String s=ModJson.string(m.get(key)).trim();if(s.isEmpty()||s.length()>max)throw new IOException("Campo inválido: "+key);
        for(int i=0;i<s.length();i++)if(Character.isISOControl(s.charAt(i)))throw new IOException("Texto de mod inválido.");return s;
    }
    private static MessageDigest digest(){try{return MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}}
    public static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x&255));return s.toString();}
    private static byte[] unhex(String text)throws IOException {
        if(!text.matches("[0-9a-f]{64}"))throw new IOException("SHA-256 inválido.");byte[] b=new byte[32];for(int i=0;i<32;i++)b[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16);return b;
    }
    private static String sha(byte[] bytes){return hex(digest().digest(bytes));}
    private static String sha(File f)throws IOException {try(InputStream in=new FileInputStream(f)){MessageDigest d=digest();byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)d.update(b,0,n);return hex(d.digest());}}
    private static byte[] bytes(InputStream in,int max)throws IOException {
        if(in==null)throw new IOException("No se pudo abrir el archivo.");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;
        while((n=in.read(b))!=-1){if(n==0)continue;if(out.size()>max-n)throw new IOException("Mod demasiado grande.");out.write(b,0,n);}return out.toByteArray();
    }
    private static byte[] bytes(File f,int max)throws IOException {try(InputStream in=new FileInputStream(f)){return bytes(in,max);}}
    /** ZIP entries can contain a 24 MiB program. Never hold the expanded
     * entry and ByteArrayOutputStream's growing copy in the Java heap. */
    private static int extract(InputStream in,File target,int max)throws IOException {
        int total=0;byte[] block=new byte[16384];
        try(FileOutputStream out=new FileOutputStream(target)){
            int n;while((n=in.read(block))!=-1){
                if(n==0)continue;
                if(n>max-total)throw new IOException("Mod demasiado grande.");
                out.write(block,0,n);total+=n;
            }
        }
        return total;
    }
    private static String utf8(byte[] b)throws IOException {try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString();}catch(CharacterCodingException e){throw new IOException("El manifiesto no es UTF-8 válido.",e);}}
    private static File mods(File root){return new File(root,"mods-v2");}
    private static File packageDir(File root,String digest)throws IOException {unhex(digest);return new File(mods(root),"packages/"+digest);}
    private static void mkdir(File f)throws IOException {if(!f.isDirectory()&&!f.mkdirs())throw new IOException("No se pudo crear el almacenamiento de mods.");}
    private static void removeTree(File f)throws IOException {File[] files=f.listFiles();if(files!=null)for(File child:files)removeTree(child);if(f.exists()&&!f.delete())throw new IOException("No se pudo eliminar "+f.getName());}
    private static void atomic(File f,byte[] b)throws IOException {
        mkdir(f.getParentFile());File tmp=File.createTempFile(".new-",".tmp",f.getParentFile());
        try {try(FileOutputStream out=new FileOutputStream(tmp)){out.write(b);out.getFD().sync();}if(!tmp.renameTo(f))throw new IOException("No se pudo guardar el estado de los mods.");}finally{if(tmp.exists())tmp.delete();}
    }
    private static boolean path(String s){
        if(s.isEmpty()||s.length()>160||s.startsWith("/")||s.contains("\\")||s.contains(":")||!s.matches("[A-Za-z0-9._/-]+"))return false;
        for(String p:s.split("/",-1))if(p.isEmpty()||p.equals(".")||p.equals(".."))return false;return true;
    }
    private static File child(File dir,String name)throws IOException {
        if(!path(name))throw new IOException("Ruta no permitida en el mod.");File f=new File(dir,name);
        if(!f.getCanonicalPath().startsWith(dir.getCanonicalPath()+File.separator))throw new IOException("Ruta fuera del mod.");return f;
    }
    private static String identifier(Map<String,Object> m,String field)throws IOException {
        String value=label(m,field,32);if(!value.matches("[a-z][a-z0-9_-]{0,31}"))throw new IOException("Identificador de selección inválido: "+field);return value;
    }
    private static void noOverlap(List<Patch> patches)throws IOException {
        List<Patch> sorted=new ArrayList<>(patches);Collections.sort(sorted,(a,b)->Integer.compare(a.offset,b.offset));
        int end=-1;for(Patch p:sorted){if(p.offset<end)throw new IOException("El paquete contiene parches solapados.");end=p.offset+p.length;}
    }
    private static List<Patch> parsePatches(File dir,Object value,boolean text,boolean full,int[] budget,boolean romhack)throws IOException {
        List<Object> rows=ModJson.array(value);if(rows.size()>MAX_PATCHES)throw new IOException("Cantidad de parches inválida.");
        List<Patch> patches=new ArrayList<>();int total=0;
        for(Object row:rows){Map<String,Object> p=ModJson.object(row);ModJson.keys(p,"offset","size","file","sha256","expected_sha256","kind");
            int offset=ModJson.integer(p.get("offset")),length=ModJson.integer(p.get("size"));String name=label(p,"file",160),hash=label(p,"sha256",64),old=label(p,"expected_sha256",64),kind=label(p,"kind",16);
            unhex(hash);unhex(old);
            if(!Arrays.asList("text","graphics","level","audio","data").contains(kind)||text&&!kind.equals("text"))throw new IOException("Tipo de recurso no admitido.");
            if(!name.matches("(patches|textures|sprites|levels|audio)/[A-Za-z0-9._/-]+\\.bin"))throw new IOException("El recurso debe ser un .bin dentro de la carpeta de contenido.");
            boolean allowed=romhack?offset>=0&&length>0&&offset<=4194304&&length<=4194304-offset:ModRegions.allowed(offset,length,text||kind.equals("text"));
            if(!allowed||length>MAX_PAYLOAD||total>MAX_PAYLOAD-length)throw new IOException("El parche toca código o una región no admitida.");
            if(++budget[0]>MAX_PATCHES||budget[1]>MAX_TOTAL-length)throw new IOException("Demasiados recursos entre las opciones del mod.");budget[1]+=length;
            File source=child(dir,name);if(!source.isFile()||source.length()!=length)throw new IOException("Recurso ausente o incompleto: "+name);
            if(full&&!sha(source).equals(hash))throw new IOException("Recurso alterado: "+name);
            total+=length;patches.add(new Patch(offset,length,name,hash,old,kind,source));
        }
        Collections.sort(patches,(a,b)->Integer.compare(a.offset,b.offset));noOverlap(patches);return Collections.unmodifiableList(patches);
    }
    private static Info inspect(File dir,String digestValue,boolean full)throws IOException {
        Map<String,Object> m=ModJson.read(utf8(bytes(new File(dir,"manifest.json"),512*1024)));
        ModJson.keys(m,"format","id","name","version","description","category","locale","min_port","base_sha256","patches","choices","runtime","save_profile_sha256","execution","native_module");
        int format=ModJson.integer(m.get("format")),port=ModJson.integer(m.get("min_port"));
        if((format<2||format>6)||port>108||!BASE_SHA.equals(m.get("base_sha256")))throw new IOException("Mod incompatible: se requiere formato 2 a 6 para DKC1 USA v1.0.");
        boolean romhack=format==5, nativeCode=format==6;
        NativeModule.Info nativeModule=NativeModule.inspect(dir,m.get("native_module"),full);
        if(nativeCode!=(nativeModule!=null))throw new IOException("El código nativo requiere formato 6.");
        if(romhack){
            if(port<106||!"snes-compat-v1".equals(m.get("execution"))||!"data".equals(m.get("category"))||m.containsKey("runtime")||m.containsKey("choices")||m.containsKey("save_profile_sha256"))
                throw new IOException("El formato 5 requiere compatibilidad SNES exclusiva, sin scripts, selectores ni alias de partidas.");
        }else if(nativeCode){
            if(port<107||!"aot-native-v1".equals(m.get("execution"))||!"data".equals(m.get("category"))||m.containsKey("runtime")||m.containsKey("choices")||m.containsKey("save_profile_sha256"))
                throw new IOException("El formato 6 requiere un programa nativo completo y exclusivo.");
        }else if(m.containsKey("execution"))throw new IOException("La compatibilidad SNES necesita formato 5 y APK 1.5.");
        if(format==4&&port<105||format!=4&&m.containsKey("save_profile_sha256"))throw new IOException("Los scripts y perfiles compatibles necesitan formato 4 y min_port 105.");
        if(format==2&&(m.containsKey("choices")||m.containsKey("runtime"))||format==3&&port<103)throw new IOException("Las selecciones necesitan formato 3 y min_port 103.");
        RuntimeMod.Info runtime=RuntimeMod.inspect(dir,m.get("runtime"),full);
        if(runtime!=null&&runtime.scripted()!=(format==4))throw new IOException("El motor del mod no corresponde al formato del paquete.");
        boolean text="translation".equals(m.get("category"));int[] budget={0,0};List<Patch> patches=parsePatches(dir,m.get("patches"),text,full,budget,romhack||nativeCode);
        List<Choice> choices=new ArrayList<>();Set<String> choiceIds=new HashSet<>();
        if(m.containsKey("choices")){
            List<Object> rows=ModJson.array(m.get("choices"));if((rows.isEmpty()&&format!=4)||rows.size()>8)throw new IOException("Cantidad de selectores inválida.");
            for(Object row:rows){Map<String,Object> c=ModJson.object(row);ModJson.keys(c,"id","label","default","options");
                String id=identifier(c,"id"),title=label(c,"label",60),def=identifier(c,"default");if(!choiceIds.add(id))throw new IOException("Selector duplicado.");
                List<Object> opts=ModJson.array(c.get("options"));if(opts.size()<2||opts.size()>8)throw new IOException("Un selector necesita entre dos y ocho botones.");
                List<Option> options=new ArrayList<>();Set<String> optionIds=new HashSet<>();
                for(Object option:opts){Map<String,Object> o=ModJson.object(option);ModJson.keys(o,"id","label","patches");String optionId=identifier(o,"id");
                    if(!optionIds.add(optionId))throw new IOException("Botón duplicado en el selector.");
                    List<Patch> pp=parsePatches(dir,o.get("patches"),text,full,budget,false);List<Patch> withBase=new ArrayList<>(patches);withBase.addAll(pp);noOverlap(withBase);
                    options.add(new Option(optionId,label(o,"label",60),pp));
                }
                Choice choice=new Choice(id,title,def,options);choice.option(def);choices.add(choice);
            }
        }
        if(format==2&&patches.isEmpty()||format==3&&choices.isEmpty())throw new IOException("El paquete no tiene contenido o selectores válidos.");
        if(budget[0]==0&&runtime==null)throw new IOException("Las opciones no contienen cambios de contenido.");
        if(runtime!=null&&!runtime.scripted()){Choice linked=null;for(Choice c:choices)if(c.id.equals(runtime.choice))linked=c;
            if(linked==null||linked.options.size()!=3)throw new IOException("El paquete anterior necesita su selector de personajes.");
            linked.option("both");linked.option("sonic");linked.option("tails");
        }
        return new Info(digestValue,m,patches,choices,runtime,nativeModule);
    }
    private static List<Patch> allPatches(Info info){List<Patch> all=new ArrayList<>(info.patches);for(Choice c:info.choices)for(Option o:c.options)all.addAll(o.patches);return all;}
    private static SortedMap<String,String> defaults(Info info){SortedMap<String,String> values=new TreeMap<>();for(Choice c:info.choices)values.put(c.id,c.defaultId);return values;}
    /** Effective selections, including defaults, independent of whether a mod is enabled. */
    public static SortedMap<String,String> selected(File root,Info info)throws IOException {
        SortedMap<String,String> values=defaults(info);if(info.choices.isEmpty())return Collections.unmodifiableSortedMap(values);
        File file=new File(mods(root),"selections/"+info.digest+".txt");if(!file.isFile())return Collections.unmodifiableSortedMap(values);
        Set<String> seen=new HashSet<>();for(String line:utf8(bytes(file,4096)).split("\n")){
            if(line.isEmpty())continue;int split=line.indexOf('=');if(split<1||split!=line.lastIndexOf('='))throw new IOException("Selección de mod inválida.");
            String key=line.substring(0,split),value=line.substring(split+1);if(!seen.add(key)||!values.containsKey(key))throw new IOException("Selector guardado desconocido o duplicado.");
            for(Choice c:info.choices)if(c.id.equals(key))c.option(value);values.put(key,value);
        }
        return Collections.unmodifiableSortedMap(values);
    }
    private static String selectedText(Map<String,String> values){StringBuilder text=new StringBuilder();for(Map.Entry<String,String> e:new TreeMap<>(values).entrySet())text.append(e.getKey()).append('=').append(e.getValue()).append('\n');return text.toString();}
    private static List<Patch> selectedPatches(Info info,Map<String,String> values)throws IOException {
        List<Patch> patches=new ArrayList<>(info.patches);for(Choice c:info.choices)patches.addAll(c.option(values.get(c.id)).patches);return patches;
    }
    public static List<Info> installed(File root)throws IOException {
        List<Info> list=new ArrayList<>();File[] dirs=new File(mods(root),"packages").listFiles();if(dirs==null)return list;
        Arrays.sort(dirs,(a,b)->a.getName().compareTo(b.getName()));for(File d:dirs)if(d.isDirectory()&&d.getName().matches("[0-9a-f]{64}")){
            if(list.size()>=32)throw new IOException("Hay demasiados mods instalados.");list.add(inspect(d,d.getName(),false));
        }return list;
    }
    public static SortedSet<String> active(File root)throws IOException {
        SortedSet<String> ids=new TreeSet<>();File file=new File(mods(root),"enabled.txt");if(!file.isFile())return ids;
        String s=utf8(bytes(file,2048));for(String line:s.split("\n")){if(line.isEmpty())continue;unhex(line);if(!ids.add(line))throw new IOException("Mod activo duplicado.");}
        if(ids.size()>MAX_ACTIVE)throw new IOException("Demasiados mods activos.");return ids;
    }
    private static String activeText(SortedSet<String> ids){StringBuilder b=new StringBuilder();for(String id:ids)b.append(id).append("\n");return b.toString();}
    private static String key(SortedSet<String> ids,List<Info> infos,Map<String,Map<String,String>> selections){
        if(ids.isEmpty())return "";List<Info> ordered=new ArrayList<>(infos);Collections.sort(ordered,(a,b)->a.saveProfile.compareTo(b.saveProfile));StringBuilder text=new StringBuilder();
        // Compatibility aliases retain the exact archive/choice fingerprint of prior saves.
        for(Info info:ordered)text.append(info.saveProfile).append('\n');
        for(Info info:ordered)if(!info.choices.isEmpty())text.append("choices:").append(info.saveProfile).append('\n').append(selectedText(selections.get(info.digest)));
        return sha(text.toString().getBytes(StandardCharsets.UTF_8)).substring(0,16);
    }
    private static List<Info> infos(File root,SortedSet<String> ids,boolean full)throws IOException {List<Info> infos=new ArrayList<>();for(String id:ids)infos.add(inspect(packageDir(root,id),id,full));return infos;}
    private static Map<String,Map<String,String>> selections(File root,List<Info> infos,Map<String,Map<String,String>> overrides)throws IOException {
        Map<String,Map<String,String>> selections=new TreeMap<>();for(Info info:infos)selections.put(info.digest,overrides!=null&&overrides.containsKey(info.digest)?overrides.get(info.digest):selected(root,info));return selections;
    }
    public static String activeKey(File root){try{SortedSet<String> ids=active(root);List<Info> infos=infos(root,ids,false);return key(ids,infos,selections(root,infos,null));}catch(IOException e){return "invalid";}}
    public static boolean activeCompatibility(File root){try{SortedSet<String> ids=active(root);if(ids.size()!=1)return false;return infos(root,ids,false).get(0).romhack;}catch(IOException e){return false;}}
    public static Info install(File root,File cache,InputStream input)throws IOException {
        if(input==null)throw new IOException("No se pudo abrir el paquete.");mkdir(cache);File stage=new File(cache,"mod-import-"+UUID.randomUUID());mkdir(stage);File archive=new File(stage,"package.zip");
        try{
            try(FileOutputStream out=new FileOutputStream(archive)){byte[] b=new byte[16384];int count=0,n;while((n=input.read(b))!=-1){count+=n;if(count>MAX_ARCHIVE)throw new IOException("Paquete demasiado grande (máximo 32 MiB).");out.write(b,0,n);}out.getFD().sync();}
            String id=sha(archive);File content=new File(stage,"content");mkdir(content);Set<String> names=new HashSet<>();int total=0,count=0;
            try(ZipInputStream zip=new ZipInputStream(new FileInputStream(archive))){ZipEntry e;while((e=zip.getNextEntry())!=null){
                String n=e.getName();if(++count>MAX_ENTRIES)throw new IOException("Demasiadas entradas en el ZIP.");
                if(e.isDirectory()){String d=n.endsWith("/")?n.substring(0,n.length()-1):n;child(content,d);if(zip.read()!=-1)throw new IOException("Una carpeta contiene datos inesperados.");zip.closeEntry();continue;}
                if(!names.add(n.toLowerCase(Locale.ROOT)))throw new IOException("Entrada duplicada en el mod.");File target=child(content,n);mkdir(target.getParentFile());
                int limit=n.equals("manifest.json")?512*1024:n.equals("README.txt")||n.equals("LICENSE.txt")?65536:n.startsWith("runtime/")?RuntimeMod.MAX_BYTES:n.startsWith("native/")?NativeModule.MAX_BYTES:MAX_PAYLOAD;
                total+=extract(zip,target,Math.min(limit,MAX_TOTAL-total));zip.closeEntry();
            }}
            Info info=inspect(content,id,true);Set<String> used=new HashSet<>(Arrays.asList("manifest.json","readme.txt","license.txt"));for(Patch p:allPatches(info))used.add(p.path.toLowerCase(Locale.ROOT));if(info.runtime!=null)used.addAll(info.runtime.files());if(info.nativeModule!=null){used.add(info.nativeModule.file.toLowerCase(Locale.ROOT));if(!info.nativeModule.source.setReadOnly())throw new IOException("No se pudo proteger el módulo nativo.");}
            if(!used.containsAll(names))throw new IOException("El paquete contiene archivos no admitidos o sin declarar.");
            // Validate preimages against the user's clean ROM before installation.
            verifyAllPreimages(root,info);
            Map<String,Map<String,String>> defaultSelection=new TreeMap<>();defaultSelection.put(info.digest,defaults(info));
            verifyAndCompose(root,Collections.singletonList(info),defaultSelection,null);
            File dest=packageDir(root,id);mkdir(dest.getParentFile());List<Info> previous=installed(root);
            if(dest.exists())inspect(dest,id,true);else if(previous.size()>=32)throw new IOException("Máximo 32 mods instalados.");
            Migration migration=migration(root,info,previous);
            if(!dest.exists()&&!content.renameTo(dest))throw new IOException("No se pudo instalar el mod.");
            if(migration!=null){
                atomic(new File(mods(root),"selections/"+id+".txt"),selectedText(migration.values).getBytes(StandardCharsets.UTF_8));
                // Activation is the final commit; previous package, choices and saves remain intact.
                if(migration.changed)atomic(new File(mods(root),"enabled.txt"),activeText(migration.ids).getBytes(StandardCharsets.UTF_8));
            }
            return inspect(dest,id,false);
        }finally{removeTree(stage);}
    }
    private static void verifyAllPreimages(File root,Info info)throws IOException {
        byte[] clean=cleanRom(root);for(Patch patch:allPatches(info))verifiedPatch(clean,patch);
    }
    private static final class Migration {
        final SortedSet<String> ids;final Map<String,String> values;final boolean changed;
        Migration(SortedSet<String> ids,Map<String,String> values,boolean changed){this.ids=ids;this.values=values;this.changed=changed;}
    }
    private static SortedMap<String,SortedSet<String>> choiceSchema(Info info){
        SortedMap<String,SortedSet<String>> schema=new TreeMap<>();
        for(Choice choice:info.choices){SortedSet<String> options=new TreeSet<>();for(Option option:choice.options)options.add(option.id);schema.put(choice.id,options);}
        return schema;
    }
    /** Resolve an explicitly compatible update before changing installation or activation. */
    private static Migration migration(File root,Info incoming,List<Info> previous)throws IOException {
        if(!incoming.compatibleProfile)return null;
        SortedSet<String> original=active(root),next=new TreeSet<>(original);List<Info> ancestors=new ArrayList<>();
        for(Info old:previous){
            if(old.digest.equals(incoming.digest))continue;
            if(!incoming.saveProfile.equals(old.digest)&&!incoming.saveProfile.equals(old.saveProfile))continue;
            if(!incoming.id.equals(old.id))throw new IOException("El perfil compatible pertenece a otro mod.");
            if(!choiceSchema(incoming).equals(choiceSchema(old)))throw new IOException("Los selectores del mod no permiten conservar el perfil anterior.");
            ancestors.add(old);
        }
        if(ancestors.isEmpty())return null;
        Collections.sort(ancestors,(a,b)->{
            int active=Boolean.compare(original.contains(b.digest),original.contains(a.digest));if(active!=0)return active;
            File af=new File(mods(root),"selections/"+a.digest+".txt"),bf=new File(mods(root),"selections/"+b.digest+".txt");
            int age=Long.compare(bf.lastModified(),af.lastModified());return age!=0?age:a.digest.compareTo(b.digest);
        });
        boolean changed=false;for(Info old:ancestors)if(next.remove(old.digest))changed=true;
        if(changed)next.add(incoming.digest);
        File own=new File(mods(root),"selections/"+incoming.digest+".txt");
        Map<String,String> values=own.isFile()?selected(root,incoming):selected(root,ancestors.get(0));
        if(changed){
            List<Info> candidates=new ArrayList<>();for(String id:next)candidates.add(id.equals(incoming.digest)?incoming:inspect(packageDir(root,id),id,true));
            Map<String,Map<String,String>> proposed=selections(root,candidates,null);proposed.put(incoming.digest,values);
            verifyAndCompose(root,candidates,proposed,null);
        }
        return new Migration(next,values,changed);
    }
    private static byte[] cleanRom(File root)throws IOException {
        byte[] r=bytes(new File(root,"game/dkc1.sfc"),4194304);if(r.length!=4194304||!sha(r).equals(BASE_SHA))throw new IOException("Importa primero la ROM original USA v1.0.");return r;
    }
    private static byte[] verifiedPatch(byte[] rom,Patch p)throws IOException {
        byte[] b=bytes(p.source,MAX_PAYLOAD);if(b.length!=p.length||!sha(b).equals(p.sha))throw new IOException("Recurso del mod alterado.");
        MessageDigest d=digest();d.update(rom,p.offset,p.length);if(!hex(d.digest()).equals(p.before))throw new IOException("El parche no corresponde a la ROM original.");
        if(p.kind.equals("text"))for(int i=0;i<b.length;i++){
            int old=rom[p.offset+i]&255,next=b[i]&255;
            if((old<32&&old!=next)||(old>=32&&((old^next)&128)!=0)||(old>=32&&(next&127)<32))throw new IOException("La traducción cambia un terminador o control de texto.");
        }
        return b;
    }
    private static byte[] verifyAndCompose(File root,List<Info> infos,Map<String,Map<String,String>> selections,File plan)throws IOException {
        byte[] rom=cleanRom(root);List<Patch> patches=new ArrayList<>();Set<String> logicalIds=new HashSet<>(),profiles=new HashSet<>();int runtimes=0;
        boolean compatibility=false,nativeCode=false;for(Info info:infos){compatibility|=info.romhack;nativeCode|=info.nativeModule!=null;}
        boolean completeProgram=compatibility||nativeCode;
        if(completeProgram&&infos.size()!=1)throw new IOException("Este romhack se ejecuta solo. Desactiva los demás mods; sus archivos y partidas se conservan.");
        byte[] hardware=Arrays.copyOfRange(rom,0xffd5,0xffdc),vectors=Arrays.copyOfRange(rom,0xffe0,0x10000);
        for(Info info:infos){if(!logicalIds.add(info.id))throw new IOException("Dos versiones del mismo mod no pueden estar activas.");if(!profiles.add(info.saveProfile))throw new IOException("Dos mods activos comparten el mismo perfil de partidas.");patches.addAll(selectedPatches(info,selections.get(info.digest)));
            if(info.runtime!=null&&++runtimes>1)throw new IOException("Solo puede estar activo un mod con scripts a la vez.");
        }
        if(patches.size()>MAX_PATCHES)throw new IOException("Demasiados parches activos.");Collections.sort(patches,(a,b)->Integer.compare(a.offset,b.offset));
        ByteArrayOutputStream records=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(records);int end=-1,total=0;
        for(Patch p:patches){if(p.offset<end)throw new IOException("Conflicto entre mods en el desplazamiento 0x"+Integer.toHexString(p.offset)+". Desactiva uno de ellos.");end=p.offset+p.length;
            if(total>MAX_PAYLOAD-p.length)throw new IOException("Los mods activos son demasiado grandes.");total+=p.length;
            byte[] b=verifiedPatch(rom,p);
            out.writeInt(p.offset);out.writeInt(p.length);out.write(unhex(p.before));out.write(b);System.arraycopy(b,0,rom,p.offset,p.length);
        }
        ByteArrayOutputStream packed=new ByteArrayOutputStream();DataOutputStream header=new DataOutputStream(packed);
        if(completeProgram&&(!Arrays.equals(hardware,Arrays.copyOfRange(rom,0xffd5,0xffdc))||!Arrays.equals(vectors,Arrays.copyOfRange(rom,0xffe0,0x10000))))throw new IOException("El hack cambia el hardware o los vectores DKC1 no admitidos.");
        if(nativeCode&&!sha(rom).equals(infos.get(0).nativeModule.romSha))throw new IOException("El contenido no corresponde al código nativo.");
        header.writeBytes(nativeCode?"DKCMOD06":compatibility?"DKCMOD05":"DKCMOD02");header.writeInt(patches.size());header.write(unhex(BASE_SHA));header.write(digest().digest(rom));header.write(records.toByteArray());
        byte[] result=packed.toByteArray();if(plan!=null)atomic(plan,result);return result;
    }
    private static Session prepare(File root,SortedSet<String> ids,Map<String,Map<String,String>> overrides)throws IOException {
        if(ids.isEmpty())return new Session("","","","","",-1,"",null);List<Info> mods=infos(root,ids,true);
        Map<String,Map<String,String>> values=selections(root,mods,overrides);String k=key(ids,mods,values);
        File plan=new File(ContentMods.mods(root),"plans/"+k+".bin");byte[] b=verifyAndCompose(root,mods,values,plan);
        String runtimePath="",runtimeSha="",runtimeOptions="";NativeModule.Info nativeModule=null;
        for(Info info:mods)if(info.nativeModule!=null){if(!NativeModule.approved(root,info.digest,info.nativeModule))throw new IOException("Este módulo necesita tu confirmación de confianza antes de activarse.");nativeModule=info.nativeModule;}
        for(Info info:mods)if(info.runtime!=null){
            if(!info.runtime.scripted())throw new IOException("Este mod usa el motor anterior. Importa su versión independiente actualizada para conservar tus personajes y partidas.");
            runtimePath=info.runtime.source.getAbsolutePath();runtimeSha=info.runtime.sha;runtimeOptions=selectedText(values.get(info.digest));
        }
        return new Session(k,plan.getAbsolutePath(),sha(b),runtimePath,runtimeSha,mods.size()==1&&mods.get(0).romhack?-2:-1,runtimeOptions,nativeModule);
    }
    public static boolean activeUsesOwnMusic(File root){try{for(Info info:infos(root,active(root),false))if(info.romhack||info.nativeModule!=null)return true;return false;}catch(IOException e){return false;}}
    public static boolean needsNativeTrust(File root,String id)throws IOException {Info info=inspect(packageDir(root,id),id,true);return !active(root).contains(id)&&info.nativeModule!=null&&!NativeModule.approved(root,id,info.nativeModule);}
    public static void trustAndToggleNative(File root,String id)throws IOException {Info info=inspect(packageDir(root,id),id,true);if(info.nativeModule==null)throw new IOException("El paquete no es un módulo nativo.");NativeModule.approve(root,id,info.nativeModule);toggle(root,id);}
    public static Session prepare(File root)throws IOException {return prepare(root,active(root),null);}
    public static void toggle(File root,String id)throws IOException {
        SortedSet<String> ids=active(root);if(!ids.remove(id)){unhex(id);ids.add(id);}if(ids.size()>MAX_ACTIVE)throw new IOException("Máximo ocho mods activos.");
        prepare(root,ids,null);atomic(new File(mods(root),"enabled.txt"),activeText(ids).getBytes(StandardCharsets.UTF_8));
    }
    /** Persist only after the proposed active combination has passed full validation. */
    public static void select(File root,String digest,String choiceId,String optionId)throws IOException {
        Info info=inspect(packageDir(root,digest),digest,true);Choice found=null;for(Choice c:info.choices)if(c.id.equals(choiceId))found=c;
        if(found==null)throw new IOException("Selector de mod desconocido.");found.option(optionId);
        SortedMap<String,String> values=new TreeMap<>(selected(root,info));values.put(choiceId,optionId);
        SortedSet<String> ids=active(root);if(!ids.contains(digest)){ids=new TreeSet<>();ids.add(digest);}
        Map<String,Map<String,String>> overrides=new TreeMap<>();overrides.put(digest,values);prepare(root,ids,overrides);
        atomic(new File(mods(root),"selections/"+digest+".txt"),selectedText(values).getBytes(StandardCharsets.UTF_8));
    }
    public static void disableAll(File root)throws IOException {atomic(new File(mods(root),"enabled.txt"),new byte[0]);}
    public static void uninstall(File root,String id)throws IOException {
        if(active(root).contains(id))throw new IOException("Desactiva el mod antes de quitarlo.");removeTree(packageDir(root,id));
        // Keep selections with the matching save profile for exact package reinstalls.
    }
}

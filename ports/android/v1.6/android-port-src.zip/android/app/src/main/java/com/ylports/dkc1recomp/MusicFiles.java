package com.ylports.dkc1recomp;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.util.*;

/** Copy a SAF folder once; playback no longer depends on URI grants or the original location. */
public final class MusicFiles {
    private MusicFiles(){}
    public static void importFolder(Context context,Uri uri)throws IOException{
        try{MusicPack.install(context.getFilesDir(),writer->{walk(context,uri,DocumentsContract.getTreeDocumentId(uri),writer,0,new int[]{0},new HashSet<>());});}
        catch(SecurityException|IllegalArgumentException e){throw new IOException("No se pudo acceder a la carpeta elegida.",e);}
    }
    private static void walk(Context c,Uri tree,String id,MusicPack.Writer writer,int depth,int[] count,Set<String> visited)throws IOException{
        if(depth>3||!visited.add(id))throw new IOException("Carpeta anidada o circular no admitida.");
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        try(Cursor cursor=c.getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
            if(cursor==null)throw new IOException("No se pudo leer la carpeta.");
            while(cursor.moveToNext()){
                if(++count[0]>512)throw new IOException("Demasiados archivos en el pack.");
                String child=cursor.getString(0),name=cursor.getString(1),mime=cursor.getString(2);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){walk(c,tree,child,writer,depth+1,count,visited);continue;}
                Uri file=DocumentsContract.buildDocumentUriUsingTree(tree,child);
                try(InputStream in=c.getContentResolver().openInputStream(file)){if(in==null)throw new IOException("No se pudo abrir "+name);writer.add(name,in);}
            }
        }
    }
}

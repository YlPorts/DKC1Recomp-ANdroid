package com.ylports.dkc1recomp;

import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.concurrent.Executors;

/** Small recovery entry: never reads mod manifests or loads native libraries. */
public final class RecoveryActivity extends Activity {
    private static final int EXPORT=210;
    private TextView status;
    private File game(){return AppSettings.gameDirectory(this);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(24*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);setContentView(scroll);
        TextView title=new TextView(this);title.setText("Recuperar DKC1 Android · 1.6.1");title.setTextSize(23);box.addView(title);
        status=new TextView(this);status.setText("Se registró un cierre al abrir o importar contenido. Tus archivos y partidas siguen guardados.");status.setTextSize(16);box.addView(status);
        button(box,"Volver al inicio",()->retry(false));
        button(box,"Desactivar mods y volver al inicio",()->retry(true));
        button(box,"Exportar diagnóstico",()->{
            try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("text/plain").putExtra(Intent.EXTRA_TITLE,"DKC1-diagnostico.txt"),EXPORT);}
            catch(ActivityNotFoundException e){status.setText("No hay selector de archivos disponible.");}
        });
    }
    private void button(LinearLayout box,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setOnClickListener(v->action.run());box.addView(b);}
    private void retry(boolean disable){
        try{
            if(disable)ContentMods.disableAll(getFilesDir());
            AppDiagnostics.retry(game());
            startActivity(new Intent(this,LauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK));finish();
        }catch(IOException|RuntimeException e){AppDiagnostics.record("Recuperación",e);status.setText("No se pudo volver al inicio. Exporta el diagnóstico.");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=EXPORT||result!=RESULT_OK||data==null||data.getData()==null)return;
        android.net.Uri uri=data.getData();File dir=game();Context app=getApplicationContext();
        java.util.concurrent.ExecutorService worker=Executors.newSingleThreadExecutor();
        worker.execute(()->{String message="Diagnóstico guardado.";
            try(OutputStream out=app.getContentResolver().openOutputStream(uri,"w")){AppDiagnostics.export(dir,out);}
            catch(IOException|RuntimeException e){message="No se pudo guardar el diagnóstico.";}
            final String text=message;runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())status.setText(text);});
        });worker.shutdown();
    }
}

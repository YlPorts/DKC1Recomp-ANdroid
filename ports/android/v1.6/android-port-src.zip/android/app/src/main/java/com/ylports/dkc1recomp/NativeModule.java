package com.ylports.dkc1recomp;

import java.io.*;
import java.security.*;
import java.util.*;

/** Trusted AOT modules have a separate format and explicit approval boundary.
 * Formats 2-4 keep their original data/Lua restrictions. */
public final class NativeModule {
    public static final int MAX_BYTES=24*1024*1024;
    public static final String ABI="c40089a07f379b453c4fd30497b40d8e826efd92c14a4fcd517b43a9bdced195";
    public static final class Info {
        public final String file,sha,romSha;public final File source;
        Info(String file,String sha,String romSha,File source){this.file=file;this.sha=sha;this.romSha=romSha;this.source=source;}
    }
    private NativeModule(){}
    private static String hash(Object value)throws IOException {
        String s=ModJson.string(value);if(!s.matches("[0-9a-f]{64}"))throw new IOException("Identidad de módulo nativo inválida.");return s;
    }
    static Info inspect(File dir,Object value,boolean full)throws IOException {
        if(value==null)return null;
        Map<String,Object> m=ModJson.object(value);
        ModJson.keys(m,"file","size","sha256","rom_sha256","abi_sha256","architecture");
        if(!"arm64-v8a".equals(m.get("architecture"))||!ABI.equals(m.get("abi_sha256")))throw new IOException("El módulo necesita otra versión del motor o arquitectura.");
        String file=ModJson.string(m.get("file")),sha=hash(m.get("sha256")),rom=hash(m.get("rom_sha256"));
        if(!file.matches("native/arm64-v8a/[A-Za-z0-9_-]+\\.so"))throw new IOException("Ruta de módulo nativo inválida.");
        File source=new File(dir,file);int size=ModJson.integer(m.get("size"));
        if(!source.getCanonicalPath().startsWith(dir.getCanonicalPath()+File.separator)||!source.isFile()||size<64||size>MAX_BYTES||source.length()!=size)
            throw new IOException("Módulo nativo ausente o incompleto.");
        try(InputStream in=new FileInputStream(source)){
            byte[] header=new byte[64];int p=0,n;while(p<header.length&&(n=in.read(header,p,header.length-p))>0)p+=n;
            if(p!=64||header[0]!=0x7f||header[1]!='E'||header[2]!='L'||header[3]!='F'||header[4]!=2||header[5]!=1||header[16]!=3||header[17]!=0||(header[18]&255)!=183||header[19]!=0)
                throw new IOException("El módulo no es una biblioteca Android ARM64.");
            if(full){MessageDigest d;try{d=MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}
                d.update(header);byte[] b=new byte[16384];while((n=in.read(b))!=-1)d.update(b,0,n);
                if(!ContentMods.hex(d.digest()).equals(sha))throw new IOException("El módulo nativo ha sido alterado.");}
        }
        return new Info(file,sha,rom,source);
    }
    private static File approval(File root,String id)throws IOException {
        hash(id);return new File(root,"mods-v2/native-trust/"+id+".txt");
    }
    static boolean approved(File root,String id,Info info)throws IOException {
        File f=approval(root,id);if(!f.isFile())return false;
        try(InputStream in=new FileInputStream(f)){
            byte[] b=new byte[66];int n=in.read(b);return n==65&&in.read()==-1&&new String(b,0,n,java.nio.charset.StandardCharsets.US_ASCII).equals(info.sha+"\n");
        }
    }
    static void approve(File root,String id,Info info)throws IOException {
        File f=approval(root,id),dir=f.getParentFile();if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("No se pudo guardar la confianza del módulo.");
        File tmp=File.createTempFile("native-",".tmp",dir);
        try{try(FileOutputStream out=new FileOutputStream(tmp)){out.write((info.sha+"\n").getBytes(java.nio.charset.StandardCharsets.US_ASCII));out.getFD().sync();}
            if(!tmp.renameTo(f))throw new IOException("No se pudo guardar la confianza del módulo.");
        }finally{if(tmp.exists())tmp.delete();}
    }
}

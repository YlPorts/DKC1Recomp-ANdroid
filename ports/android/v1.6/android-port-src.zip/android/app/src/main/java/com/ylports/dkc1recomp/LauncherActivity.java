package com.ylports.dkc1recomp;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.util.AtomicFile;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.*;

public final class LauncherActivity extends Activity implements OptionsPanel.Host {
    private static final int PICK_ROM=100,EXPORT_LOG=101,EXPORT_BACKUP=102,IMPORT_BACKUP=103,PICK_MUSIC_ZIP=104,PICK_MUSIC_FOLDER=105,PICK_MOD=106;
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private AppSettings settings;private OptionsPanel panel;
    private boolean working,ready;private int serial;private String message="Comprobando la ROM instalada…";
    static File gameDirectory(Activity a){return AppSettings.gameDirectory(a);}
    private File rom(){return new File(gameDirectory(this),"dkc1.sfc");}
    @Override public void onCreate(Bundle state){
        AppDiagnostics.install(AppSettings.gameDirectory(this),"DKC1 1.6.1 · Android "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");
        super.onCreate(state);
        if(Build.VERSION.SDK_INT>=30){Context app=getApplicationContext();IO.execute(()->ExitHistory.record(app));}
        if(AppDiagnostics.recoveryNeeded(gameDirectory(this))){openRecovery();return;}
        try{
            settings=new AppSettings(this);panel=new OptionsPanel(this,settings,this,0);setContentView(panel);
            panel.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});
            panel.requestApplyInsets();
        }catch(RuntimeException|LinkageError|OutOfMemoryError e){AppDiagnostics.startupFailure("Construyendo el inicio",e);openRecovery();}
    }
    private void openRecovery(){startActivity(new Intent(this,RecoveryActivity.class));finish();}
    @Override protected void onResume(){super.onResume();if(isFinishing()||settings==null)return;settings.reload();if(!working)checkInstalled();}
    @Override protected void onPause(){if(settings!=null)settings.save();super.onPause();}
    @Override public boolean inGame(){return false;}
    @Override public boolean romReady(){return ready;}
    @Override public boolean busy(){return working;}
    @Override public String activeAspect(){return settings.aspect();}
    @Override public String saveKey(){return settings.saveKey(this);}
    @Override public String status(){return message;}
    @Override public void changed(){}
    private void refresh(){if(panel!=null)panel.refresh();}
    @Override public void action(String name){
        if(name.equals("music_page")){panel.showPage(6);return;}
        if(name.equals("licenses")){Ui.licenses(this);return;}
        if(name.equals("remove_mod")){settings.removeMod();refresh();return;}
        if(name.equals("reset_controls")){new AlertDialog.Builder(this).setTitle("Restablecer controles")
            .setMessage("Volver a la distribución estándar sin cambiar partidas ni otros ajustes.")
            .setPositiveButton("Restablecer",(d,w)->{settings.clearPositions();settings.set("touch_size",100);settings.save();refresh();}).setNegativeButton("Cancelar",null).show();return;}
        if(working)return;
        if(name.startsWith("select_content:")){
            String[] parts=name.split(":",-1);
            if(parts.length!=4){error("Selección de mod inválida.");return;}
            job("Comprobando opción…","Opción guardada para la próxima partida.",()->ContentMods.select(getFilesDir(),parts[1],parts[2],parts[3]));return;
        }
        if(name.startsWith("toggle_content:")){
            String id=name.substring(15);final boolean[] trust=new boolean[1];
            job("Comprobando compatibilidad…","",()->trust[0]=ContentMods.needsNativeTrust(getFilesDir(),id),()->{
                if(trust[0])new AlertDialog.Builder(this).setTitle("¿Confías en este mod?")
                    .setMessage("Este mod ejecuta código nativo con los permisos de DKC1 Android. Actívalo solo si confías en su origen.")
                    .setPositiveButton("Confiar y activar",(d,w)->job("Activando mod…","Mod activado.",()->ContentMods.trustAndToggleNative(getFilesDir(),id)))
                    .setNegativeButton("Cancelar",null).show();
                else job("Comprobando compatibilidad…","Selección de mods guardada.",()->ContentMods.toggle(getFilesDir(),id));
            });return;
        }
        if(name.startsWith("delete_content:")){String id=name.substring(15);new AlertDialog.Builder(this).setTitle("¿Quitar este mod?")
            .setPositiveButton("Quitar",(d,w)->job("Quitando mod…","Mod eliminado.",()->ContentMods.uninstall(getFilesDir(),id))).setNegativeButton("Cancelar",null).show();return;}
        if(name.equals("disable_content")){job("Desactivando mods…","Juego original seleccionado.",()->ContentMods.disableAll(getFilesDir()));return;}
        switch(name){
            case "play":case "fresh":
                if(!ready)return;settings.save();final ContentMods.Session[] session=new ContentMods.Session[1];
                job("Preparando el juego…","",()->session[0]=ContentMods.prepare(getFilesDir()),()->startActivity(new Intent(this,GameActivity.class)
                    .putExtra("aspect",session[0].compatibility()?"4:3":settings.aspect()).putExtra("resume",name.equals("play")&&settings.autoState(this).isFile())
                    .putExtra("compatibility",session[0].compatibility())
                    .putExtra("native_path",session[0].nativeModule==null?"":session[0].nativeModule.source.getAbsolutePath()).putExtra("native_sha",session[0].nativeModule==null?"":session[0].nativeModule.sha)
                    .putExtra("mod_key",session[0].key).putExtra("mod_plan",session[0].plan).putExtra("mod_sha",session[0].planSha)
                    .putExtra("runtime_path",session[0].runtimePath).putExtra("runtime_sha",session[0].runtimeSha).putExtra("runtime_options",session[0].runtimeOptions)));break;
            case "rom":openDocument(PICK_ROM);break;
            case "music_zip":openDocument(PICK_MUSIC_ZIP);break;
            case "import_mod":openDocument(PICK_MOD);break;
            case "music_folder":
                try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),PICK_MUSIC_FOLDER);}
                catch(ActivityNotFoundException e){error("No hay selector de carpetas disponible.");}break;
            case "music_remove":new AlertDialog.Builder(this).setTitle("¿Quitar el pack?")
                .setPositiveButton("Quitar",(d,w)->job("Quitando música…","Música original activada.",()->MusicPack.remove(getFilesDir()),()->{settings.set("music_enabled",false);settings.set("music_name","");settings.save();}))
                .setNegativeButton("Cancelar",null).show();break;
            case "export_backup":createDocument(EXPORT_BACKUP,"application/zip","DKC1-partidas.zip");break;
            case "import_backup":
                new AlertDialog.Builder(this).setTitle("Restaurar partidas y ajustes")
                    .setMessage("Los archivos presentes en la copia reemplazarán las mismas ranuras. Exporta antes tus partidas actuales. La ROM instalada no se cambia.")
                    .setPositiveButton("Elegir copia",(d,w)->openDocument(IMPORT_BACKUP)).setNegativeButton("Cancelar",null).show();break;
            case "export_log":
                if(!AppDiagnostics.available(gameDirectory(this))){error("Aún no hay un diagnóstico disponible.");break;}
                createDocument(EXPORT_LOG,"text/plain","DKC1Recomp-android.log.txt");break;
            default:break;
        }
    }
    private void openDocument(int request){try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),request);}catch(ActivityNotFoundException e){error("No hay selector de archivos disponible.");}}
    private void createDocument(int request,String mime,String name){try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name),request);}catch(ActivityNotFoundException e){error("No hay selector de archivos disponible.");}}
    private void checkInstalled(){
        final int ticket=++serial;working=true;message="Comprobando la copia privada…";refresh();File source=rom();
        IO.execute(()->{
            boolean valid=false;String status="Selecciona tu ROM USA v1.0 una vez para comenzar.";
            try{MusicPack.recover(new File(getFilesDir(),"music"));}catch(IOException ignored){}
            try(InputStream in=new AtomicFile(source).openRead()){RomVerifier.readVerified(in);valid=true;status="USA v1.0 · ROM instalada y verificada";}
            catch(IOException e){if(source.exists())status="La copia instalada no es válida. Cámbiala desde Extras.";}
            final boolean ok=valid;final String text=status;
            runOnUiThread(()->{if(isFinishing()||isDestroyed()||ticket!=serial)return;working=false;ready=ok;message=text;refresh();readLastError();});
        });
    }
    private void readLastError(){
        File f=new File(gameDirectory(this),"last-error.txt");if(!f.isFile())return;
        try(InputStream in=new FileInputStream(f)){byte[] b=new byte[4096];int n=in.read(b);if(n>0)error(new String(b,0,n,StandardCharsets.UTF_8));f.delete();}catch(IOException ignored){}
    }
    private interface Job{void run()throws Exception;}
    private void job(String status,String success,Job action){job(status,success,action,null);}
    private void job(String status,String success,Job action,Runnable completed){
        int ticket=++serial;working=true;message=status;refresh();
        AppDiagnostics.record(status,null);
        IO.execute(()->{String problem=null;
            try{action.run();AppDiagnostics.record("Completado: "+status,null);}
            catch(OutOfMemoryError e){problem="No hay suficiente memoria disponible para importar el mod. Cierra otras aplicaciones y vuelve a intentarlo. Tus partidas se conservan.";AppDiagnostics.record(status,e);}
            catch(Exception e){problem=e.getMessage()==null?e.toString():e.getMessage();AppDiagnostics.record(status,e);}
            final String failure=problem;
            runOnUiThread(()->{if(isFinishing()||isDestroyed()||ticket!=serial)return;working=false;settings.reload();if(failure!=null)error(failure);else{if(completed!=null)completed.run();if(!success.isEmpty())Toast.makeText(this,success,Toast.LENGTH_LONG).show();}if(ticket==serial)checkInstalled();});});
    }
    private static void atomicWrite(File target,byte[] bytes)throws IOException{
        File parent=target.getParentFile();if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("No se pudo crear el almacenamiento privado.");
        AtomicFile file=new AtomicFile(target);FileOutputStream out=null;
        try{out=file.startWrite();out.write(bytes);file.finishWrite(out);out=null;}finally{if(out!=null)file.failWrite(out);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();Context app=getApplicationContext();File dir=AppSettings.gameDirectory(app);
        if(request==PICK_ROM){
            job("Importando ROM…","ROM guardada.",()->{
                try(InputStream in=app.getContentResolver().openInputStream(uri)){atomicWrite(new File(dir,"dkc1.sfc"),RomVerifier.readVerified(in));}
            });
        }else if(request==PICK_MOD){final VisualMod[] profile=new VisualMod[1];job("Validando mod…","Mod importado. Actívalo desde Mods.",()->{
            InputStream raw=app.getContentResolver().openInputStream(uri);if(raw==null)throw new IOException("No se pudo abrir el mod.");
            try(BufferedInputStream in=new BufferedInputStream(raw)){in.mark(4);int a=in.read(),b=in.read();in.reset();
                if(a=='P'&&b=='K')ContentMods.install(app.getFilesDir(),app.getCacheDir(),in);else profile[0]=VisualMod.read(in);
            }},()->{if(profile[0]!=null)settings.activateMod(profile[0]);});
        }else if(request==PICK_MUSIC_ZIP||request==PICK_MUSIC_FOLDER){final String[] packName={"Pack MSU-1"};job("Importando pack de música…","Pack de música instalado.",()->{
            if(request==PICK_MUSIC_FOLDER)MusicFiles.importFolder(app,uri);
            else try(InputStream in=app.getContentResolver().openInputStream(uri)){MusicPack.fromZip(app.getFilesDir(),in);}
            String name="Pack MSU-1";
            try(android.database.Cursor cursor=app.getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
                if(cursor!=null&&cursor.moveToFirst())name=cursor.getString(0);
            }catch(Exception ignored){}
            packName[0]=name==null?"Pack MSU-1":name.substring(0,Math.min(name.length(),80));
        },()->{settings.set("music_name",packName[0]);settings.set("music_enabled",true);settings.save();});
        }else if(request==EXPORT_BACKUP){settings.save();job("Exportando partidas…","Copia de seguridad guardada.",()->{try(OutputStream out=app.getContentResolver().openOutputStream(uri,"w")){SaveBackup.exportTo(app.getFilesDir(),out);}});
        }else if(request==IMPORT_BACKUP){job("Validando la copia antes de restaurar…","Partidas y configuración restauradas.",()->{try(InputStream in=app.getContentResolver().openInputStream(uri)){SaveBackup.importFrom(app.getFilesDir(),app.getCacheDir(),in);}});
        }else if(request==EXPORT_LOG){job("Exportando diagnóstico…","Diagnóstico guardado.",()->{
            try(OutputStream out=app.getContentResolver().openOutputStream(uri,"w")){AppDiagnostics.export(dir,out);}});
        }
    }
    private void error(String text){Ui.message(this,"DKC1 Android",text);}
}

package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.charset.StandardCharsets;

/** Bounded private launcher diagnostics, also available before the first game. */
public final class AppDiagnostics {
    private static File directory;
    private static boolean installed;
    private AppDiagnostics(){}
    public static synchronized void install(File dir,String version){
        directory=dir;
        if(!installed){
            Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
                startupFailure("Fallo no controlado en "+thread.getName(),error);
                if(previous!=null)previous.uncaughtException(thread,error);
            });
            installed=true;
        }
        record("Inicio: "+version,null);
    }
    public static synchronized void startupFailure(String action,Throwable error){
        record(action,error);
        try{if(directory!=null){directory.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(directory,"launcher-crash.txt"))){out.write(1);}}}catch(Throwable ignored){}
    }
    public static boolean recoveryNeeded(File dir){return new File(dir,"launcher-crash.txt").isFile();}
    public static void retry(File dir)throws IOException {
        File marker=new File(dir,"launcher-crash.txt");
        if(marker.exists()&&!marker.delete())throw new IOException("No se pudo preparar el reinicio.");
    }
    public static synchronized void record(String action,Throwable error){
        if(directory==null)return;
        try{
            if(!directory.isDirectory()&&!directory.mkdirs())return;
            File file=new File(directory,"launcher.log");
            boolean append=file.length()<256*1024;
            try(PrintWriter out=new PrintWriter(new OutputStreamWriter(new FileOutputStream(file,append),StandardCharsets.UTF_8))){
                out.println(System.currentTimeMillis()+" · "+action);
                if(error!=null)error.printStackTrace(out);
            }
        }catch(Throwable ignored){/* Do not hide the original error, including OOM. */}
    }
    public static boolean available(File dir){return new File(dir,"launcher.log").isFile()||new File(dir,"android.log").isFile();}
    public static void export(File dir,OutputStream out)throws IOException {
        if(out==null)throw new IOException("No se pudo abrir el destino.");
        for(String name:new String[]{"launcher.log","android.log"}){
            File file=new File(dir,name);if(!file.isFile())continue;
            out.write(("\n--- "+name+" ---\n").getBytes(StandardCharsets.UTF_8));
            try(RandomAccessFile in=new RandomAccessFile(file,"r")){
                long limit=name.equals("launcher.log")?256*1024:8L*1024*1024;
                in.seek(Math.max(0,in.length()-limit));byte[] block=new byte[16384];int n;
                while((n=in.read(block))!=-1)out.write(block,0,n);
            }
        }
    }
}

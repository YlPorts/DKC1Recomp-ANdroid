package com.ylports.dkc1recomp;

import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

/** Bounded, transactional MSU-1 importer. Game uses the same player as the desktop host. */
public final class MusicPack {
    public static final long MAX_TRACK=256L*1024*1024,MAX_TOTAL=2L*1024*1024*1024;
    private static final Pattern TRACK=Pattern.compile("(?:track|dkc_msu|dkc)[-_](\\d{1,2})\\.pcm",Pattern.CASE_INSENSITIVE);
    public interface Source {void copy(Writer writer)throws IOException;}
    public static final class Writer {
        private final File stage;private final Set<Integer> found=new HashSet<>();private long total;private int entries;
        Writer(File stage){this.stage=stage;}
        public void add(String name,InputStream in)throws IOException{
            if(++entries>512)throw new IOException("Demasiados archivos en el pack.");
            String clean=name.replace('\\','/');
            if(clean.startsWith("/")||clean.indexOf(':')>=0||clean.indexOf('\0')>=0)throw new IOException("Ruta no válida en el pack.");
            for(String part:clean.split("/"))if(part.equals(".."))throw new IOException("Ruta no válida en el pack.");
            String base=clean.substring(clean.lastIndexOf('/')+1);Matcher m=TRACK.matcher(base);
            boolean pcm=m.matches();int id=pcm?Integer.parseInt(m.group(1)):0;
            if(pcm&&(id<1||id>32||!found.add(id)))throw new IOException("Pista duplicada o fuera de rango: "+base);
            // Consume even ignored entries with limits, preventing hidden ZIP bombs.
            File target=pcm?new File(stage,"track-"+id+".pcm"):null;
            long count=0;byte[] buf=new byte[65536];int n;
            try(OutputStream out=pcm?new FileOutputStream(target):new OutputStream(){@Override public void write(int b){} @Override public void write(byte[] b,int o,int l){}}){
                while((n=in.read(buf))!=-1){count+=n;total+=n;if(count>(pcm?MAX_TRACK:8L*1024*1024)||total>MAX_TOTAL)throw new IOException("El pack excede el límite de tamaño.");out.write(buf,0,n);}
            }
            if(pcm)validatePcm(target);
        }
        void complete()throws IOException{
            List<Integer> missing=new ArrayList<>();for(int i=1;i<=27;i++)if(!found.contains(i))missing.add(i);
            if(!missing.isEmpty())throw new IOException("Faltan pistas MSU-1: "+missing+". Se conserva el pack anterior.");
        }
    }
    public static void validatePcm(File file)throws IOException{
        long size=file.length();if(size<16||(size-8)%4!=0||size>MAX_TRACK)throw new IOException("PCM inválido: "+file.getName());
        byte[] h=new byte[8];try(DataInputStream in=new DataInputStream(new FileInputStream(file))){in.readFully(h);}
        if(h[0]!='M'||h[1]!='S'||h[2]!='U'||h[3]!='1')throw new IOException("No es PCM MSU-1: "+file.getName());
        long loop=(h[4]&255L)|((h[5]&255L)<<8)|((h[6]&255L)<<16)|((h[7]&255L)<<24);
        if(loop>=(size-8)/4&&loop!=0xffffffffL)throw new IOException("Punto de bucle inválido: "+file.getName());
    }
    public static synchronized void install(File files,Source source)throws IOException{
        File root=new File(files,"music");if(!root.isDirectory()&&!root.mkdirs())throw new IOException("No se pudo crear la carpeta de música.");
        File current=new File(root,"current"),old=new File(root,"previous");
        recover(root);
        File stage=new File(root,"stage-"+UUID.randomUUID());if(!stage.mkdir())throw new IOException("No se pudo preparar el pack.");
        boolean movedOld=false;
        try{
            Writer writer=new Writer(stage);source.copy(writer);writer.complete();
            if(current.exists()){if(old.exists())delete(old);if(!current.renameTo(old))throw new IOException("No se pudo conservar el pack anterior.");movedOld=true;}
            if(!stage.renameTo(current)){if(movedOld)old.renameTo(current);throw new IOException("No se pudo instalar el pack.");}
            if(old.exists())delete(old);
        }finally{if(stage.exists())delete(stage);}
    }
    public static void fromZip(File files,InputStream input)throws IOException{
        if(input==null)throw new IOException("No se pudo abrir el pack.");
        install(files,writer->{try(ZipInputStream zip=new ZipInputStream(input)){ZipEntry entry;while((entry=zip.getNextEntry())!=null){writer.add(entry.getName(),zip);zip.closeEntry();}}});
    }
    public static void recover(File root)throws IOException{
        File current=new File(root,"current"),old=new File(root,"previous");
        if(!current.exists()&&old.exists()&&!old.renameTo(current))throw new IOException("No se pudo recuperar el pack anterior.");
    }
    public static boolean isComplete(File dir){
        if(!dir.isDirectory())return false;
        for(int i=1;i<=27;i++)if(!new File(dir,"track-"+i+".pcm").isFile())return false;
        return true;
    }
    public static synchronized void remove(File files)throws IOException{File root=new File(files,"music");recover(root);File current=new File(root,"current");if(current.exists())delete(current);}
    static void delete(File file)throws IOException{File[] children=file.listFiles();if(children!=null)for(File f:children)delete(f);if(file.exists()&&!file.delete())throw new IOException("No se pudo eliminar "+file.getName());}
}

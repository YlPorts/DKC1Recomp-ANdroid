package com.ylports.dkc1recomp;

import java.io.IOException;
import java.util.*;

/** Small strict manifest parser, independent of Android for adversarial tests.
 * No code evaluation, duplicate keys, floats or implicit conversions. */
final class ModJson {
    private final String text; private int p,nodes;
    private ModJson(String t){text=t;}
    static Map<String,Object> read(String text)throws IOException {
        ModJson r=new ModJson(text);Object o=r.value(0);r.ws();
        if(r.p!=text.length()||!(o instanceof Map))throw new IOException("Manifest JSON inválido.");
        return object(o);
    }
    @SuppressWarnings("unchecked") static Map<String,Object> object(Object o)throws IOException {
        if(!(o instanceof Map))throw new IOException("Se esperaba un objeto JSON.");return (Map<String,Object>)o;
    }
    @SuppressWarnings("unchecked") static List<Object> array(Object o)throws IOException {
        if(!(o instanceof List))throw new IOException("Se esperaba una lista JSON.");return (List<Object>)o;
    }
    static String string(Object o)throws IOException {if(!(o instanceof String))throw new IOException("Se esperaba texto JSON.");return (String)o;}
    static int integer(Object o)throws IOException {if(!(o instanceof Long)||((Long)o)<0||((Long)o)>Integer.MAX_VALUE)throw new IOException("Entero JSON fuera de rango.");return ((Long)o).intValue();}
    static void keys(Map<String,Object> m,String... allowed)throws IOException {
        Set<String> keys=new HashSet<>(Arrays.asList(allowed));for(String k:m.keySet())if(!keys.contains(k))throw new IOException("Campo no admitido: "+k);
    }
    private IOException bad(){return new IOException("JSON inválido cerca del carácter "+p+".");}
    private void ws(){while(p<text.length()&&" \r\n\t".indexOf(text.charAt(p))>=0)p++;}
    private boolean take(char c){ws();if(p<text.length()&&text.charAt(p)==c){p++;return true;}return false;}
    private Object value(int depth)throws IOException {
        if(depth>12||++nodes>30000)throw bad();ws();if(p>=text.length())throw bad();char c=text.charAt(p);
        if(c=='"')return string();
        if(take('{')){Map<String,Object> m=new LinkedHashMap<>();if(take('}'))return m;
            do{ws();String k=string();if(!take(':')||m.containsKey(k))throw bad();m.put(k,value(depth+1));if(take('}'))return m;}while(take(','));throw bad();}
        if(take('[')){List<Object> l=new ArrayList<>();if(take(']'))return l;do{l.add(value(depth+1));if(take(']'))return l;}while(take(','));throw bad();}
        for(String literal:new String[]{"true","false","null"})if(text.startsWith(literal,p)){p+=literal.length();return literal.equals("null")?null:literal.equals("true");}
        int start=p;if(p<text.length()&&text.charAt(p)=='-')p++;
        if(p>=text.length()||text.charAt(p)<'0'||text.charAt(p)>'9')throw bad();
        if(text.charAt(p)=='0')p++;else while(p<text.length()&&text.charAt(p)>='0'&&text.charAt(p)<='9')p++;
        try{return Long.valueOf(text.substring(start,p));}catch(NumberFormatException e){throw bad();}
    }
    private String string()throws IOException {
        ws();if(p>=text.length()||text.charAt(p++)!='"')throw bad();StringBuilder s=new StringBuilder();
        while(p<text.length()){
            char c=text.charAt(p++);if(c=='"'){
                for(int i=0;i<s.length();i++)if(Character.isSurrogate(s.charAt(i))){if(!Character.isHighSurrogate(s.charAt(i))||i+1>=s.length()||!Character.isLowSurrogate(s.charAt(++i)))throw bad();}
                return s.toString();
            }
            if(c<32)throw bad();if(c=='\\'){
                if(p>=text.length())throw bad();c=text.charAt(p++);
                switch(c){case '"':case '\\':case '/':break;case 'b':c='\b';break;case 'f':c='\f';break;case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;
                case 'u':if(p+4>text.length())throw bad();for(int k=p;k<p+4;k++)if(Character.digit(text.charAt(k),16)<0||text.charAt(k)>127)throw bad();try{c=(char)Integer.parseInt(text.substring(p,p+4),16);}catch(NumberFormatException e){throw bad();}p+=4;break;default:throw bad();}
            }s.append(c);if(s.length()>16384)throw bad();
        }throw bad();
    }
}

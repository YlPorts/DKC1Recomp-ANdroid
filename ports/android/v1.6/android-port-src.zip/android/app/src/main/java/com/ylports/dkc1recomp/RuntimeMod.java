package com.ylports.dkc1recomp;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.security.*;
import java.util.*;

/** Bounded script packages. The native Lua host validates resources again before execution. */
public final class RuntimeMod {
    public static final int MAX_BYTES=24*1024*1024,MAX_SCRIPT_BYTES=256*1024;
    public static final String SCRIPT_ENGINE="dkc-lua-v1";
    public static final class Info {
        public final String engine,path,sha,choice;
        public final int size;
        public final File source;
        private Info(String engine,String path,String sha,String choice,int size,File source){
            this.engine=engine;this.path=path;this.sha=sha;this.choice=choice;this.size=size;this.source=source;
        }
        public Set<String> files(){return Collections.singleton(path.toLowerCase(Locale.ROOT));}
        public boolean scripted(){return SCRIPT_ENGINE.equals(engine);}
        /** Compatibility metadata for old format-3 packages; no legacy behavior is executed. */
        public int mode(String option)throws IOException {
            if("both".equals(option))return 0;
            if("sonic".equals(option))return 1;
            if("tails".equals(option))return 2;
            throw new IOException("Selección del paquete anterior no admitida.");
        }
    }
    private RuntimeMod(){}
    private static byte[] read(InputStream in,int size)throws IOException {
        byte[] bytes=new byte[size];int count=0;
        while(count<size){int n=in.read(bytes,count,size-count);if(n<0)throw new EOFException("Recurso de mod incompleto.");count+=n;}
        return bytes;
    }
    private static long little32(byte[] data,int offset){return (data[offset]&255L)|((data[offset+1]&255L)<<8)|((data[offset+2]&255L)<<16)|((data[offset+3]&255L)<<24);}
    public static Info inspect(File directory,Object value,boolean full)throws IOException {
        if(value==null)return null;
        Map<String,Object> m=ModJson.object(value);
        String engine=ModJson.string(m.get("engine"));boolean scripted=SCRIPT_ENGINE.equals(engine);
        if(scripted)ModJson.keys(m,"engine","file","size","sha256");
        else ModJson.keys(m,"engine","file","size","sha256","character_choice");
        String path=ModJson.string(m.get("file")),sha=ModJson.string(m.get("sha256"));
        String choice=scripted?"":ModJson.string(m.get("character_choice"));int size=ModJson.integer(m.get("size"));
        if(!scripted&&!engine.equals("sonic2-v1"))throw new IOException("Motor del mod no admitido.");
        if(!path.matches("runtime/[A-Za-z0-9_-]+\\.bin")||!sha.matches("[0-9a-f]{64}")||
            (!scripted&&!choice.matches("[a-z][a-z0-9_-]{0,31}"))||size<(scripted?21:32)||size>MAX_BYTES)
            throw new IOException("Descriptor del mod inválido.");
        File source=new File(directory,path);
        if(!source.getCanonicalPath().startsWith(directory.getCanonicalPath()+File.separator)||
            !source.isFile()||source.length()!=size)throw new IOException("Recursos del mod ausentes o incompletos.");
        try(InputStream in=new FileInputStream(source)){
            byte[] magic=read(in,8);
            if(scripted){
                if(!Arrays.equals(magic,new byte[]{'D','K','C','L','U','A','1',0}))throw new IOException("Formato del script de mod no admitido.");
                byte[] lengths=read(in,12);long script=little32(lengths,0),atlas=little32(lengths,4),audio=little32(lengths,8);
                if(script<1||script>MAX_SCRIPT_BYTES||20+script+atlas+audio!=size)throw new IOException("Secciones del mod incompletas o fuera de rango.");
                byte[] code=read(in,(int)script);if((code[0]&255)==27)throw new IOException("El mod debe incluir código Lua fuente, no bytecode.");
                try{StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(code));}
                catch(CharacterCodingException e){throw new IOException("El script del mod no es UTF-8 válido.",e);}
                for(byte b:code)if(b==0)throw new IOException("El script del mod contiene bytes nulos.");
            }else if(!Arrays.equals(magic,new byte[]{'S','2','M','O','D','1','3',0}))throw new IOException("Formato de personajes anterior no admitido.");
        }
        if(full){
            final MessageDigest d;try{d=MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}
            try(InputStream in=new FileInputStream(source)){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}
            StringBuilder actual=new StringBuilder();for(byte b:d.digest())actual.append(String.format(Locale.ROOT,"%02x",b&255));
            if(!actual.toString().equals(sha))throw new IOException("Recursos del mod alterados.");
        }
        return new Info(engine,path,sha,choice,size,source);
    }
}
